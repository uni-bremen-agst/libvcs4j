package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class ParentsCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        ParentsCommand cmd = ParentsCommand.on(repo);
        List<Changeset> parents = cmd.execute();
        Assert.assertEquals(0, parents.size());

        writeFile("a");
        Changeset csRoot = commit();
        parents = cmd.execute();
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csRoot, parents.get(0));

        writeFile("b");
        Changeset csB = commit();
        parents = cmd.execute();
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csB, parents.get(0));

        update(csRoot);
        writeFile("c");
        Changeset csC = commit();
        parents = cmd.execute();
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csC, parents.get(0));

        MergeCommand.on(repo).execute(null);
        parents = cmd.execute();
        Assert.assertEquals(2, parents.size());
        Assert.assertEquals(csC, parents.get(0));
        Assert.assertEquals(csB, parents.get(1));

        writeFile("a");
        Changeset csA2 = commit();
        parents = cmd.execute();
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csA2, parents.get(0));

        writeFile("a");
        Changeset csA3 = commit();
        parents = cmd.execute();
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csA3, parents.get(0));

        parents = cmd.execute("a");
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csA3, parents.get(0));

        parents = cmd.execute("b");
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csB, parents.get(0));

        parents = cmd.rev(csA3.getNode()).execute("a");
        Assert.assertEquals(1, parents.size());
        Assert.assertEquals(csA2, parents.get(0));

        // Diamond shape give two parents with the same node
        parents = cmd.rev(csA2.getNode()).execute("a");
        Assert.assertEquals(2, parents.size());
        Assert.assertEquals(csRoot, parents.get(0));
        Assert.assertEquals(csRoot, parents.get(1));
    }

}
