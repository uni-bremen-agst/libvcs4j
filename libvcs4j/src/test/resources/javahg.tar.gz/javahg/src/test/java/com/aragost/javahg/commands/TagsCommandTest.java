/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.test.AbstractTestCase;

public class TagsCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        List<Changeset> changesets = createTags(repo);

        List<Tag> tags = TagsCommand.on(repo).execute();

        Collections.sort(tags);

        Assert.assertEquals(4, tags.size());
        assertTag(changesets.get(0), "a", tags.get(0));
        assertTag(changesets.get(2), "a , b", tags.get(1));
        assertTag(changesets.get(1), "a b", tags.get(2));
        assertTag(changesets.get(0), "b", tags.get(3));

        Assert.assertFalse(tags.get(0).isLocal());
        Assert.assertFalse(tags.get(3).isLocal());
    }

    private static void assertTag(Changeset expectedChangeset, String expectedName, Tag actualTag) {
        Assert.assertEquals(expectedChangeset, actualTag.getChangeset());
        Assert.assertEquals(expectedName, actualTag.getName());
    }

    private List<Changeset> createTags(Repository repo) throws IOException {
        TagCommand cmd = TagCommand.on(repo).force().user("test");
        createChangeset();
        cmd.execute("a", "b", "a b");
        cmd.execute(" a b ");
        cmd.execute(" a , b ");
        return LogCommand.on(repo).rev("0:tip").execute();
        // O:tip orders the list so rev n is in position n of the
        // list
    }

    @Test
    public void testReverse() throws IOException {
        Repository repo = getTestRepository();
        List<Changeset> changesets = createTags(repo);

        Map<Changeset, List<Tag>> map = TagsCommand.on(repo).executeReverse();

        Assert.assertEquals(3, map.size());
        List<Tag> tags = map.get(changesets.get(0));
        Collections.sort(tags);
        Assert.assertEquals(2, tags.size());
        Assert.assertEquals("a", tags.get(0).getName());
        Assert.assertEquals("b", tags.get(1).getName());
        Assert.assertEquals("a b", Utils.single(map.get(changesets.get(1))).getName());
        Assert.assertEquals("a , b", Utils.single(map.get(changesets.get(2))).getName());
    }
}
