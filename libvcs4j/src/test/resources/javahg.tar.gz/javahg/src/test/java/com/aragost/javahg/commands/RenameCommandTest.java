package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class RenameCommandTest extends AbstractTestCase {

    @Test
    public void testCopyFileToFile() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "");
        commit();

        Map<String, String> result = RenameCommand.on(repo).execute("x", "y");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("x", result.get("y"));
    }

    @Test
    public void testCopyFileToFileInDir() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "");
        commit();
        new File(repo.getDirectory(), "b").mkdir();

        Map<String, String> result = RenameCommand.on(repo).execute("x", "b/y");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("x", result.get(osSep("b/y")));
    }

    @Test
    public void testCopyFileInDirToFileInDir() throws IOException {
        Repository repo = getTestRepository();
        new File(repo.getDirectory(), "a").mkdir();
        new File(repo.getDirectory(), "b").mkdir();
        writeFile("a/x", "");
        commit();

        Map<String, String> result = RenameCommand.on(repo).execute("a/x", "b/y");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(osSep("a/x"), result.get(osSep("b/y")));
    }

    @Test
    public void testCopyFileToDir() throws IOException {
        Repository repo = getTestRepository();
        new File(repo.getDirectory(), "b").mkdir();
        writeFile("x", "");
        commit();

        Map<String, String> result = RenameCommand.on(repo).execute("x", "b");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("x", result.get(osSep("b/x")));
    }

    @Test
    public void testCopyDirToDir() throws IOException {
        Repository repo = getTestRepository();
        new File(repo.getDirectory(), "a").mkdir();
        new File(repo.getDirectory(), "b").mkdir();
        writeFile("a/x", "");
        commit();

        Map<String, String> result = RenameCommand.on(repo).execute("a", "b");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(osSep("a/x"), result.get(osSep("b/a/x")));
    }

    @Test
    public void testCopyDirToDirInDir() throws IOException {
        Repository repo = getTestRepository();
        new File(repo.getDirectory(), "a").mkdir();
        new File(repo.getDirectory(), "b/c").mkdirs();
        writeFile("a/x", "");
        commit();

        Map<String, String> result = RenameCommand.on(repo).execute("a", "b/c");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(osSep("a/x"), result.get(osSep("b/c/a/x")));
    }

    @Test
    public void testCopyMultipleFiles() throws IOException {
        Repository repo = getTestRepository();
        new File(repo.getDirectory(), "a").mkdir();
        writeFile("a/x", "");
        writeFile("a/y", "");
        writeFile("z", "");
        commit();

        new File(repo.getDirectory(), "dst").mkdir();
        Map<String, String> result = RenameCommand.on(repo).execute("z", "a", "dst");
        Assert.assertEquals(3, result.size());
        Assert.assertEquals(osSep("a/x"), result.get(osSep("dst/a/x")));
        Assert.assertEquals(osSep("a/y"), result.get(osSep("dst/a/y")));
        Assert.assertEquals("z", result.get(osSep("dst/z")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testOneFile() {
        Repository repo = getTestRepository();
        RenameCommand.on(repo).execute("a");
    }

    @Test(expected = NullPointerException.class)
    public void testNullPointer() {
        Repository repo = getTestRepository();
        RenameCommand.on(repo).execute((String[]) null);
    }

    @Test
    public void testCopyWithAfterFlag() throws IOException {
        Repository repo = getTestRepository();
        File dir = repo.getDirectory();
        writeFile("x", "");
        commit();
        new File(dir, "x").renameTo(new File(dir, "y"));

        Map<String, String> result = RenameCommand.on(repo).after().execute("x", "y");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("x", result.get("y"));
    }

    @Test
    public void testCopyAddedFile() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "");
        AddCommand.on(repo).execute();

        // The 'x has not been committed yet, so no copy data will be
        // stored for x.' message is sent on stderr and is notparsed
        // by execute.
        Map<String, String> result = RenameCommand.on(repo).execute("x", "y");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("x", result.get("y"));
    }

    /**
     * Return / with the OS specific file seperator
     * 
     * @param s
     * @return
     */
    private static String osSep(String s) {
        char osSep = File.separatorChar;
        return s.replace('/', osSep);
    }
}
