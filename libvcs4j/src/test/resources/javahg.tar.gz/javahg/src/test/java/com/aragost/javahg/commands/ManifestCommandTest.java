/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class ManifestCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        writeFile("b");
        commit();
        List<File> manifest = ManifestCommand.on(repo).execute();
        Assert.assertEquals(2, manifest.size());
        Assert.assertEquals("a", manifest.get(0).getName());
        Assert.assertEquals("b", manifest.get(1).getName());
    }

    @Test
    public void testSingleRevision() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        commit();
        writeFile("b");
        commit();
        ManifestCommand cmd = ManifestCommand.on(repo).rev("0");
        List<File> manifest = cmd.execute();
        Assert.assertEquals(1, manifest.size());
        Assert.assertEquals("a", manifest.get(0).getName());
    }

    @Test
    public void testAllRevisions() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        commit();
        deleteFile("a");
        commit();
        ManifestCommand cmd = ManifestCommand.on(repo).all();
        List<File> manifest = cmd.execute();
        Assert.assertEquals(1, manifest.size());
        Assert.assertEquals("a", manifest.get(0).getName());
    }

}
