/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.HgVersion;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class CommitCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "abc");

        CommitCommand commit = CommitCommand.on(repo);
        StatusCommand status = StatusCommand.on(repo);

        List<StatusLine> statusLines = status.lines();
        Assert.assertEquals(1, statusLines.size());
        Assert.assertEquals(StatusLine.Type.UNKNOWN, statusLines.get(0).getType());

        AddCommand.on(repo).execute();
        statusLines = status.lines();
        Assert.assertEquals(1, statusLines.size());
        Assert.assertEquals(StatusLine.Type.ADDED, statusLines.get(0).getType());

        commit.message("unit test").user("unit test");
        Changeset cset = commit.execute();
        Assert.assertEquals("unit test", cset.getUser());
        statusLines = status.lines();
        Assert.assertEquals(0, statusLines.size());

        Assert.assertNull(commit.execute());

    }

    @Test(expected = IllegalStateException.class)
    public void testNoMessage() {
        Repository repo = getTestRepository();
        CommitCommand.on(repo).execute();
    }

    @Test(expected = NullPointerException.class)
    public void testSetNullMessage() {
        Repository repo = getTestRepository();
        CommitCommand.on(repo).message(null);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNullDate() {
        Repository repo = getTestRepository();
        CommitCommand.on(repo).date(null);
    }

    @Test
    public void testAmend() throws IOException {
        Repository repo = getTestRepository();
        Assume.assumeTrue(HgVersion.fromString("2.2").isBefore(repo.getHgVersion()));

        writeFile("x", "abc");

        CommitCommand commit = CommitCommand.on(repo);
        StatusCommand status = StatusCommand.on(repo);

        List<StatusLine> statusLines = status.lines();
        Assert.assertEquals(1, statusLines.size());
        Assert.assertEquals(StatusLine.Type.UNKNOWN, statusLines.get(0).getType());

        AddCommand.on(repo).execute();

        commit.message("unit test").user("unit test");
        Changeset cset = commit.execute();
        Assert.assertEquals("unit test", cset.getUser());

        cset = commit.amend().message("unit test amended").execute();
        Assert.assertEquals("unit test amended", cset.getMessage());

        Assert.assertEquals(1, LogCommand.on(repo).execute().size());
    }
}
