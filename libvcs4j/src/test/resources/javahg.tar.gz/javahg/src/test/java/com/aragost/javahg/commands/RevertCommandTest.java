package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.test.AbstractTestCase;

public class RevertCommandTest extends AbstractTestCase {

    @Test
    public void testNothingToRevert() throws IOException {
        BaseRepository repo = getTestRepository();
        createChangeset();
        RevertCommand.on(repo).all().execute();
    }

    @Test
    public void testRevertToParent() throws IOException {
        BaseRepository repo = getTestRepository();
        writeFile("a", "a");
        commit();
        writeFile("a", "aa");
        RevertCommand.on(repo).execute("a");
        Assert.assertEquals("a", readFile("a"));
    }
}
