/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class UpdateCommandTest extends AbstractTestCase {

    @Test
    public void testWithMergeConflicts() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        Changeset csetA = commit();
        writeFile("b");
        writeFile("a");
        Changeset csetB = commit();
        UpdateResult result = UpdateCommand.on(repo).rev(csetA).execute();
        verifyResult(result, 1, 0, 1, 0);
        writeFile("a");
        result = UpdateCommand.on(repo).rev(csetB).execute();
        verifyResult(result, 1, 0, 0, 1);
    }

    @Test
    public void testWithMerge() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "1\n2\n3\n");
        Changeset csetA = commit();
        writeFile("b");
        writeFile("a", "11\n2\n3\n");
        Changeset csetB = commit();
        UpdateResult result = UpdateCommand.on(repo).rev(csetA).execute();
        verifyResult(result, 1, 0, 1, 0);
        writeFile("a", "1\n2\n\33\n");
        result = UpdateCommand.on(repo).rev(csetB).execute();
        verifyResult(result, 1, 0, 0, 1);
    }

    /**
     * This test has been ignored because it has been rewritten below in a non-interactive version that does not fail.
     * This test fails because of the assumption that the oracle will be used, which is not the case since the server is
     * configured to use a non-interactive merge tool.
     * <p>
     * TODO enable test when interactivity has been restored.
     * 
     * @throws IOException
     */
    @Test
    @Ignore
    public void testWithManifestMergeConflict() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        Changeset csetA = commit();
        writeFile("a");
        Changeset csetB = commit();
        UpdateResult result = UpdateCommand.on(repo).rev(csetA).execute();
        verifyResult(result, 1, 0, 0, 0);
        deleteFile("a");
        ManifestMergeOracle oracle = new ManifestMergeOracle();
        result = UpdateCommand.on(repo).rev(csetB).execute(oracle);
        Assert.assertEquals(1, oracle.getMissingAnswers().size());
        verifyResult(result, 1, 0, 0, 0);

    }

    /**
     * Scenario: a file receives two changes each followed by a commit (csetA and csetB). Then the file is deleted (from
     * the filesystem) and the repo is updated to csetB. Given that the file does not exist anymore (but it still
     * tracked!), a conflict about the one file that we're using in the test occurs and is unresolved.
     * <p>
     * See comment in {@link MergeCommandTest#testMergeCtxKeepDeleteConflict()}. I can't explain what causes the
     * conflict. My assumption is that hg considers a missing file as a zero-content file, ie a file that has has all
     * its lines deleted before being deleted itself.
     * <p>
     * <em>Javadoc retro-engineering: Amenel Voglozin, 2016-12-12.</em>
     * 
     * @throws IOException
     */
    @Test
    public void testWithManifestMergeConflictNonInteractive() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        Changeset csetA = commit();
        writeFile("a");
        Changeset csetB = commit();
        UpdateResult result = UpdateCommand.on(repo).rev(csetA).execute();
        verifyResult(result, 1, 0, 0, 0);
        deleteFile("a");
        ManifestMergeOracle oracle = new ManifestMergeOracle();
        result = UpdateCommand.on(repo).rev(csetB).execute(oracle);
        /*
         * TODO: uncomment the two lines after the effects of --tool internal:fail have been assessed and verified.
         */
        // Assert.assertEquals(1, oracle.getMissingAnswers().size());
        // verifyResult(result, 1, 0, 0, 0);
        verifyResult(result, 0, 0, 0, 1);
    }

    private static void verifyResult(UpdateResult r, int updated, int merged, int removed, int unresolved) {
        Assert.assertEquals("updated", updated, r.getUpdated());
        Assert.assertEquals("merged", merged, r.getMerged());
        Assert.assertEquals("removed", removed, r.getRemoved());
        Assert.assertEquals("unresolved", unresolved, r.getUnresolved());
    }

    /**
     * This test is ignored because it has been rewritten below. I have later on discovered that many of the unexpected
     * test failures and errors with Graft, Update and Merge (before I started this test fixing task) might well be
     * caused by the specifying of <code>--tool: internal:fail</code> at server startup.
     * <p>
     * After I've investigated the effects of that merge tool specification, I'll decide the best course of action to
     * adopt.<br>
     * Amenel Voglozin, 2016-12-28.
     * 
     * @throws IOException
     */
    @Test
    @Ignore
    public void testUpdateCrossesBranches() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        Changeset csetA = commit();
        writeFile("a");
        Changeset csetB = commit();

        UpdateCommand.on(repo).rev(csetA).execute();
        writeFile("a");

        commit();

        Assert.assertEquals(2, repo.getBaseRepository().heads().size());

        UpdateCommand.on(repo).rev(csetB).execute();
        UpdateCommand command = UpdateCommand.on(repo);

        try {
            command.execute();
            Assert.fail("Expected exception");
        } catch (ExecutionException e) {
            Assert.assertFalse(command.isSuccessful());
            Assert.assertTrue(command.crossedBranch());
        }
    }

    /**
     * This test is a variant of the {@link #testUpdateCrossesBranches()} for cases when the interactivity is disabled
     * and the merge tool is set to "internal:fail".
     * <p>
     * Scenario: a repo gets a first changeset (csetA) and a second one (csetB). csetB is therefore a descendant of
     * csetA. Then, from csetA, a third changeset (csetC) is added. csetC is also a descendant of csetA: the repo has
     * two heads. From csetC, an update to csetB (a sister changeset) must not change any files (from hg doc: "If the
     * changeset is not a descendant or ancestor of the working directory's parent, the update is aborted.") for csetB
     * is indeed a descendant of the parent (csetA) of the working copy (csetC).
     * <p>
     * We then prolong each of the existing heads (to csetB2 and csetC2). We get the following situation:
     * 
     * <pre>
     * csetA
     * |-- csetB -- csetB2
     * |-- csetC -- csetC2
     * </pre>
     * 
     * Then, updating from one line of ancestry (aka branch) to the other works fine. However, updating from any cset to
     * the tip (ie when no revision is specified) won't work: there is no single tip in the repo. The documentation says
     * this: “If no changeset is specified, update to the tip of the <em>current named branch</em> and move the active
     * bookmark (see hg help bookmarks)”. Since there's no single tip, hg plays it safe and reports that there are
     * multiple heads: it's a hint that a merge should be issued, there's nothing to update to. <br>
     * Amenel Voglozin, 2016-12-20.
     * 
     * @throws IOException
     */
    @Test
    public void testUpdateCrossesBranches2() throws IOException {
        // TODO: explicitly set the merge tool to internal:fail in this test
        Repository repo = getTestRepository();
        writeFile("a"); // contains 0
        Changeset csetA = commit();
        writeFile("a"); // now contains 1
        Changeset csetB = commit();

        UpdateCommand.on(repo).rev(csetA).execute(); // contains 0
        writeFile("a"); // contains 2

        Changeset csetC = commit();

        Assert.assertEquals(2, repo.getBaseRepository().heads().size());
        UpdateResult resultToB = UpdateCommand.on(repo).rev(csetB).execute();
        // the file contains 1 again due to the update to csetB
        Assert.assertEquals(0, resultToB.getMerged());
        Assert.assertEquals(0, resultToB.getRemoved());
        Assert.assertEquals(0, resultToB.getUnresolved());
        Assert.assertEquals(1, resultToB.getUpdated());

        writeFile("a"); // contains 3

        Changeset csetB2 = commit();

        UpdateResult resultToC = UpdateCommand.on(repo).rev(csetC).execute();
        // contains 2 again due to the update to csetC
        Assert.assertEquals(0, resultToC.getMerged());
        Assert.assertEquals(0, resultToC.getRemoved());
        Assert.assertEquals(0, resultToC.getUnresolved());
        Assert.assertEquals(1, resultToC.getUpdated());

        writeFile("a"); // contains 4
        Changeset csetC2 = commit();

        UpdateCommand.on(repo).rev(csetB);

        /*
         * Update to the tip: nothing will happen bc there's no single "tip" but hg will report the presence of multiple
         * heads.
         */
        UpdateCommand command = UpdateCommand.on(repo);
        UpdateResult result = command.execute();
        Assert.assertEquals(0, command.getReturnCode());
        Assert.assertTrue(result.hasMultipleHeads());
        Assert.assertEquals(0, result.getMerged());
        Assert.assertEquals(0, result.getRemoved());
        Assert.assertEquals(0, result.getUnresolved());
        Assert.assertEquals(0, result.getUpdated());
    }

    @Test
    public void testWithBookmarkLeave() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "1\n2\n3\n");
        Changeset csetA = commit();
        BookmarksCommand.on(repo).create("bmark");
        writeFile("b");
        writeFile("a", "11\n2\n3\n");
        commit();
        // leaving bookmark
        UpdateResult result = UpdateCommand.on(repo).rev(csetA).execute();
        verifyResult(result, 1, 0, 1, 0);
    }

    @Test
    public void testWithBookmarkActivate() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "1\n2\n3\n");
        commit();
        BookmarksCommand.on(repo).create("bmark");
        UpdateResult result = UpdateCommand.on(repo).rev("bmark").execute();
        verifyResult(result, 0, 0, 0, 0);
    }
}
