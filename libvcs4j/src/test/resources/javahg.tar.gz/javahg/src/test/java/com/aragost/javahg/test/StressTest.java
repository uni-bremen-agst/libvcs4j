/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.RepositoryConfiguration;
import com.aragost.javahg.commands.AddCommand;
import com.aragost.javahg.commands.CommitCommand;
import com.aragost.javahg.commands.ExecutionException;
import com.aragost.javahg.commands.LogCommand;
import com.aragost.javahg.commands.RemoveCommand;
import com.google.common.collect.Lists;
import com.google.common.io.Files;

/**
 * Stress test the system by running many threads sending commands to a repository.
 */
public class StressTest extends AbstractTestCase {

    private static final int CYCLES_PER_THREAD = 25;
    private static final int NUMBER_OF_THREADS = 20;
    private static volatile Random RANDOM = new Random(0);

    @Test
    public void stressTest() throws InterruptedException {
        BaseRepository repo = getTestRepository();
        Stats stats = new Stats();
        List<StressThread> threads = Lists.newArrayList();
        for (int i = 0; i < NUMBER_OF_THREADS; i++) {
            StressThread t = new StressThread(CYCLES_PER_THREAD, i, stats, repo);
            t.start();
            threads.add(t);
        }

        for (StressThread cycleThread : threads) {
            cycleThread.join();
        }
        Assert.assertEquals(2 * CYCLES_PER_THREAD * NUMBER_OF_THREADS, stats.changes + stats.noChanges);
        System.err.println("Cache stats: " + repo.getCacheStats());
    }

    @Test
    public void stressTestConcurrency() throws InterruptedException, IOException {
        RepositoryConfiguration conf = makeRepoConf();
        conf.setConcurrency(3);
        BaseRepository repo = Repository.create(conf, Files.createTempDir());

        Stats stats = new Stats();
        List<StressThread> threads = Lists.newArrayList();

        // Write some initial changesets
        writeFile(repo, "a", "123");
        AddCommand.on(repo).execute();
        CommitCommand.on(repo).message("a").user("setup").execute();
        writeFile(repo, "b", "123");
        AddCommand.on(repo).execute();
        CommitCommand.on(repo).message("b").user("setup").execute();
        writeFile(repo, "c", "123");
        AddCommand.on(repo).execute();
        CommitCommand.on(repo).message("c").user("setup").execute();

        for (int i = 0; i < NUMBER_OF_THREADS; i++) {
            StressThread t = new StressThread2(CYCLES_PER_THREAD * 10, i, stats, repo);
            t.start();
            threads.add(t);
        }

        for (StressThread cycleThread : threads) {
            cycleThread.join();
        }
        Assert.assertEquals(20 * CYCLES_PER_THREAD * NUMBER_OF_THREADS, stats.changes + stats.noChanges);
        System.err.println("Cache stats: " + repo.getCacheStats());
    }

    static String randomString(int length) {
        StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            builder.append((char) ('a' + RANDOM.nextInt(26)));
        }
        return builder.toString();
    }

    class StressThread extends Thread {

        private int count;
        protected final int threadId;
        protected final Stats stats;
        protected final BaseRepository repo;

        public StressThread(int count, int threadId, Stats stats, BaseRepository repo) {
            this.count = count;
            this.threadId = threadId;
            this.stats = stats;
            this.repo = repo;
        }

        @Override
        public void run() {
            for (int i = 0; i < this.count; i++) {
                try {
                    performCycle();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        protected void performCycle() throws IOException {
            String newFile = randomString(1);
            String fileContent = randomString(20);
            writeFile(repo, newFile, fileContent);
            AddCommand.on(repo).execute();
            CommitCommand commitCmd = CommitCommand.on(repo).user("thread: " + this.threadId).message(
                    "msg: " + this.threadId);
            Changeset x = commitCmd.execute();
            if (x != null) {
                Changeset y = repo.changeset(x.getNode());
                Assert.assertSame(x, y);
                stats.incChanges();
            } else {
                // Change committed by other thread
                stats.incNoChanges();
            }

            File file = new File(repo.getDirectory(), randomString(1));
            try {
                RemoveCommand.on(repo).execute(file.getPath());
            } catch (ExecutionException e) {
                // The file did not exist. Maybe it never existed, or
                // maybe it was deleted by another Mercurial process.
                // Note that even if we check for existence before
                // calling 'hg remove', then another thread might
                // delete it before Mercurial and thus cause an error.
            }

            commitCmd.execute();
            if (commitCmd.getReturnCode() == 1) {
                // Change committed by other thread
                stats.incNoChanges();
            } else {
                stats.incChanges();
            }

        }
    }

    class StressThread2 extends StressThread {

        public StressThread2(int count, int threadId, Stats stats, BaseRepository repo) {
            super(count, threadId, stats, repo);
        }

        @Override
        protected void performCycle() throws IOException {
            if (threadId == 0) {
                super.performCycle();
            } else {
                LogCommand.on(repo).limit(3);
                stats.incChanges();
                stats.incChanges();
            }
        }
    }

    static class Stats {
        int noChanges = 0;
        int changes = 0;

        synchronized void incNoChanges() {
            this.noChanges++;
        }

        synchronized void incChanges() {
            this.changes++;
        }
    }
}
