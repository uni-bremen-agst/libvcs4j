/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class LogCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "abc");

        LogCommand log = LogCommand.on(repo);
        CommitCommand commit = CommitCommand.on(repo);
        AddCommand.on(repo).execute();

        commit.message("line1\nline2\nX").user("user").execute();

        writeFile("x", "ABC");
        commit.message("Line1\nLine2\n").user("USER").execute();

        List<Changeset> changesets = log.execute();

        Assert.assertEquals(2, changesets.size());
        Changeset cs = changesets.get(1);
        Assert.assertEquals("user", cs.getUser());
        Assert.assertEquals("line1\nline2\nX", cs.getMessage());
        Assert.assertEquals("x", cs.getAddedFiles().get(0));

        cs = changesets.get(0);
        Assert.assertEquals("USER", cs.getUser());
        Assert.assertEquals("Line1\nLine2", cs.getMessage());
        Assert.assertEquals("x", cs.getModifiedFiles().get(0));
    }

    @Test
    public void testLimit() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        commit();
        writeFile("b");
        commit();
        List<Changeset> log = LogCommand.on(repo).limit(1).execute();
        Assert.assertEquals(1, log.size());
    }

    @Test
    public void testEagerLoading() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "abc");
        AddCommand.on(repo).execute();
        Changeset c = CommitCommand.on(repo).user("test").message("added file a").execute();
        String nodeId = c.getNode();
        c = LogCommand.on(repo).fileStatus().rev(nodeId).single();
        Assert.assertEquals("a", c.getAddedFiles().get(0));
    }

}
