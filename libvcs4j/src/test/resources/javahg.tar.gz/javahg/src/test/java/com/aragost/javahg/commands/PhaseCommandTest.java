package com.aragost.javahg.commands;

import static com.aragost.javahg.Phase.DRAFT;
import static com.aragost.javahg.Phase.PUBLIC;
import static com.aragost.javahg.Phase.SECRET;

import java.io.IOException;

import org.junit.Assume;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.UnknownCommandException;
import com.aragost.javahg.test.AbstractTestCase;

import junit.framework.Assert;

public class PhaseCommandTest extends AbstractTestCase {

    private boolean isPhasesSupported() {
        BaseRepository repo = getTestRepository();
        try {
            PhaseCommand.on(repo).rev(Changeset.NULL_ID).execute();
            return true;
        } catch (UnknownCommandException e) {
            return false;
        }
    }

    @Test
    public void test() throws IOException {
        Assume.assumeTrue(isPhasesSupported());
        BaseRepository repo = getTestRepository();
        Changeset cs1 = createChangeset();
        Changeset cs2 = createChangeset();
        Assert.assertEquals(DRAFT, cs1.phase());
        Assert.assertEquals(DRAFT, cs2.phase());
        PhaseCommand cmd = PhaseCommand.on(repo).pub().rev(cs2.getNode());
        cmd.execute();
        Assert.assertEquals(PUBLIC, cs1.phase());
        Assert.assertEquals(PUBLIC, cs2.phase());

        cmd = PhaseCommand.on(repo).secret().rev(cs2.getNode());
        Assert.assertFalse(cmd.execute());
        Assert.assertEquals(PUBLIC, cs1.phase());
        Assert.assertEquals(PUBLIC, cs2.phase());

        cmd = PhaseCommand.on(repo).secret().force().rev(cs1.getNode());
        Assert.assertTrue(cmd.execute());
        Assert.assertEquals(SECRET, cs1.phase());
        Assert.assertEquals(SECRET, cs2.phase());

        cmd = PhaseCommand.on(repo).pub().force().rev(cs1.getNode());
        cmd.execute();
        Assert.assertEquals(PUBLIC, cs1.phase());
        Assert.assertEquals(SECRET, cs2.phase());
    }

    /**
     * Scenario: We create a changeset in a repo. The cset is normally created in the "draft" phase. We explicitly move
     * the changeset to the to the draft phase, which is a noop. We then check that the changeset remained in "draft"
     * phase.
     */
    @Test
    public void testPhaseDraftToDraftMakesNoChanges() throws IOException {
        Assume.assumeTrue(isPhasesSupported());
        BaseRepository repo = getTestRepository();

        Changeset cs = createChangeset();

        PhaseCommand cmd1 = PhaseCommand.on(repo);
        boolean b1 = cmd1.execute();
        Assert.assertEquals("0: draft\n", cmd1.getOutputString());
        Assert.assertEquals(DRAFT, cs.phase());
        Assert.assertTrue(b1);

        // hg 4.0.1 reports 0 (success).
        PhaseCommand cmd2 = PhaseCommand.on(repo).draft().rev(cs.getNode());
        Assert.assertTrue(cmd2.execute());
        Assert.assertTrue("".equals(cmd2.getOutputString()));
        Assert.assertEquals(DRAFT, cs.phase());

        PhaseCommand cmd3 = PhaseCommand.on(repo);
        Assert.assertTrue(cmd3.execute());
        Assert.assertEquals("0: draft\n", cmd3.getOutputString());
        Assert.assertEquals(DRAFT, cs.phase());
    }

    @Test
    public void testPhasesWhenPhasesNotSupported() throws IOException {
        Assume.assumeTrue(!isPhasesSupported());
        Changeset cs = createChangeset();
        Assert.assertNull(cs.phase());
    }

    @Test
    public void testPhasesUnknownRev() throws IOException {
        Assume.assumeTrue(isPhasesSupported());

        createChangeset();

        Repository repo = getTestRepository();

        try {
            repo.phases("abcdef124");
        } catch (ExecutionException e) {
            // Testing invalid phase name. The exception is expected.
        }

        try {
            repo.phases("abcdef124");
        } catch (ExecutionException e) {
            // Testing invalid phase name. The exception is expected.
        }

        try {
            repo.phases("abcdef124");
        } catch (ExecutionException e) {
            // Testing invalid phase name. The exception is expected.
        }

        try {
            repo.phases("abcdef124");
        } catch (ExecutionException e) {
            // Testing invalid phase name. The exception is expected.
        }
    }
}
