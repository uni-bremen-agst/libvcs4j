###
# #%L
# JavaHg
# %%
# Copyright (C) 2012 aragost Trifork ag
# %%
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# #L%
###

# Helper functions for JavaHg.
#
# Copyright 2012 aragost Trifork

import os, sys, struct
from mercurial import util, cmdutil

"""Helper extension for testing JavaHg"""

cmdtable = {}
command = cmdutil.command(cmdtable)

@command('javahg-abort', [])
def abort(ui, repo):
    """simply abort"""
    raise util.Abort("crash")

@command('javahg-write', [])
def error(ui, repo, channel, msg):
    """write message to the given channel"""
    sys.stdout.write(channel)
    sys.stdout.write(struct.pack('>I', len(msg)))
    sys.stdout.write(msg)
    sys.stdout.flush()

@command('javahg-stdout', [])
def stderr(ui, repo, msg):
    """write message to sys.stdout

    This will most likely corrupt the command server protocol.
    """
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()

@command('javahg-stderr', [])
def stderr(ui, repo, msg):
    """write message to sys.stderr"""
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()

@command('javahg-hang', [])
def hang(ui, repo):
    """go into an infinite loop"""
    while True:
        pass

@command('javahg-throw', [])
def throw(ui, repo):
    """throw an exception, crashing the command server"""
    raise Exception("an unhandled exception")

@command('javahg-exit', [])
def exit(ui, repo, msg):
    """promise to write message twice, but crash mid way"""
    sys.stdout.write('o')
    sys.stdout.write(struct.pack('>I', len(msg) * 2))
    sys.stdout.write(msg)
    sys.stdout.flush()
    os._exit(200)
