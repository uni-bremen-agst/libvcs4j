/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.internals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.CharsetDecoder;

import org.junit.Test;

import com.aragost.javahg.test.AbstractTestCase;

import junit.framework.Assert;

public class HgInputStreamTest extends AbstractTestCase {

    @Test
    public void testUpToNoMatch() throws IOException {
        HgInputStream stream = createStream("abcc");
        byte[] bytes = stream.upTo("ccc".getBytes());
        Assert.assertNull(bytes);
    }

    @Test
    public void testUpToMatch() throws IOException {
        HgInputStream stream = createStream("aaaaab");
        String s = new String(stream.upTo("aaab".getBytes()));
        Assert.assertEquals("aa", s);
    }

    @Test
    public void testMatch() throws IOException {
        HgInputStream stream = createStream("aaa");
        boolean match = stream.match("aa".getBytes());
        Assert.assertTrue(match);
    }

    @Test
    public void testPeek() throws IOException {
        HgInputStream stream = createStream("a");
        Assert.assertEquals('a', stream.peek());
        Assert.assertEquals('a', stream.read());
        Assert.assertEquals(-1, stream.peek());
        Assert.assertEquals(-1, stream.peek());
    }

    @Test
    public void testReadDecimal() throws IOException {
        HgInputStream stream = createStream("");
        Assert.assertNull(stream.readDecimal());
        Assert.assertEquals(-1, stream.read());

        stream = createStream("0");
        Assert.assertEquals(Integer.valueOf(0), stream.readDecimal());
        Assert.assertEquals(-1, stream.read());

        stream = createStream("1234321.");
        Assert.assertEquals(Integer.valueOf(1234321), stream.readDecimal());
        Assert.assertEquals('.', stream.read());

    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindEmptyInEmptyStream() throws IOException {
        HgInputStream stream = createStream("");
        stream.find(new byte[0]);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindEmptyInNonEmptyStream() throws IOException {
        HgInputStream stream = createStream("aaa");
        stream.find(new byte[0]);
    }

    @Test
    public void testFindInEmptyStream() throws IOException {
        HgInputStream stream = createStream("");
        boolean found = stream.find("a".getBytes());
        Assert.assertFalse(found);
        Assert.assertTrue(stream.isEof());
    }

    @Test
    public void testFindNoMatch() throws IOException {
        HgInputStream stream = createStream("abccde");
        boolean found = stream.find("ccc".getBytes());
        Assert.assertFalse(found);
        Assert.assertTrue(stream.isEof());
    }

    @Test
    public void testFindMatchAtEof() throws IOException {
        HgInputStream stream = createStream("aaaaab");
        boolean found = stream.find("aab".getBytes());
        Assert.assertTrue(found);
        Assert.assertTrue(stream.isEof());
    }

    @Test
    public void testFindMatch() throws IOException {
        HgInputStream stream = createStream("aaaaabc");
        boolean found = stream.find("aab".getBytes());
        Assert.assertTrue(found);
        Assert.assertFalse(stream.isEof());
        Assert.assertEquals("c", Utils.readStream(stream, utf8().newDecoder()));
    }

    private HgInputStream createStream(String s) {
        CharsetDecoder decoder = utf8().newDecoder();
        return new HgInputStream(new ByteArrayInputStream(s.getBytes()), decoder);
    }
}
