/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.DateTime;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class ExportCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();

        CommitCommand commit = CommitCommand.on(repo);
        commit.user("user").date(DateTime.parse("0 0"));

        writeFile("x", "abc\n");

        AddCommand.on(repo).execute();
        commit.message("added x").execute();

        // @formatter:off
        String expected = ""
                + "# HG changeset patch\n"
                + "# User user\n"
                + "# Date 0 0\n"
                + "#      Thu Jan 01 00:00:00 1970 +0000\n"
                + "# Node ID 028afe402311268f473457f6c835052dd94f1d2b\n"
                + "# Parent  0000000000000000000000000000000000000000\n"
                + "added x\n"
                + "\n"
                + "diff --git a/x b/x\n"
                + "new file mode 100644\n"
                + "--- /dev/null\n"
                + "+++ b/x\n"
                + "@@ -0,0 +1,1 @@\n"
                + "+abc\n";
        // @formatter:on

        String patch = ExportCommand.on(repo).execute(0);
        Assert.assertEquals(expected, patch);

    }

}
