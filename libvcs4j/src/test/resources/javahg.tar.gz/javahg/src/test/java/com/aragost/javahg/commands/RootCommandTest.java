package com.aragost.javahg.commands;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class RootCommandTest extends AbstractTestCase {

    @Test
    public void test() {
        Repository repoA = getTestRepository();

        RootCommand root = RootCommand.on(repoA);
        assertEquals(repoA.getDirectory().getAbsolutePath(), root.execute());
    }

}
