/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class AddCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");
        new File(repo.getDirectory(), "dir").mkdir();
        writeFile("dir/a", "");
        writeFile("dir/b", "");

        List<File> files = AddCommand.on(repo).execute(new File("dir"));
        Assert.assertEquals(2, files.size());
        Assert.assertTrue(files.get(0).isAbsolute());
        Assert.assertEquals(repoFile(repo, "dir", "a"), files.get(0));
        Assert.assertEquals(repoFile(repo, "dir", "b"), files.get(1));
    }

    @Test
    public void testAlreadyTracked() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");

        AddCommand addCommand = AddCommand.on(repo);
        addCommand.execute();
        addCommand.execute("a");
        Assert.assertEquals("a already tracked!\n", addCommand.getErrorString());
        addCommand.execute();
        Assert.assertEquals("", addCommand.getErrorString());
    }

    /**
     * Scenario: We execute the add command by specifying a file that does not exist. This will cause 0 additions and
     * will generate an error message.
     * <p>
     * The error message typically starts with the name of the file in error.
     */
    @Test
    public void testNoSuchFile() {
        Repository repo = getTestRepository();

        AddCommand addCommand = AddCommand.on(repo);
        List<String> files = addCommand.execute("a");
        Assert.assertEquals(0, files.size());
        Assert.assertTrue(addCommand.getErrorString().startsWith("a: "));
    }
}
