/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Bundle;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class IncomingCommandTest extends AbstractTestCase {

    @Test
    public void testEmpty() {
        Repository repo = getTestRepository();
        Repository repo2 = getTestRepository2();

        Bundle bundle = IncomingCommand.on(repo).execute(repo2.getDirectory().getPath());
        Assert.assertNull(bundle);
    }

    @Test
    public void testNonEmpty() throws IOException {
        Repository repo = getTestRepository();
        Changeset cs0 = createChangeset();
        Changeset cs1 = createChangeset();

        Repository repo2 = getTestRepository2();

        Bundle bundle = IncomingCommand.on(repo2).execute(repo);
        List<Changeset> changesets = bundle.getChangesets();
        Assert.assertEquals(2, changesets.size());
        // The changesets are not the same objects, because one set is
        // in the base repo, while the other set is in the overlay
        // repo
        Assert.assertEquals(cs0.getNode(), changesets.get(0).getNode());
        Assert.assertEquals(cs1.getNode(), changesets.get(1).getNode());
        Changeset bundleCs = changesets.get(0);
        Assert.assertNotSame(cs0, bundleCs);
        Assert.assertFalse(cs0.equals(bundleCs));
        bundle.close();
    }

    @Test
    public void testHTTPIncoming() throws IOException {
        Repository repoA = getTestRepository();

        writeFile("x", "abc");

        AddCommand add = AddCommand.on(repoA);
        add.execute();

        CommitCommand commit = CommitCommand.on(repoA);
        commit.message("added x").user("user");
        commit.execute();

        ServeState serveState = startServing(repoA);
        try {
            int port = serveState.getPort();

            Repository repoB = getTestRepository2();
            Bundle b = IncomingCommand.on(repoB).execute("http://localhost:" + port);
            List<Changeset> changesets = b.getChangesets();
            Assert.assertEquals(1, changesets.size());
            Changeset cs = changesets.get(0);
            Assert.assertEquals("user", cs.getUser());
            Assert.assertEquals("added x", cs.getMessage());

            List<Changeset> heads = b.getOverlayRepository().heads();
            Assert.assertEquals(1, heads.size());
            Assert.assertEquals(cs, heads.get(0));
        } finally {
            serveState.stop();
        }
    }
}
