/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.test.AbstractTestCase;
import com.google.common.io.Files;

public class PushCommandTest extends AbstractTestCase {

    @Test
    public void testEmptyPush() throws IOException {
        Repository repo = getTestRepository();
        File dir = getTestRepository2().getDirectory();

        List<Changeset> changesets = PushCommand.on(repo).execute(dir.getPath());
        Assert.assertEquals(0, changesets.size());
    }

    @Test
    public void testPush() throws IOException {
        Repository repoA = getTestRepository();
        Changeset a = createChangeset();

        File dirB = createMercurialRepository();

        List<Changeset> changesets = PushCommand.on(repoA).execute(dirB.getPath());
        // Mercurial 3.1.1 returns more than one changeset so we care that the first is the
        // expected one
        // not sure when the change happened between 2.8.1 and 3.1.1
        Changeset b = Utils.first(changesets);
        Assert.assertSame(a, b);

        deleteTempDir(dirB);
    }

    @Test(expected = ExecutionException.class)
    public void testPushWithNoDefault() throws IOException {
        Repository repo = getTestRepository();
        PushCommand.on(repo).execute();
    }

    @Test(expected = NullPointerException.class)
    public void testPushNullSource() throws IOException {
        Repository repo = getTestRepository();
        PushCommand.on(repo).execute(null);
    }

    /**
     * Scenario: On a first repo (repoA), some activity is done. A second repo (repoB) is created from cloning the first
     * one. repoA gets more activity, just like repoB does. Then a push command is issued from repoA to repoB, which,
     * due to both repos having seen some non-sync'ed/ non-merged activity, creates two heads and must make the command
     * fail.
     * <p>
     * The push is then forced, which will indeed create two heads in repoB.
     */
    @Test
    public void testPushCreatingNewHead() throws IOException {
        Repository repoA = getTestRepository();
        Changeset base = createChangeset();

        File dir = createTempDir();
        BaseRepository repoB = Repository.clone(dir, repoA.getDirectory().getPath());

        Changeset a = createChangeset();
        update(base);
        Changeset b = createChangeset();

        Files.write("a".getBytes(), new File(repoB.getDirectory(), "file"));
        AddCommand.on(repoB).execute();
        CommitCommand.on(repoB).message("m").user("u").execute();
        PushCommand push = PushCommand.on(repoA);
        try {
            push.execute(repoB.getDirectory().getPath());
            assertFailedExecution(push);
        } catch (ExecutionException e) {
            Assert.assertTrue(e.getMessage().startsWith("push creates new remote head"));
        }

        List<Changeset> changesets = PushCommand.on(repoA).force().execute(repoB.getDirectory().getPath());
        Assert.assertEquals(2, changesets.size());
        Assert.assertTrue(changesets.contains(a));
        Assert.assertTrue(changesets.contains(b));

        repoB.close();
        deleteTempDir(dir);
    }
}
