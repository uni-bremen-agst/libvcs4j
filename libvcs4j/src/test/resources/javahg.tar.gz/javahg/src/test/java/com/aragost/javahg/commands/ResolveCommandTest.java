/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class ResolveCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "a");
        writeFile("b", "b");
        writeFile("c", "c");
        Changeset csBase = commit();
        writeFile("a", "A");
        writeFile("b", "B");
        commit();
        update(csBase);
        writeFile("a", "1");
        writeFile("b", "2");
        commit();

        MergeCommand.on(repo).execute(new ManifestMergeOracle());
        ResolveCommand resolveCommand = ResolveCommand.on(repo);

        List<ResolveStatusLine> list = resolveCommand.list();
        Assert.assertEquals(2, list.size());

        resolveCommand.mark("b");
        list = resolveCommand.list();
        Assert.assertEquals(2, list.size());
        Assert.assertEquals("a", list.get(0).getFileName());
        Assert.assertEquals("b", list.get(1).getFileName());
        Assert.assertEquals(ResolveStatusLine.Type.UNRESOLVED, list.get(0).getType());
        Assert.assertEquals(ResolveStatusLine.Type.RESOLVED, list.get(1).getType());

    }
}
