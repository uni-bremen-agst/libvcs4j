package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Test;

import com.aragost.javahg.HgVersion;
import com.aragost.javahg.Repository;
import com.aragost.javahg.UnknownCommandException;
import com.aragost.javahg.internals.AbstractCommand;
import com.aragost.javahg.test.AbstractTestCase;

import junit.framework.Assert;

public class AbstractCommandTest extends AbstractTestCase {

    @Test
    public void testGetErrorStringTwice() throws IOException {
        Repository repo = getTestRepository();
        // For mercurial 3.1.1 we need at least one changeset in the repository to produce the
        // expected error.
        // Not sure when that changed between 2.8.1 and 3.1.1
        createChangeset();
        LogCommand cmd = LogCommand.on(repo).branch("no such branch");
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (ExecutionException e) {
            String errorString1 = cmd.getErrorString();
            String errorString2 = cmd.getErrorString();
            Assert.assertEquals(errorString1, errorString2);
        }
    }

    @Test
    public void testUnknownCommand() {
        Repository repo = getTestRepository();
        HgVersion hgVersion = repo.getHgVersion();
        DummyTestCommand cmd = new DummyTestCommand(repo);

        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (UnknownCommandException e) {
            Assert.assertSame(cmd, e.getCommand());
            Assert.assertTrue(e.getMessage().indexOf(hgVersion.getVersionString()) >= 0);
        }

    }

}

class DummyTestCommand extends AbstractCommand {

    protected DummyTestCommand(Repository repository) {
        super(repository);
    }

    public void execute() {
        launchString();
    }

    @Override
    public String getCommandName() {
        return "unsupportedCommand";
    }

}
