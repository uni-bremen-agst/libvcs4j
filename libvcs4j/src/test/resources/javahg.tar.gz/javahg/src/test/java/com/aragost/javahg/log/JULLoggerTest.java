package com.aragost.javahg.log;

import static com.aragost.javahg.log.JULLogger.format;

import org.junit.Assert;
import org.junit.Test;

public class JULLoggerTest {

    @Test
    public void testFormat() {
        Assert.assertEquals("", format("", new Object[0]));
        Assert.assertEquals("abc", format("abc", new Object[] { null }));
        Assert.assertEquals("ab", format("{}{}{}", new Object[] { "a", null, "b" }));
        Assert.assertEquals("a1b2c3d", format("a{}b{}c{}d", new Object[] { 1, 2, 3, 4, 5, 6 }));
    }

}
