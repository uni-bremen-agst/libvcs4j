package com.aragost.javahg.internals;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.commands.PushCommand;
import com.aragost.javahg.test.AbstractTestCase;

public class JavaHgMercurialExtensionTest extends AbstractTestCase {

    volatile boolean inPush = false;

    @Test
    public void testLock() throws InterruptedException {
        final BaseRepository repo = getTestRepository2();
        GenericCommand lockCmd = new GenericCommand(repo, "javahg-lock");
        GenericCommand unlockCmd = new GenericCommand(repo, "javahg-unlock");
        lockCmd.execute();

        Thread thread = new Thread("otherrepo") {
            @Override
            public void run() {
                try {
                    JavaHgMercurialExtensionTest.this.inPush = true;
                    BaseRepository other = getTestRepository();
                    createChangeset();
                    PushCommand.on(other).execute(repo.getDirectory().getAbsolutePath());
                    JavaHgMercurialExtensionTest.this.inPush = false;
                } catch (IOException e) {
                    throw new RuntimeIOException(e);
                }
            }
        };
        thread.start();
        Thread.sleep(1500);
        Assert.assertTrue(this.inPush);
        unlockCmd.execute();
        Thread.sleep(1500);
        Assert.assertFalse(this.inPush);
        thread.join();
        Assert.assertEquals(0, repo.tip().getRevision());
    }

}
