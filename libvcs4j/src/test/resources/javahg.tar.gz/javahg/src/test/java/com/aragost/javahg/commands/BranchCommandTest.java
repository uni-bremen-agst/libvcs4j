/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.test.AbstractTestCase;

public class BranchCommandTest extends AbstractTestCase {

    @Test
    public void testSet() throws IOException {
        BaseRepository repo = getTestRepository();
        BranchCommand.on(repo).set("x");
        Changeset cs = commit();
        Assert.assertEquals("x", cs.getBranch());
    }

    @Test
    public void testGet() throws IOException {
        BaseRepository repo = getTestRepository();
        Assert.assertEquals("default", BranchCommand.on(repo).get());
        BranchCommand.on(repo).set("x");
        Assert.assertEquals("x", BranchCommand.on(repo).get());
        commit();
        Assert.assertEquals("x", BranchCommand.on(repo).get());
    }

    @Test
    public void testClean() throws IOException {
        BaseRepository repo = getTestRepository();
        BranchCommand.on(repo).set("x");
        String oldName = BranchCommand.on(repo).clean();
        Assert.assertEquals("default", oldName);

        BranchCommand.on(repo).set("y");
        commit();
        oldName = BranchCommand.on(repo).clean();
        Assert.assertEquals("y", oldName);
        BranchCommand.on(repo).set("z");
        oldName = BranchCommand.on(repo).clean();
        Assert.assertEquals("y", oldName);
    }
}
