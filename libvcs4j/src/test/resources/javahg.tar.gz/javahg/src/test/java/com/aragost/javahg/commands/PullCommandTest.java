/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;
import com.google.common.io.Files;

public class PullCommandTest extends AbstractTestCase {

    @Test
    public void testEmptyPull() throws IOException {
        Repository repo = getTestRepository();
        File dir = repo.getDirectory();

        List<Changeset> changesets = PullCommand.on(repo).execute(dir.getPath());
        Assert.assertEquals(0, changesets.size());
    }

    /**
     * Scenario: A repository (repoA) gets one commit with a given user name and commit message. A second repository is
     * created and pulls all change sets from repoA. We check that the history pulled into B matches the one that was
     * created on A.
     */
    @Test
    public void testPull() throws IOException {
        Repository repoA = getTestRepository();
        File dirA = repoA.getDirectory();

        writeFile("x", "abc");

        AddCommand add = AddCommand.on(repoA);
        add.execute();

        CommitCommand commit = CommitCommand.on(repoA);
        commit.message("added x").user("user");
        commit.execute();

        Repository repoB = getTestRepository2();

        List<Changeset> changesets = PullCommand.on(repoB).execute(dirA.getPath());
        Assert.assertEquals(1, changesets.size());
        Changeset cs = changesets.get(0);
        Assert.assertEquals("user", cs.getUser());
        Assert.assertEquals("added x", cs.getMessage());
    }

    @Test
    public void testHTTPPull() throws IOException {
        Repository repoA = getTestRepository();

        writeFile("x", "abc");

        AddCommand add = AddCommand.on(repoA);
        add.execute();

        CommitCommand commit = CommitCommand.on(repoA);
        commit.message("added x").user("user");
        commit.execute();

        ServeState serveState = startServing(repoA);
        try {
            int port = serveState.getPort();

            Repository repoB = getTestRepository2();
            List<Changeset> changesets = PullCommand.on(repoB).execute("http://localhost:" + port);
            Assert.assertEquals(1, changesets.size());
            Changeset cs = changesets.get(0);
            Assert.assertEquals("user", cs.getUser());
            Assert.assertEquals("added x", cs.getMessage());
        } finally {
            serveState.stop();
        }
    }

    @Test(expected = ExecutionException.class)
    public void testPullWithNoDefault() throws IOException {
        Repository repo = getTestRepository();
        PullCommand.on(repo).execute();
    }

    @Test(expected = NullPointerException.class)
    public void testPullNullSource() throws IOException {
        Repository repo = getTestRepository();
        PullCommand.on(repo).execute(null);
    }

    @Test
    public void testWithDivergingBookmarks() throws IOException {
        Repository repo1 = getTestRepository();
        createChangeset();
        BookmarksCommand.on(repo1).create("bm");
        BookmarksCommand.on(repo1).list();

        File cloneDir = Files.createTempDir();
        Repository clone = Repository.clone(cloneDir, repo1.getDirectory().getAbsolutePath());
        Assert.assertEquals(1, BookmarksCommand.on(clone).list().size());

        Files.write("abc".getBytes(), new File(cloneDir, "clone"));
        AddCommand.on(clone).execute("clone");
        CommitCommand.on(clone).user("user").message("m").execute();
        BookmarksCommand.on(clone).force().create("bm");
        BookmarksCommand.on(clone).list();

        createChangeset();

        PullCommand.on(repo1).execute(clone.getDirectory().getAbsolutePath());
        BookmarksCommand.on(repo1).list();

        clone.close();
        deleteTempDir(cloneDir);
    }
}
