package com.aragost.javahg.internals;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.Maps;

public class PatternReplacingOutputStreamTest {

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final Map<String, byte[]> REPLACEMENTS = Maps.newHashMap();
    static {
        REPLACEMENTS.put("one", "1".getBytes());
        REPLACEMENTS.put("two", "2".getBytes());
        REPLACEMENTS.put("three", "3".getBytes());
    }

    @Test
    public void test() throws IOException {
        assertFilter("", "");
        assertFilter("abc", "abc");
        assertFilter("1 2 3", "%{one} %{two} %{three}");
        assertFilter("A%{B}{C", "A%%{B}{C");
        assertFilter("1%{%{two=null}}", "%{one}%{%{two}}%{three");
    }

    private static void assertFilter(String expected, String input) throws IOException {
        String filtered = filter(input);
        Assert.assertEquals(expected, filtered);
    }

    private static String filter(String s) throws IOException {
        byte[] bytes = s.getBytes("UTF-8");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PatternReplacingOutputStream out = new PatternReplacingOutputStream(baos, REPLACEMENTS);
        out.write(bytes);
        out.flush();
        String res = Utils.decodeBytes(baos.toByteArray(), UTF8.newDecoder());
        out.close();
        return res;
    }
}
