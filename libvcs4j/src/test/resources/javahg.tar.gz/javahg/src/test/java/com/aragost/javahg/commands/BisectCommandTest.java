/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class BisectCommandTest extends AbstractTestCase {

    @Test
    public void testBisect() throws IOException {
        Repository repo = getTestRepository();

        writeFile("a");
        Changeset start = commit();
        writeFile("a");
        commit();
        writeFile("a");
        commit();
        writeFile("a");
        Changeset target = commit();
        writeFile("a");
        commit();
        writeFile("a");
        commit();

        Assert.assertFalse(BisectCommand.on(repo).good().execute(start.getNode()).isComplete());
        Assert.assertFalse(BisectCommand.on(repo).bad().execute().isComplete());

        BisectResult result = null;

        do {
            if (repo.workingCopy().getParent1().getRevision() < target.getRevision()) {
                result = BisectCommand.on(repo).good().execute();
            } else {
                result = BisectCommand.on(repo).bad().execute();
            }
        } while (!result.isComplete());

        Assert.assertTrue(result.getMessage().contains("3:" + target.getNode().substring(0, 12)));
    }

}
