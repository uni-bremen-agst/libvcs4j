/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import static org.junit.Assume.assumeTrue;

import java.io.File;
import java.io.IOException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.MalformedInputException;
import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.HgVersion;
import com.aragost.javahg.Repository;
import com.aragost.javahg.internals.RuntimeIOException;
import com.aragost.javahg.test.AbstractTestCase;
import com.google.common.collect.Sets;
import com.google.common.io.Files;

public class StatusCommandTest extends AbstractTestCase {

    @Test
    public void testSimple() throws IOException {
        setup();

        List<StatusLine> status = StatusCommand.on(getTestRepository()).lines();
        Assert.assertEquals(2, status.size());
    }

    @Test
    public void testAllFlag() throws IOException {
        Repository repo = getTestRepository();
        writeFile(".hgignore", "");
        writeFile("modified");
        writeFile("removed");
        writeFile("clean");
        writeFile("missing");
        commit();
        writeFile("modified", "new content");
        RemoveCommand.on(repo).execute("removed");
        CopyCommand.on(repo).execute("clean", "copied");
        new File(repo.getDirectory(), "missing").delete();
        writeFile("added");
        AddCommand.on(repo).execute("added");

        writeFile(".hgignore", "syntax: glob\nignored\n");
        CommitCommand.on(repo).message("message").user("user").execute(".hgignore");
        writeFile("ignored");
        writeFile("unknown");

        // Because of issue3278 open a new repo (and start a new
        // server process). Issue is fixed in 2.1.1
        boolean notFixed = repo.getHgVersion().isBefore(HgVersion.fromString("2.1.1"));
        Repository repo2 = repo;
        if (notFixed) {
            repo2 = Repository.open(repo.getDirectory());
        }

        StatusCommand statusCmd = StatusCommand.on(repo2).all();
        StatusResult result = statusCmd.execute();

        Assert.assertArrayEquals(new String[] { "modified" }, result.getModified().toArray());
        Assert.assertArrayEquals(new String[] { "added" }, result.getAdded().toArray());
        Assert.assertArrayEquals(new String[] { "removed" }, result.getRemoved().toArray());
        Assert.assertArrayEquals(new String[] { ".hgignore", "clean" }, result.getClean().toArray());
        Assert.assertArrayEquals(new String[] { "missing" }, result.getMissing().toArray());
        Assert.assertArrayEquals(new String[] { "unknown" }, result.getUnknown().toArray());
        Assert.assertArrayEquals(new String[] { "ignored" }, result.getIgnored().toArray());

        if (notFixed) {
            repo2.close();
        }
    }

    @Test
    public void testCopy() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a");
        commit();
        CopyCommand.on(repo).execute("a", "c");
        StatusResult result = StatusCommand.on(repo).copies().execute();
        Assert.assertEquals("a", result.getCopied().get("c"));
        Assert.assertEquals(1, result.getCopied().size());
    }

    @Test
    public void testIterator() throws IOException {
        setup();

        int count = 0;
        Collection<String> names = Sets.newHashSet("a.txt", "b.txt");
        for (StatusLine line : StatusCommand.on(getTestRepository())) {
            Assert.assertTrue(names.contains(line.getFileName()));
            count++;
        }
        Assert.assertEquals(2, count);

        // Make sure we have read all from stdout
        VersionCommand.on(getTestRepository()).execute();
    }

    @Test
    public void testErrorActionReport() throws IOException {
        assumeTrue(System.getProperty("os.name").equals("Linux"));
        assumeTrue(System.getProperty("file.encoding").equals("ISO-8859-1"));

        Repository repo = getTestRepository();
        File dir = repo.getDirectory();

        // Keep this file in ASCII so that it works when Eclipse is
        // started in both ISO-8859-1 and UTF-8 locales.

        // \u00C6 is the AE ligature.
        File apples = new File(dir, "\u00C6bler.txt");
        Files.write("\u00C6bler", apples, utf8());

        StatusCommand cmd = StatusCommand.on(repo);

        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (Exception ex) {
            Assert.assertEquals(RuntimeIOException.class, ex.getClass());
            Assert.assertEquals(MalformedInputException.class, ex.getCause().getClass());
        }
    }

    @Test
    public void testErrorActionReplace() throws IOException {
        assumeTrue(System.getProperty("os.name").equals("Linux"));
        assumeTrue(System.getProperty("file.encoding").equals("ISO-8859-1"));

        Repository repo = getTestRepository();
        File dir = repo.getDirectory();

        // Keep this file in ASCII so that it works when Eclipse is
        // started in both ISO-8859-1 and UTF-8 locales.

        // \u00C6 is the AE ligature.
        File apples = new File(dir, "\u00C6bler.txt");
        Files.write("\u00C6bler", apples, utf8());

        getFirstServer(repo).setErrorAction(CodingErrorAction.REPLACE);
        StatusResult result = StatusCommand.on(repo).execute();
        Assert.assertEquals(1, result.getUnknown().size());
        // \uFFFD is the Unicode replacement character
        Assert.assertEquals("\uFFFDbler.txt", result.getUnknown().get(0));
    }

    @Test
    public void testErrorActionIgnore() throws IOException {
        assumeTrue(System.getProperty("os.name").equals("Linux"));
        assumeTrue(System.getProperty("file.encoding").equals("ISO-8859-1"));

        Repository repo = getTestRepository();
        File dir = repo.getDirectory();

        // Keep this file in ASCII so that it works when Eclipse is
        // started in both ISO-8859-1 and UTF-8 locales.

        // \u00C6 is the AE ligature.
        File apples = new File(dir, "\u00C6bler.txt");
        Files.write("\u00C6bler", apples, utf8());

        getFirstServer(repo).setErrorAction(CodingErrorAction.IGNORE);
        StatusResult result = StatusCommand.on(repo).execute();
        Assert.assertEquals(1, result.getUnknown().size());
        Assert.assertEquals("bler.txt", result.getUnknown().get(0));
    }

    private StatusCommand setup() throws IOException {
        Repository repo = getTestRepository();
        File dir = repo.getDirectory();
        StatusCommand cmd = StatusCommand.on(repo);
        StatusResult result = cmd.execute();
        Assert.assertTrue(result.getAdded().isEmpty());
        Assert.assertTrue(result.getClean().isEmpty());
        Assert.assertTrue(result.getCopied().isEmpty());
        Assert.assertTrue(result.getIgnored().isEmpty());
        Assert.assertTrue(result.getMissing().isEmpty());
        Assert.assertTrue(result.getModified().isEmpty());
        Assert.assertTrue(result.getRemoved().isEmpty());
        Assert.assertTrue(result.getUnknown().isEmpty());

        AddCommand addCmd = AddCommand.on(repo);
        File a = new File(dir, "a.txt");
        File b = new File(dir, "b.txt");
        Files.write("BOO", a, utf8());
        Files.write("BOO", b, utf8());

        addCmd.execute(a.getAbsolutePath());
        return cmd;
    }
}
