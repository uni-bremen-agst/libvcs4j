/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Bookmark;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.test.AbstractTestCase;

public class BookmarksCommandTest extends AbstractTestCase {

    @Test
    public void testNoBookmarks() {
        Repository repo = getTestRepository();
        Assert.assertTrue(BookmarksCommand.on(repo).list().isEmpty());
    }

    @Test
    public void testDelete() throws IOException {
        Repository repo = getTestRepository();
        createChangeset();
        BookmarksCommand.on(repo).create("a");
        Assert.assertEquals(1, BookmarksCommand.on(repo).list().size());
        BookmarksCommand.on(repo).delete("a");
        Assert.assertEquals(0, BookmarksCommand.on(repo).list().size());
    }

    @Test
    public void testRename() throws IOException {
        Repository repo = getTestRepository();
        createChangeset();
        BookmarksCommand.on(repo).create("a");
        Assert.assertEquals(1, BookmarksCommand.on(repo).list().size());
        BookmarksCommand.on(repo).rename("a", "b");
        List<Bookmark> list = BookmarksCommand.on(repo).list();
        Assert.assertEquals(1, list.size());
        Bookmark bm = list.get(0);
        Assert.assertEquals("b", bm.getName());
        Assert.assertTrue("b", bm.isActive());
    }

    @Test
    public void testActive() throws IOException {
        Repository repo = getTestRepository();
        createChangeset();
        BookmarksCommand.on(repo).create("a");
        Bookmark bm = Utils.single(BookmarksCommand.on(repo).list());
        Assert.assertTrue(bm.isActive());

        Changeset cs2 = createChangeset();
        bm = Utils.single(BookmarksCommand.on(repo).list());
        Assert.assertSame(cs2, bm.getChangeset());
        Assert.assertTrue(bm.isActive());
    }

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();

        Assert.assertTrue(BookmarksCommand.on(repo).list().isEmpty());

        BookmarksCommand.on(repo).inactive().create("bookmark");
        createChangeset();
        BookmarksCommand.on(repo).create("a");
        Changeset cs = createChangeset();

        List<Bookmark> list = BookmarksCommand.on(repo).list();
        Assert.assertEquals(2, list.size());
        Bookmark bm = list.get(0);
        Assert.assertEquals("a", bm.getName());
        Assert.assertEquals(cs, bm.getChangeset());
        Assert.assertTrue(bm.isActive());
        bm = list.get(1);
        Assert.assertEquals("bookmark", bm.getName());
        Assert.assertNull(bm.getChangeset());
        Assert.assertFalse(bm.isActive());
    }

}
