/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class DiffCommandTest extends AbstractTestCase {

    @Test
    public void testNoFiles() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "abc\n");
        AddCommand.on(repo).execute();

        // @formatter:off
        String expected = ""
                + "diff --git a/x b/x\n"
                + "new file mode 100644\n"
                + "--- /dev/null\n"
                + "+++ b/x\n"
                + "@@ -0,0 +1,1 @@\n"
                + "+abc\n";
        // @formatter:on

        String patch = DiffCommand.on(repo).nodates().execute();
        Assert.assertEquals(expected, patch);
    }

    @Test
    public void testSingleFile() throws IOException {
        Repository repo = getTestRepository();

        writeFile("x", "abc\n");
        AddCommand.on(repo).execute();

        // @formatter:off
        String expected = ""
                + "diff --git a/x b/x\n" 
                + "new file mode 100644\n"
                + "--- /dev/null\n"
                + "+++ b/x\n"
                + "@@ -0,0 +1,1 @@\n"
                + "+abc\n";
        // @formatter:on

        String patch = DiffCommand.on(repo).nodates().execute("x");
        Assert.assertEquals(expected, patch);
    }

    @Test
    public void testDiffstat() throws IOException {
        Repository repo = getTestRepository();
        writeFile("x", "abc\n");
        AddCommand.on(repo).execute();

        // @formatter:off
        String expected = ""
                + " x |  1 +\n"
                + " 1 files changed, 1 insertions(+), 0 deletions(-)\n";
        // @formatter:on

        String patch = DiffCommand.on(repo).stat().execute();
        Assert.assertEquals(expected, patch);
    }

}
