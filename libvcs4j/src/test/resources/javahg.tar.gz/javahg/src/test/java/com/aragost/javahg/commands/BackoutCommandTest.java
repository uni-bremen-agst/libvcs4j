package com.aragost.javahg.commands;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.merge.BackoutConflictResolvingContext;
import com.aragost.javahg.test.AbstractTestCase;

public class BackoutCommandTest extends AbstractTestCase {

    @Test
    public void testBackoutMerge() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "bar");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("b", "booo");
        Changeset backoutCs = commitCmd.execute();

        writeFile("a", "foo");
        Changeset curCs = commitCmd.execute();

        BackoutCommand.on(repo).rev(backoutCs.getNode()).merge().message("BackoutMerge").user("user").execute();

        Assert.assertEquals(curCs, repo.workingCopy().getParent1());
        Assert.assertEquals(backoutCs, repo.workingCopy().getParent2().getParent1());

        commitCmd.execute();

        Assert.assertEquals("bar", readFile("b"));
        Assert.assertEquals(5, LogCommand.on(repo).execute().size());
    }

    @Test
    public void testBackoutUpdate() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "bar");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("b", "booo");

        Changeset backoutCs = commitCmd.execute();

        writeFile("a", "foo");

        Changeset curCs = commitCmd.execute();

        BackoutCommand.on(repo).rev(backoutCs.getNode()).message("BackoutMerge").user("user").execute();

        Changeset parent1 = repo.workingCopy().getParent1();
        /*
         * @Amenel Voglozin: comparing curCs with parent1 is plain wrong because backoutBaseCs is the direct parent of
         * curCs. According to the hg doc: "If REV is the parent of the working directory, then this new changeset is
         * committed automatically (unless --no-commit is specified)." Therefore, the parent of the working copy is not
         * curCs, but a new cset. Instead of comparing curCs with parent1, we check for the number of csets, and for the
         * contents of the file modified in the backed out cset ("b").
         */
        // Assert.assertEquals(curCs, parent1);
        Assert.assertEquals(3, parent1.getRevision());
        Assert.assertNull(repo.workingCopy().getParent2());

        // No need to commit for hg has done it automatically.
        // commitCmd.execute(); //
        Assert.assertEquals("bar", readFile("b"));
        Assert.assertEquals(4, LogCommand.on(repo).execute().size());
    }

    @Test
    public void testBackoutMergeConflict() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "boo");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("a", "bar");
        writeFile("b", "bar");
        Changeset backoutCs = commitCmd.execute();

        writeFile("a", "foo");
        writeFile("b", "foo");
        commitCmd.execute();

        BackoutCommand command = BackoutCommand.on(repo).rev(backoutCs.getNode()).merge().message("BackoutMerge").user(
                "user");
        BackoutConflictResolvingContext ctx;

        ctx = command.execute();

        Assert.assertEquals(2, ctx.getMergeConflicts().size());
    }

    @Test
    public void testBackoutUpdateConflict() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "boo");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("a", "bar");
        writeFile("b", "bar");
        Changeset backoutCs = commitCmd.execute();

        writeFile("a", "foo");
        writeFile("b", "foo");
        commitCmd.execute();

        BackoutCommand command = BackoutCommand.on(repo).rev(backoutCs.getNode()).message("BackoutMerge").user("user");
        BackoutConflictResolvingContext ctx;

        ctx = command.execute();

        Assert.assertEquals(2, ctx.getMergeConflicts().size());
    }

    @Test
    public void testBackoutTipMerge() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "bar");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("b", "booo");
        Changeset backoutCs = commitCmd.execute();

        BackoutCommand.on(repo).rev(backoutCs.getNode()).merge().message("BackoutMerge").user("user").execute();

        Assert.assertEquals(backoutCs, repo.workingCopy().getParent1().getParent1());
        Assert.assertEquals(null, repo.workingCopy().getParent2());
        Assert.assertEquals(null, repo.workingCopy().getParent1().getParent2());

        Assert.assertEquals("bar", readFile("b"));
        Assert.assertEquals(3, LogCommand.on(repo).execute().size());
    }

    @Test
    public void testBackoutTipUpdate() throws Exception {

        Repository repo = getTestRepository();
        CommitCommand commitCmd = CommitCommand.on(repo).message("m").user("user");

        writeFile("a", "boo");
        writeFile("b", "bar");
        AddCommand.on(repo).execute();
        commitCmd.execute();

        writeFile("b", "booo");
        Changeset backoutCs = commitCmd.execute();

        BackoutCommand.on(repo).rev(backoutCs.getNode()).message("BackoutMerge").user("user").execute();

        Assert.assertEquals(backoutCs, repo.workingCopy().getParent1().getParent1());
        Assert.assertEquals(null, repo.workingCopy().getParent2());
        Assert.assertEquals(null, repo.workingCopy().getParent1().getParent2());

        commitCmd.execute();

        Assert.assertEquals("bar", readFile("b"));
        Assert.assertEquals(3, LogCommand.on(repo).execute().size());
    }
}
