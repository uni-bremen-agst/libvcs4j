package com.aragost.javahg.test;

import com.aragost.javahg.internals.JavaHgMercurialExtension;

/**
 * Mercurial extension for running JavaHg Test cases
 */
public class JavaHgTestExtension extends JavaHgMercurialExtension {

    @Override
    public String getName() {
        return "javahg-test";
    }
}
