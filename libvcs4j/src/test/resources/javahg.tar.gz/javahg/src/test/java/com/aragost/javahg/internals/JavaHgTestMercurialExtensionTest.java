package com.aragost.javahg.internals;

import java.io.File;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Repository;
import com.aragost.javahg.RepositoryConfiguration;
import com.aragost.javahg.commands.CancelledExecutionException;
import com.aragost.javahg.commands.ExecutionException;
import com.aragost.javahg.commands.VersionCommand;
import com.aragost.javahg.test.AbstractTestCase;
import com.google.common.base.Strings;
import com.google.common.io.Files;

public class JavaHgTestMercurialExtensionTest extends AbstractTestCase {

    @Test
    public void testAbort() {
        BaseRepository repo = getTestRepository();
        GenericCommand cmd = new GenericCommand(repo, "javahg-abort");
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (ExecutionException e) {
            // Mercurial 3.1.1 returns other error codes other than -1, often 255
            // that suspiciously amount to -1 in 8bit two's complement...
            Assert.assertTrue(0 != cmd.getReturnCode() && 1 != cmd.getReturnCode());
            Assert.assertEquals("abort: crash\n", cmd.getErrorString());
        }
    }

    /**
     * This test is ignored because it was apparently designed to check that the javahg-write command was correctly
     * writing the given text to the e channel and that this text could be read from the channel, but as of hg 4.0, we
     * don't get anything back (Windows and Linux) from the command.
     * <p>
     * The only way to get something back on the 'e' channel is to have the extension write directly to stderr, which
     * we'll capture in javahg as an exception (see {@link #testStderr()}, which already checks that scenario). <br>
     * -Amenel Voglozin, 2016-12-25.
     */
    @Test
    @Ignore
    public void testError() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-write");
        cmd.execute("e", "foo bar");
        Assert.assertEquals(0, cmd.getReturnCode());
        Assert.assertEquals("foo bar", cmd.getErrorString());
    }

    /**
     * This test has been ignored because of an invalid assumption stated in the existing comments, namely the
     * assumption that a capital letter in the channel name (other than the legitimate 'I' and 'L') would trigger an
     * exception, which is not the case with hg 4.0.
     * <p>
     * Again, like for {@link #testUnknownMandatoryChannel()}, hg simply ignores the request, which, instead of causing
     * an exception, appears as a no-op.
     * <p>
     * The documentation of the command server (<a>https://www.mercurial-scm.org/wiki/CommandServer#Protocol</a>) says
     * nothing about the behavior of the server when illegal channel names are used.<br>
     * -Amenel Voglozin, 2016-12-25.
     */
    @Test
    @Ignore
    public void testStdout() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-stdout");
        try {
            cmd.execute("XXX YYY ZZZ"); // capital letter is
                                        // important, triggers illegal
                                        // channel exception
            assertFailedExecution(cmd);
        } catch (IllegalStateException e) {
            Assert.assertEquals("Unknown channel: X", e.getMessage());
        }

        // The server is aborted
        Assert.assertEquals(0, getTestRepository().getServerPool().getServers().size());

        VersionCommand.on(getTestRepository()).execute();

        Assert.assertEquals(1, getTestRepository().getServerPool().getServers().size());
    }

    /**
     * Scenario: the javahg-stderr command, designed to echo the received message to stderr, is used to make the generic
     * command report an error. We check that the expected exception (triggered by JavaHg) is raised.
     */
    @Test
    public void testStderr() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-stderr");
        Process process = getFirstServer(cmd.getRepository()).getProcess();
        try {
            cmd.execute("foo");
            assertFailedExecution(cmd);
        } catch (RuntimeException e) {
            Assert.assertEquals(0, cmd.getReturnCode());
            Assert.assertEquals("", cmd.getErrorString());
            String msg = e.getMessage();
            Assert.assertEquals("foo\n", msg);
            Assert.assertEquals(RuntimeException.class, e.getClass());
            int exitValue = process.exitValue();
            Assert.assertEquals(0, exitValue);
        }
    }

    /**
     * Scenario: we test that overflowing the buffer allocated by JavaHg to stderr does trigger an exception. A string
     * longer than the buffer size is sent to the javahg-stderr, which is designed to echo the payload on stderr.
     * <p>
     * I fail to see the added value of this test as testStderr follows the same pattern: we cause something to be
     * written to stderr, which fact is captured as an exception.<br>
     * -Amenel Voglozin, 2016-12-26.
     */
    @Test
    public void testLongMessageOnStderr() {
        // See comment in Server#checkStderr()
        // Without that available call in checkStderr typically not
        // everything from stderr will be read and this testcase fails
        // Assume.assumeTrue(System.getProperty("java.runtime.version").compareTo("1.7")
        // < 0);
        BaseRepository repo = getTestRepository();
        RepositoryConfiguration configuration = repo.getConfiguration();
        int bufSize = configuration.getStderrBufferSize();
        String longMessage = Strings.repeat("x", bufSize + 100) + "A";
        GenericCommand cmd = new GenericCommand(repo, "javahg-stderr");
        try {
            cmd.execute(longMessage);
            assertFailedExecution(cmd);
        } catch (RuntimeException e) {
            String msg = e.getMessage();
            Assert.assertEquals(bufSize, msg.length());
            Assert.assertEquals(Strings.repeat("x", bufSize), msg);
        }
    }

    @Test
    public void testUnknownOptionalChannel() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-write");
        cmd.execute("x", "foo bar");
        Assert.assertEquals(0, cmd.getReturnCode());
        Assert.assertEquals("", cmd.getErrorString());
    }

    /**
     * This test has been ignored because of an invalid assumption, namely the assumption that a capital letter in the
     * channel name would trigger an exception, which is not the case with hg 4.0. (I'm not sure which of hg or javahg
     * is supposed to raise/cause the exception.)
     * <p>
     * This voids the test, which was checking that the exception happened. The assumption is invalid on both Windows
     * and Linux.<br>
     * -Amenel Voglozin, 2016-12-25.
     */
    @Test
    @Ignore
    public void testUnknownMandatoryChannel() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-write");
        try {
            cmd.execute("X", "foo bar");
            assertFailedExecution(cmd);
        } catch (IllegalStateException e) {
            Assert.assertEquals("Unknown channel: X", e.getMessage());
        }
    }

    @Test
    public void testHang() throws IOException {
        // This test case has historical not fail consistently so
        // execute it 10 times
        for (int i = 0; i < 10; i++) {
            File dir = Files.createTempDir();

            final Repository repo = Repository.create(REPO_CONF, dir);
            GenericCommand cmd = new GenericCommand(repo, "javahg-hang");

            Thread executioner = new Thread() {
                /**
                 * Sleep 1/2 seconds to allow cmd to exit normally if the 'javahg-hang' doesn't make it hang and then
                 * kill server process
                 */
                @SuppressWarnings("synthetic-access")
                @Override
                public void run() {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        throw Utils.asRuntime(e);
                    }
                    getFirstServer(repo).getProcess().destroy();
                }
            };

            executioner.start();
            try {
                cmd.execute();
                assertFailedExecution(cmd);
            } catch (UnexpectedServerTerminationException e) {
                // When process is kill we get an IOException with
                // Stream closed, it is a
                // BlockInputStream.InvalidStreamException exception
                Throwable cause = e.getCause();
                if (cause instanceof IOException) {
                    String msg = ((IOException) cause).getMessage();
                    Assert.assertTrue("Unexpected message. Got \"" + msg + "\"", msg.equals("Bad file descriptor")
                            || msg.equals("Stream Closed") || msg.equals("Stream closed"));
                } else {
                    Assert.assertEquals(BlockInputStream.InvalidStreamException.class, cause.getClass());
                }
            } catch (ExecutionException e) {
                // System.err.println("Got 'killed!' on 'e' channel");
                Assert.assertEquals("killed!", e.getMessage());
            }
            // TODO There seems to be some kind of race condition.
            // Sometimes an UnexpectedServerTerminationException is
            // thrown, and sometimes an ExecutionException
            // Analysis so far: Mercurial server process writes
            // 'killed!' when the process is destroyed, sometimes it
            // writes it to
            // the actual stderr stream (typically case, gives
            // UnexpectedServerTerminationException), and
            // sometimes to the 'e'
            // channel (rare case, gives ExecutionException).
            //
            // TODO also try to access the server on stdout and stdin

            repo.close();
            deleteTempDir(dir);
        }
    }

    @Test
    public void testCancel() throws IOException {
        File dir = Files.createTempDir();

        final Repository repo = Repository.create(REPO_CONF, dir);
        final GenericCommand cmd = new GenericCommand(repo, "javahg-hang");

        Thread executioner = new Thread() {
            @Override
            public void run() {
                while (cmd.getState() != GenericCommand.State.RUNNING) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        throw Utils.asRuntime(e);
                    }
                }
                cmd.cancel();
            }
        };

        executioner.start();
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (CancelledExecutionException e) {
            // Expected
        } catch (Throwable e) {
            Assert.fail("CancelledExecutionException expected. Got:" + e);
        }

        VersionCommand.on(repo).execute();

        repo.close();
        deleteTempDir(dir);
    }

    @Test
    public void testPreCancel() throws IOException {
        File dir = Files.createTempDir();

        final Repository repo = Repository.create(REPO_CONF, dir);
        final GenericCommand cmd = new GenericCommand(repo, "javahg-hang");

        cmd.cancel();

        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (CancelledExecutionException e) {
            // Expected
        } catch (Throwable e) {
            Assert.fail("CancelledExecutionException expected. Got:" + e);
        }

        VersionCommand.on(repo).execute();

        repo.close();
        deleteTempDir(dir);
    }

    /**
     * Test canceling a command that is queued
     */
    @Test
    // @Ignore
    public void testCancelQueued() throws IOException {
        File dir = Files.createTempDir();

        final Repository repo = Repository.create(REPO_CONF, dir);
        final GenericCommand cmd = new GenericCommand(repo, "javahg-hang");
        final GenericCommand cmd2 = new GenericCommand(repo, "javahg-hang");

        final Thread executor = new Thread() {

            @SuppressWarnings("synthetic-access")
            @Override
            public void run() {
                try {
                    Thread.sleep(500);
                    Assert.assertEquals(0, repo.getServerPool().getNumIdleServers());
                    cmd2.execute();
                    assertFailedExecution(cmd);
                } catch (CancelledExecutionException e) {
                    // Expected
                } catch (InterruptedException e) {
                    throw Utils.asRuntime(e);
                }
            }
        };

        Thread executioner = new Thread() {

            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw Utils.asRuntime(e);
                }
                Assert.assertEquals(AbstractCommand.State.QUEUED, cmd2.getState());
                cmd2.cancel();
                try {
                    executor.join();
                } catch (InterruptedException e) {
                    throw Utils.asRuntime(e);
                }
                cmd.cancel();
            }
        };

        Assert.assertEquals(1, repo.getServerPool().getNumIdleServers());
        executor.start();
        executioner.start();
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (CancelledExecutionException e) {
            // Expected
        } catch (Throwable e) {
            Assert.fail("CancelledExecutionException expected. Got:" + e);
        }

        VersionCommand.on(repo).execute();

        repo.close();
        deleteTempDir(dir);
    }

    /**
     * Scenario: We test the javahg-throw command, which is designed to raise an exception. We check that the server is
     * indeed interrupted by an exception raised from hg.
     */
    @Test
    public void testThrow() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-throw");
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (UnexpectedServerTerminationException e) {
            int expectedExitValue = Utils.isWindows() ? 255 : 1;
            Assert.assertEquals(expectedExitValue, e.getExitValue());
        }
    }

    /**
     * Scenario: We execute the javahg-exit command, explicitly defined to (quote from the Python code) “promise to
     * write message twice, but crash mid way”) with an exit code of 200. We check that the server did indeed terminate
     * unexpectedly, and with exit code 200.
     * <p>
     * The “promise to write message twice” part refers to announcing a certain length and only providing half the
     * announced bytes message length (see the protocol at
     * <a>https://www.mercurial-scm.org/wiki/CommandServer#Protocol</a>).
     * <p>
     * The Python code is in <em>src/test/resources/javahg-test.py</em>.
     */
    @Test
    public void testExit() {
        GenericCommand cmd = new GenericCommand(getTestRepository(), "javahg-exit");
        try {
            cmd.execute("foo");
            assertFailedExecution(cmd);
        } catch (UnexpectedServerTerminationException e) {
            // This is the main exception that we are expecting (@hg 4.0).
            Assert.assertEquals(200, e.getExitValue());
        } catch (RuntimeIOException e) {
            Assert.assertEquals("Unexpected EOF", e.getMessage());
        }
    }

}
