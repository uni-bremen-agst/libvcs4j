package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Ignore;
import org.junit.Test;

import com.aragost.javahg.BaseRepository;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.UnknownCommandException;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.merge.ConflictResolvingContext;
import com.aragost.javahg.merge.GraftContext;
import com.aragost.javahg.merge.KeepDeleteConflict;
import com.aragost.javahg.merge.MergeConflict;
import com.aragost.javahg.test.AbstractTestCase;

public class GraftCommandTest extends AbstractTestCase {

    private boolean isGraftSupported() {
        BaseRepository repo = getTestRepository();
        try {
            PhaseCommand.on(repo).rev(Changeset.NULL_ID).execute();
            return true;
        } catch (UnknownCommandException e) {
            return false;
        }
    }

    @Test
    public void testGraftSelf() throws IOException {
        Assume.assumeTrue(isGraftSupported());
        BaseRepository repo = getTestRepository();
        Changeset cs = createChangeset();
        GraftCommand.on(repo).execute(cs);
        List<Changeset> heads = repo.heads();
        assertSingleton(cs, heads);
    }

    /**
     * Scenario: We create a change set that will be used as a base change set and which is the direct parent to two
     * other change sets (cset1 and cset2) with different manifests. This will give two heads. We then backport cset1 to
     * the currently active (i.e. latest) history line/ branch, which will then also have cset1 in addition to cset2 and
     * the base change set.
     * <p>
     * Note that cset1 therefore exists twice in the repository: once in the base-cset1 branch and once in
     * base-cset2-cset1 (as a clone).
     * <p>
     * We check that the tip (of the active, i.e. latest, ancestry line) references cset1 as its source (cset1 and its
     * "clone" WILL have different IDs).
     */
    @Test
    public void test() throws IOException {
        Assume.assumeTrue(isGraftSupported());
        BaseRepository repo = getTestRepository();

        // This creates a file named "dummyFileForCreatingChangesets"
        Changeset base = createChangeset();
        writeFile("a");
        Changeset cset1 = commit();
        update(base);
        writeFile("b");

        Changeset cset2 = commit();
        ConflictResolvingContext r = GraftCommand.on(repo).execute(cset1);
        Assert.assertNull(r);
        Changeset tip = repo.tip();
        String source = tip.getExtra().getString("source");
        Assert.assertEquals(cset1.getNode(), source);
    }

    /**
     * This test has been ignored because of an invalid assumption, namely the assumption that merging two revisions
     * with different manifests would produce a conflict when a file has been deleted in a cset but is available in the
     * other one. As of hg 4.0, this does yield a conflict, at least not of the expected KeepDelete type: merging a cset
     * in which a file has been modified to a cset in which the file does not exist produces a simple merge conflict.
     * <p>
     * The concept of a manifest conflict seems to have vanished from hg's semantics. Maybe that there was a time when
     * manifest conflicts occurred but this is no longer (Dec 2016) the case; hg seems to go for the largest set
     * possible when reconciling change sets, not only in files but also in manifests. This would make sense as the only
     * type of conflicts remaining in the semantics is a line conflict aka “merge conflict”.<br>
     * -Amenel Voglozin, 2016-12-25.
     */
    @Test
    @Ignore
    public void testKeepDeleteConflict() throws IOException {
        Assume.assumeTrue(isGraftSupported());
        BaseRepository repo = getTestRepository();
        writeFile("file", "");
        Changeset base = commit();
        writeFile("file", "X");
        Changeset changed = commit();
        update(base);
        RemoveCommand.on(repo).execute("file");
        Changeset removed = commit();

        GraftContext ctx = GraftCommand.on(repo).execute(changed);
        Assert.assertNotNull(ctx);
        Assert.assertTrue(ctx.getFlagConflicts().isEmpty());
        Assert.assertTrue(ctx.getMergeConflicts().isEmpty());
        KeepDeleteConflict kdc = Utils.single(ctx.getKeepDeleteConflicts());
        Assert.assertNotNull(kdc);
        Assert.assertSame(removed, repo.tip());
        Assert.assertEquals("file", kdc.getFilename());
        Assert.assertSame(changed, ctx.getSource());
        kdc.delete();
        // TODO commiting results in an error, see issue 3261
        // Changeset cs = ctx.commit();
        // Assert.assertNotNull(cs);
    }

    /**
     * Scenario: We get two heads (cset1 & cset2) by committing twice from a base changeset. Then the oldest head
     * changeset is grafted on the latest ancestry line (branch). Due to the one-line file having different contents in
     * cset1 and cset2, the graft operation results in a conflict.
     */
    @Test
    public void testMergeConflict() throws IOException {
        Assume.assumeTrue(isGraftSupported());
        BaseRepository repo = getTestRepository();
        writeFile("file", "");
        Changeset base = commit();
        writeFile("file", "X");
        Changeset cset1 = commit();
        update(base);
        writeFile("file", "Y");

        Changeset cset2 = commit();

        GraftContext ctx = GraftCommand.on(repo).execute(cset1);
        Assert.assertNotNull(ctx);
        Assert.assertTrue(ctx.getFlagConflicts().isEmpty());
        Assert.assertTrue(ctx.getKeepDeleteConflicts().isEmpty());
        MergeConflict mergeConflict = Utils.single(ctx.getMergeConflicts());
        Assert.assertNotNull(mergeConflict);
        // Mercurial 2.2 will skip empty commits, so we must resolve
        // with new content.
        writeFile("file", "XY");
        mergeConflict.markResolved();
        Changeset cs = ctx.commit();
        Assert.assertNotNull(cs);
        Assert.assertEquals(cset1.getNode(), cs.getExtra().getString("source"));
    }

}
