/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.aragost.javahg.Repository;
import com.aragost.javahg.test.AbstractTestCase;

public class RemoveCommandTest extends AbstractTestCase {

    @Test
    public void test() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");
        new File(repo.getDirectory(), "dir").mkdir();
        writeFile("dir/a", "");
        writeFile("dir/b", "");
        commit();

        List<File> removed = RemoveCommand.on(repo).execute(new File("dir"));
        Assert.assertEquals(2, removed.size());
        Assert.assertEquals(repoFile(repo, "dir", "a"), removed.get(0));
        Assert.assertEquals(repoFile(repo, "dir", "b"), removed.get(1));
    }

    /**
     * Scenario: We try to execute the remove command without providing the required file(s) to be scheduled for
     * removal, which should cause an exception.
     */
    @Test
    public void testWithNoFiles() {
        Repository repo = getTestRepository();
        RemoveCommand cmd = RemoveCommand.on(repo);
        try {
            cmd.execute();
            assertFailedExecution(cmd);
        } catch (ExecutionException e) {
            Assert.assertSame(cmd, e.getCommand());
            // Mercurial 3.1.1 returns other error codes other than -1, often 255
            // that suspiciously amount to -1 in 8bit two's complement...
            Assert.assertFalse(0 == cmd.getReturnCode() || 1 == cmd.getReturnCode());
            Assert.assertEquals("abort: no files specified\n", cmd.getErrorString());
        }
    }

    @Test
    public void testUntracked() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");

        RemoveCommand cmd = RemoveCommand.on(repo);
        cmd.execute("a");
        Assert.assertEquals("not removing a: file is untracked\n", cmd.getErrorString());
    }

    /**
     * Scenario: We try to execute the remove command by specifying a file that is not tracked in the repository, which
     * will cause no removals and will generate an error message. The error message typically starts with the name of
     * the file that was given.
     */
    @Test
    public void testNoSuchFile() {
        Repository repo = getTestRepository();

        RemoveCommand cmd = RemoveCommand.on(repo);
        List<String> filesRemoved = cmd.execute("a");
        Assert.assertEquals(0, filesRemoved.size());
        Assert.assertTrue(cmd.getErrorString().startsWith("a: "));
    }

    /**
     * Scenario: We execute the remove command by specifying a legitimate file and another one that is not tracked in
     * the repository. This will cause one removal and will generate an error message.
     * <p>
     * The error message typically starts with the name of the file in error.
     */
    @Test
    public void testMixedSuccess() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");
        commit();

        RemoveCommand cmd = RemoveCommand.on(repo);
        List<File> result = cmd.execute(new File("a"), new File("b"));
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(repoFile(repo, "a"), result.get(0));
        Assert.assertTrue(cmd.getErrorString().startsWith("b: "));
    }

}
