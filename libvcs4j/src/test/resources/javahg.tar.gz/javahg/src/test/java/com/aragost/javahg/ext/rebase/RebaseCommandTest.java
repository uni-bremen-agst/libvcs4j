/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.ext.rebase;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Ignore;
import org.junit.Test;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.UnknownCommandException;
import com.aragost.javahg.commands.ExecutionException;
import com.aragost.javahg.commands.PhaseCommand;
import com.aragost.javahg.commands.ResolveCommand;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.merge.ConflictResolvingContext;
import com.aragost.javahg.merge.KeepDeleteConflict;
import com.aragost.javahg.merge.MergeConflict;
import com.aragost.javahg.test.AbstractTestCase;

/**
 * TODO: add test case for conflict on continue
 */
public class RebaseCommandTest extends AbstractTestCase {

    static {
        REPO_CONF.addExtension(RebaseExtension.class);
    }

    @Test
    public void testMergeCtxAncestor() throws IOException {
        Repository repo = getTestRepository();
        Changeset base = createChangeset();
        Changeset parent2 = createChangeset();
        update(base);
        Changeset parent1 = createChangeset();
        ConflictResolvingContext ms = RebaseCommand.on(repo).source(parent2.getNode()).execute();

        Assert.assertEquals(parent1, ms.getLocal());
        Assert.assertEquals(parent2, ms.getRemote());
        Assert.assertEquals(base, ms.getBase());
    }

    /**
     * Test ignored on 2018-02-06 after merging javahg-ext-rebase into core JavaHg.
     * 
     * @throws IOException
     */
    @Test
    @Ignore
    public void testMergeCtxKeepDeleteConflict() throws IOException {
        Repository repo = getTestRepository();
        writeFile("a", "");
        Changeset base = commit();
        writeFile("a", "a");
        Changeset p2 = commit();
        update(base);
        repo.workingCopy().remove("a");
        commit();

        ConflictResolvingContext ms = RebaseCommand.on(repo).source(p2.getNode()).execute();
        Assert.assertEquals(1, ms.getKeepDeleteConflicts().size());
        KeepDeleteConflict keepDeleteConflict = ms.getKeepDeleteConflicts().iterator().next();
        Assert.assertEquals(KeepDeleteConflict.State.KEEP, keepDeleteConflict.getState());
        Assert.assertEquals("a", keepDeleteConflict.getFilename());

        // TODO: add support for changing default choices for
        // keep/delete conflicts
        // Assert.assertEquals(p2,
        // keepDeleteConflict.getKeepParent());
    }

    @Test
    public void testMergeCtxFlagConflict() throws IOException, InterruptedException {
        // Windows does not (in the Mercurial world) support symlinks
        Assume.assumeTrue(!Utils.isWindows());

        Repository repo = getTestRepository();
        writeFile("x", "");
        Changeset base = commit();
        writeFile("a", "");
        setExecutable(repo.file("a"));
        Changeset parent2 = commit();
        update(base);
        createSymlink(repo.file("b"), repo.file("a"));
        commit();

        ConflictResolvingContext mergeCtx = RebaseCommand.on(repo).source(parent2.getNode()).execute();
        //Assert.assertEquals(1, mergeCtx.getFlagConflicts().size());
        //Assert.assertEquals("a", mergeCtx.getFlagConflicts().iterator().next().getFilename());
        Assert.assertEquals(1, mergeCtx.getMergeConflicts().size());
        Assert.assertEquals("a", mergeCtx.getMergeConflicts().iterator().next().getFilename());
    }

    private void createSymlink(File oldName, File newName) throws IOException, InterruptedException {
        String[] cmd = new String[] { "ln", "-s", oldName.getAbsolutePath(), newName.getAbsolutePath() };
        exec(cmd);
    }

    private void setExecutable(File file) throws InterruptedException, IOException {
        String[] cmd = new String[] { "chmod", "+x", file.getAbsolutePath() };
        exec(cmd);
    }

    @SuppressWarnings("static-method")
    private void exec(String[] cmd) throws InterruptedException, IOException {
        Process process = Runtime.getRuntime().exec(cmd);
        process.waitFor();
        process.destroy();
    }

    @Test
    public void testMergeConflict() throws IOException {
        Repository repo = getTestRepository();
        // Merge conflict in a can not be resolved with internal:merge
        // in b the conflict can
        writeFile("a");
        writeFile("b", "a\na\na\na\na\n");
        Changeset base = commit();
        writeFile("a", "XX");
        writeFile("b", "X\na\na\na\na\n");
        Changeset parent2 = commit();
        update(base);
        writeFile("a", "YY");
        writeFile("b", "a\na\na\nY\na\n");
        commit();

        ConflictResolvingContext mergeState = RebaseCommand.on(repo).source(parent2.getNode()).execute();
        List<MergeConflict> mergeConflicts = mergeState.getMergeConflicts();
        Assert.assertEquals(2, mergeConflicts.size());
        MergeConflict mca = mergeConflicts.get(0);
        MergeConflict mcb = mergeConflicts.get(1);
        Assert.assertEquals("a", mca.getFilename());
        Assert.assertEquals("b", mcb.getFilename());

        Assert.assertFalse(mca.isResolved());
        Assert.assertFalse(mcb.isResolved());

        mca.resolveWithInternalMerge();
        mcb.resolveWithInternalMerge();

        Assert.assertFalse(mca.isResolved());
        Assert.assertTrue(mcb.isResolved());

        try {
            RebaseCommand.on(repo).executeContinue();
            Assert.fail("Exception expected");
        } catch (ExecutionException e) {
            // This exception is expected.
        }

        ResolveCommand.on(repo).mark("a");

        RebaseCommand.on(repo).executeContinue();
    }

    public void testErrorHandling() throws Exception {
        Repository repo = getTestRepository();
        Changeset base = createChangeset();
        Changeset parent2 = createChangeset();
        update(base);

        try {
            PhaseCommand.on(repo).pub().rev(parent2.getNode()).execute();
        } catch (UnknownCommandException e) {
            // The phase command is only supported from Mercurial 2.1.
            // Simply return if
            // it doesn't exists.
            return;
        }
        try {
            RebaseCommand.on(repo).source(parent2.getNode()).execute();
        } catch (ExecutionException e) {
            // As expected
            return;
        }
        Assert.fail(ExecutionException.class.getName() + " expected");
    }
}
