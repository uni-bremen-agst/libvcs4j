package com.aragost.javahg.internals;

/**
 * Exception thrown when during parsing of the output from command server, some unexpected output is encountered.
 * <p>
 * It means that Mercurial generated output that JavaHg didn't anticipate. If this exception is throw it generally means
 * there is a bug in JavaHg.
 */
public class UnexpectedCommandOutputException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public UnexpectedCommandOutputException(AbstractCommand command, String s) {
        super(createMessage(command, s));
    }

    public UnexpectedCommandOutputException(String msg) {
        super(msg);
    }

    private static String createMessage(AbstractCommand command, String s) {
        StringBuilder builder = new StringBuilder();
        builder.append("Unexpected output from: ").append(command);
        if (s != null) {
            builder.append(" [").append(s).append(']');
        }
        return builder.toString();
    }

}
