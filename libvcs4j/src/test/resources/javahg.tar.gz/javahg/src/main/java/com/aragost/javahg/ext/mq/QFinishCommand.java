package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QFinishCommandFlags;

public class QFinishCommand extends QFinishCommandFlags {

    public QFinishCommand(Repository repository) {
        super(repository);
    }

    /**
     * @param revs
     *            Revisions or patch names of applied patches
     */
    public void execute(String... revs) {
        launchString(revs);
    }
}
