package com.aragost.javahg.internals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * The ServiceLoader searches for Service implementations in META-INF/services. This class emulates the behavior of
 * ServiceLoader introduced in Java 1.6.
 *
 * @author Sebastian Sdorra
 */
public final class ServiceLoader {

    private static final String SERVICE_PREFIX = "META-INF/services/";

    /**
     * This method is shorthand for {@link #loadService(java.lang.ClassLoader, java.lang.Class)} with the context
     * classloader.
     * 
     * @param serviceClass
     *            classloader used to load the resource from META-INF/services
     * 
     * @return service implementation or null
     * 
     * @throws ServiceException
     */
    public static <S> S loadService(Class<S> serviceClass) throws ServiceException {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if (classLoader == null) {
            classLoader = Utils.class.getClassLoader();
        }
        return loadService(classLoader, serviceClass);
    }

    /**
     * Returns a implementation of the given service or null if no service could be found.
     * 
     * @param classLoader
     *            classloader used to load the resource from META-INF/services
     * @param serviceClass
     *            service class to load
     * 
     * @return service implementation or null
     * @throws ServiceException
     */
    public static <S> S loadService(ClassLoader classLoader, Class<S> serviceClass) throws ServiceException {
        S service = null;
        String name = serviceClass.getName();
        URL resource = classLoader.getResource(SERVICE_PREFIX.concat(name));
        if (resource != null) {
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(resource.openStream(), "UTF-8"));
                String line = reader.readLine();
                while (line != null) {
                    int comment = line.indexOf("#");
                    if (comment >= 0) {
                        line = line.substring(0, comment);
                    }
                    line = line.trim();
                    if (line.length() > 0) {
                        service = serviceClass.cast(Class.forName(line).newInstance());
                        break;
                    }
                    line = reader.readLine();
                }
            } catch (Exception ex) {
                throw new ServiceException("could not load service for class ".concat(name), ex);
            } finally {
                // do not use Utils or logger, because they are
                // loaded with the help of ServiceLoader
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException ex) {
                        // Nothing to recover from.
                    }
                }
            }
        }
        return service;
    }
}
