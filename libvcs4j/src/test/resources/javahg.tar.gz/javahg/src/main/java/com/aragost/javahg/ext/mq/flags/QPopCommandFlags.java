/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.1.1+41-63a1bed65fa3.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.ext.mq.flags;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.QPopCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class QPopCommandFlags extends AbstractCommand {

    protected QPopCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "qpop";
    }

    public static QPopCommand on(Repository repository) {
        return new QPopCommand(repository);
    }

    /**
     * Set the <tt>--all</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qpop">Mercurial documentation</a>
     * @return this instance
     */
    public QPopCommand all() {
        cmdAppend("--all");
        return (QPopCommand) this;
    }

    /**
     * Set the <tt>--name</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qpop">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public QPopCommand name(String name) {
        cmdAppend("--name", name);
        return (QPopCommand) this;
    }

    /**
     * Set the <tt>--force</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qpop">Mercurial documentation</a>
     * @return this instance
     */
    public QPopCommand force() {
        cmdAppend("--force");
        return (QPopCommand) this;
    }

}
