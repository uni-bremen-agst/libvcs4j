/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2017 aragost Trifork ag & contributors
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

/**
 * Constants for the arguments/switches supported by Mercurial. Before this class was introduced, arguments were
 * sprinkled all around the source code. Gathering all strings removes the risk of typos and gives us a single place
 * where to modify the strings, should one ever change.
 * 
 * @author waav / W. Amenel VOGLOZIN
 */
public class Args {

    //@formatter:off
    public static final String ADDED      = "--added";
    public static final String ACTIVE     = "--active";
    public static final String INACTIVE   = "--inactive";
    public static final String BOOKMARK   = "--bookmark";
    public static final String BOOKMARKS  = "--bookmarks";
    public static final String BUNDLE     = "--bundle";
    public static final String BRANCH     = "--branch";
    public static final String CLEAN      = "--clean";
    public static final String CMDSERVER  = "--cmdserver";
    public static final String CONFIG     = "--config";
    public static final String DATE       = "--date";
    public static final String DELETED    = "--deleted";
    public static final String DRAFT      = "--draft";
    public static final String DEBUG      = "--debug";
    public static final String EXCLUDE    = "--exclude";
    public static final String FORCE      = "--force";
    public static final String GIT        = "--git";
    public static final String IGNORED    = "--ignored";
    public static final String INCLUDE    = "--include";
    public static final String LIST       = "--list";
    public static final String MARK       = "--mark";
    public static final String MERGE      = "--merge";
    public static final String MESSAGE    = "--message";
    public static final String MODIFIED   = "--modified";
    public static final String PARENT     = "--parent";
    public static final String PUBLIC     = "--public";
    public static final String PULL       = "--pull";
    public static final String REMOVED    = "--removed";
    public static final String REPOSITORY = "--repository";
    public static final String REVISION   = "--rev";
    public static final String SECRET     = "--secret";
    public static final String STYLE      = "--style";
    public static final String TAGS       = "--tags";
    public static final String TEMPLATE   = "--template";
    public static final String TOOL       = "--tool";
    public static final String UNKNOWN    = "--unknown";
    public static final String UNMARK     = "--unmark";
    public static final String USER       = "--user";
    //@formatter:on

    private Args() {
        // Utility class.
    }
}
