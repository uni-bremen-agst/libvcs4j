package com.aragost.javahg.commands;

import com.aragost.javahg.internals.AbstractCommand;

public class CancelledExecutionException extends ExecutionException {

    private static final long serialVersionUID = 1L;

    public CancelledExecutionException(AbstractCommand command) {
        super(command, "Command cancelled");
    }
}
