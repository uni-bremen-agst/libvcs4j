package com.aragost.javahg.ext.purge;

import com.aragost.javahg.Repository;
import com.aragost.javahg.internals.AbstractCommand;

public class PurgeCommand extends AbstractCommand {

    protected PurgeCommand(Repository repository) {
        super(repository);
    }

    public static PurgeCommand on(Repository repo) {
        return new PurgeCommand(repo);
    }

    @Override
    public String getCommandName() {
        return "purge";
    }

    public void execute() {
        launchString();
    }

}
