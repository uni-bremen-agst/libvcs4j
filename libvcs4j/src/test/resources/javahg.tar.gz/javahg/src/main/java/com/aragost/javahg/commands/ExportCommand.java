/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.ExportCommandFlags;
import com.aragost.javahg.internals.HgInputStream;

/**
 * Command class for executing <tt>hg export</tt>. Set flags from {@link ExportCommandFlags} and call the
 * {@link #execute} method.
 */
public class ExportCommand extends ExportCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public ExportCommand(Repository repository) {
        super(repository);
        cmdAppend(Args.GIT);
    }

    /**
     * Export a revision to a string.
     * 
     * @param revs
     *            list of changeset identifiers to export.
     * @return the patch as a string.
     */
    public String execute(String... revs) {
        return launchString(revs);
    }

    /**
     * Export a revision to a string.
     * 
     * @param revs
     *            list of revision numbers to export.
     * @return the patch as a string.
     */
    public String execute(int... revs) {
        String[] converted = new String[revs.length];
        for (int i = 0; i < revs.length; i++) {
            converted[i] = "" + revs[i];
        }
        return execute(converted);
    }

    /**
     * Export a revision to a stream. Note: The caller is responsible for fully consuming the returned stream
     * 
     * @param revs
     *            list of changeset identifiers to export.
     * @return the patch as a string.
     */
    public HgInputStream stream(String... revs) {
        return launchStream(revs);
    }
}
