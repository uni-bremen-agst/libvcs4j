package com.aragost.javahg;

public class Bookmark {

    private Changeset changeset;

    private String name;

    private boolean active;

    public Bookmark(Changeset changeset, String name, boolean active) {
        this.changeset = changeset;
        this.name = name;
        this.active = active;
    }

    public Changeset getChangeset() {
        return changeset;
    }

    public String getName() {
        return name;
    }

    public boolean isActive() {
        return active;
    }

    @Override
    public String toString() {
        if (isActive()) {
            return "*" + getName();
        }
        return getName();
    }

}
