/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.RollbackCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.RuntimeIOException;
import com.aragost.javahg.internals.Utils;

/**
 * Command class for executing <tt>hg rollback</tt>. Set flags from {@link RollbackCommandFlags} and call
 * the{@link #execute} method.
 */
public class RollbackCommand extends RollbackCommandFlags {

    private static final byte[] REPOSITORY_TIP_ROLLBACK_REVSION = "repository tip rolled back to revision ".getBytes();

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public RollbackCommand(Repository repository) {
        super(repository);
    }

    /**
     * Rollback last transaction.
     * 
     * @return The new tip of the repository
     */
    public Changeset execute() {
        HgInputStream stream = launchStream();
        try {
            stream.mustMatch(REPOSITORY_TIP_ROLLBACK_REVSION);
            int rev = stream.decimalIntUpTo(' ');
            stream.consumeAll();
            return Utils.single(LogCommand.on(getRepository()).rev(String.valueOf(rev)).execute());
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
    }

}
