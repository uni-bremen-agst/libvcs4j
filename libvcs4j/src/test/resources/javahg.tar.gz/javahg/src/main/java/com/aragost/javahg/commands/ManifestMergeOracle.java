/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.List;
import java.util.Map;

import com.aragost.javahg.internals.Server;
import com.aragost.javahg.internals.UpdateMergeHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Defines an "oracle" that will answer questions from Mercurial about manifest merge conflicts. Such conflicts happen
 * (see the text of the manifest merge pattern in {@link UpdateMergeHelper}) when the remote changeset has changed a
 * file that has been locally deleted.
 * <p>
 * The options are 1- keeping the <u>c</u>hanged file and 2- <u>d</u>eleting the file.
 * <p>
 * The oracle can be seen as an agent tasked with answering questions about files. The answers must be provided
 * beforehand, that is before using the oracle. However, it is only relevant to query the list of missing answers after
 * using the oracle (see {@link #ask(String)}).
 * <p>
 * <em>Javadoc retro-engineering: Amenel Voglozin, 2016-12-12.</em>
 * <p>
 * NOTE1: This class was used with the Update and Merge commands, under the rationale that both commands are interactive
 * and would then need answers about resolving conflicts. However, the server is configured (see
 * {@link Server#start(java.io.File, String, List, Map, Runnable)}) to use "internal:fail" as a merge tool. That tool
 * has the following explanation in the hg documentation <blockquote>Rather than attempting to merge files that were
 * modified on both branches, it marks them as unresolved. The resolve command must be used to resolve these
 * conflicts.</blockquote>
 * <p>
 * NOTE2: Manual tests on the command line (hg 4.0, Windows, 2016-12-28) reveal that this merge tool <u>disables</u> any
 * interactivity. Consequently, the oracle is not used.
 * <p>
 * FIXME Edit Javadoc (remove notes) after interactivity has been restored.
 */
public class ManifestMergeOracle {

    private Map<String, String> answers = Maps.newHashMap();
    private List<String> missingAnswers = Lists.newArrayList();

    public String ask(String name) {
        String answer = answers.get(name);
        if (answer == null) {
            this.missingAnswers.add(name);
            answer = "c";
        }
        return answer;
    }

    public void keep(String file) {
        this.answers.put(file, "c");
    }

    public void delete(String file) {
        this.answers.put(file, "d");
    }

    public List<String> getMissingAnswers() {
        return missingAnswers;
    }

}
