/*

 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * An aggregated status result. This class gives easy access to the files of different status types and will in
 * particular parse added and copied files correctly.
 */
public class StatusResult {
    private List<String> modified = Lists.newArrayList();
    private List<String> added = Lists.newArrayList();
    private List<String> removed = Lists.newArrayList();
    private List<String> clean = Lists.newArrayList();
    private List<String> missing = Lists.newArrayList();
    private List<String> unknown = Lists.newArrayList();
    private List<String> ignored = Lists.newArrayList();
    // Map from new name to old name
    private Map<String, String> copied = Maps.newHashMap();

    /**
     * @return files with status M
     */
    public List<String> getModified() {
        return modified;
    }

    /**
     * List of added files. Files that has been copied is <em>not</em> in this List, even though 'hg status' reports
     * them with status A. Instead they are in {@code copied}.
     * <p>
     * If the <tt>--copies</tt> flag isn't set the status command does not report origin, and this List will also
     * include copied files.
     * 
     * @return files with status A
     */
    public List<String> getAdded() {
        return added;
    }

    /**
     * @return Files with status R
     */
    public List<String> getRemoved() {
        return removed;
    }

    /**
     * @return files with status C
     */
    public List<String> getClean() {
        return clean;
    }

    /**
     * @return files with status !
     */
    public List<String> getMissing() {
        return missing;
    }

    /**
     * @return files with status ?
     */
    public List<String> getUnknown() {
        return unknown;
    }

    /**
     * @return files with status I
     */
    public List<String> getIgnored() {
        return ignored;
    }

    /**
     * Mapping copied files. The key is the new name and value is origin.
     * 
     * @return map from new name to origin for copied files.
     */
    public Map<String, String> getCopied() {
        return copied;
    }

    void addLine(StatusLine current) {
        String fileName = current.getFileName();
        switch (current.getType()) {
        case ADDED:
            this.added.add(fileName);
            break;
        case CLEAN:
            this.clean.add(fileName);
            break;
        case IGNORED:
            this.ignored.add(fileName);
            break;
        case MISSING:
            this.missing.add(fileName);
            break;
        case MODIFIED:
            this.modified.add(fileName);
            break;
        case ORIGIN:
            // The previous line is ADDED. It should be removed,
            // and replaced with a mapping in copied
            String newName = this.added.remove(this.added.size() - 1);
            this.copied.put(newName, fileName);
            break;
        case REMOVED:
            this.removed.add(fileName);
            break;
        case UNKNOWN:
            this.unknown.add(fileName);
            break;
        default:
            throw new IllegalStateException("Unhandled StatusLine type: " + current.getType());
        }
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("status(");
        toStringHelper(s, this.modified, "modified");
        toStringHelper(s, this.added, "added");
        toStringHelper(s, this.removed, "removed");
        toStringHelper(s, this.unknown, "unknown");
        toStringHelper(s, this.missing, "missing");
        toStringHelper(s, this.ignored, "ignored");
        toStringHelper(s, this.clean, "clean");
        s.append(")");
        return s.toString();
    }

    private static void toStringHelper(StringBuilder s, List<String> coll, String name) {
        int size = coll.size();
        if (size == 0) {
            return;
        }
        s.append('[');
        if (size > 5) {
            s.append(size).append(" files");
        } else {
            char sep = '=';
            s.append(name);
            for (String e : coll) {
                s.append(sep).append(e);
                sep = ',';
            }
        }
        s.append(']');
    }
}
