/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.3+10-9d9d15928521.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.commands.flags;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.LogCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class LogCommandFlags extends AbstractCommand {

    protected LogCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "log";
    }

    public static LogCommand on(Repository repository) {
        return new LogCommand(repository);
    }

    /**
     * Set the <tt>--follow</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand follow() {
        cmdAppend("--follow");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--follow-first</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public LogCommand followFirst() {
        cmdAppend("--follow-first");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--date</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand date(String date) {
        cmdAppend(Args.DATE, date);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--copies</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand copies() {
        cmdAppend("--copies");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--keyword</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand keyword(String... texts) {
        cmdAppend("--keyword", texts);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand rev(String... revs) {
        cmdAppend(Args.REVISION, revs);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--removed</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand removed() {
        cmdAppend(Args.REMOVED);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--only-merges</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public LogCommand onlyMerges() {
        cmdAppend("--only-merges");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--user</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand user(String... users) {
        cmdAppend(Args.USER, users);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--only-branch</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public LogCommand onlyBranch(String... branches) {
        cmdAppend("--only-branch", branches);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--branch</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand branch(String... branches) {
        cmdAppend(Args.BRANCH, branches);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--prune</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand prune(String... revs) {
        cmdAppend("--prune", revs);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--hidden</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public LogCommand hidden() {
        cmdAppend("--hidden");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--limit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand limit(int num) {
        cmdAppend("--limit", num);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--no-merges</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand noMerges() {
        cmdAppend("--no-merges");
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--include</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand include(String... patterns) {
        cmdAppend(Args.INCLUDE, patterns);
        return (LogCommand) this;
    }

    /**
     * Set the <tt>--exclude</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#log">Mercurial documentation</a>
     * @return this instance
     */
    public LogCommand exclude(String... patterns) {
        cmdAppend(Args.EXCLUDE, patterns);
        return (LogCommand) this;
    }

}
