package com.aragost.javahg.ext.mq;

/**
 * A patch file
 */
public class Patch {

    private final int index;
    private final String name;
    private final String summary;
    private final boolean applied;

    public Patch(String name, boolean applied, String summary, int index) {
        this.name = name;
        this.applied = applied;
        this.summary = summary;
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public boolean isApplied() {
        return applied;
    }

    public String getSummary() {
        return summary;
    }

    public int getIndex() {
        return index;
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return this.name;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (applied ? 1231 : 1237);
        result = prime * result + index;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((summary == null) ? 0 : summary.hashCode());
        return result;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Patch other = (Patch) obj;
        if (applied != other.applied) {
            return false;
        }
        if (index != other.index) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        if (summary == null) {
            if (other.summary != null) {
                return false;
            }
        } else if (!summary.equals(other.summary)) {
            return false;
        }
        return true;
    }

}
