package com.aragost.javahg.ext.mq;

import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QUnappliedCommandFlags;

public class QUnappliedCommand extends QUnappliedCommandFlags {

    public QUnappliedCommand(Repository repository) {
        super(repository);
        summary();
        cmdAppend("--verbose");
    }

    public List<Patch> execute() {
        return QSeriesCommand.parse(launchString());
    }
}
