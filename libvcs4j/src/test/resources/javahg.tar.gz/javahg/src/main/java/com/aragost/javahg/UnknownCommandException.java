package com.aragost.javahg;

import com.aragost.javahg.internals.AbstractCommand;

/**
 * Exception thrown when an attempt it made to execute a command that the underlying Mercurial command server doesn't
 * know.
 * <p>
 * Since Mercurial from time to time introduce new commands (e.g. phase, graft), JavaHg implements these. But if you
 * attempt to use them against an older version of Mercurial you get this exception.
 * 
 */
public class UnknownCommandException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    // TODO Exceptions are Serializable, AbstractCommand not. So we
    // should not have it as a non-transient field.
    private final AbstractCommand command;

    public UnknownCommandException(AbstractCommand cmd) {
        super(createMessage(cmd));
        this.command = cmd;
    }

    private static String createMessage(AbstractCommand cmd) {
        HgVersion hgVersion = getHgVersion(cmd);
        return "Mercurial command '" + cmd.getCommandName() + "' is not supported by Mercurial version: "
                + hgVersion.getVersionString();
    }

    private static HgVersion getHgVersion(AbstractCommand cmd) {
        HgVersion hgVersion = HgVersion.unknown();
        try {
            hgVersion = cmd.getRepository().getHgVersion();
        } catch (RuntimeException e) {
            // Something went wrong, but ignore this so we can create
            // this exception
        }
        return hgVersion;
    }

    public AbstractCommand getCommand() {
        return command;
    }

}
