package com.aragost.javahg.ext.mq;

import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QAppliedCommandFlags;

public class QAppliedCommand extends QAppliedCommandFlags {

    public QAppliedCommand(Repository repository) {
        super(repository);
        summary();
        cmdAppend("--verbose");
    }

    public List<Patch> execute() {
        return QSeriesCommand.parse(launchString());
    }
}
