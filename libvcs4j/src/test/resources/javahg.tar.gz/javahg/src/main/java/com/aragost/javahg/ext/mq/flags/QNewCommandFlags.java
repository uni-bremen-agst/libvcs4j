/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.1.1+41-63a1bed65fa3.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.ext.mq.flags;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.QNewCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class QNewCommandFlags extends AbstractCommand {

    protected QNewCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "qnew";
    }

    public static QNewCommand on(Repository repository) {
        return new QNewCommand(repository);
    }

    /**
     * Set the <tt>--edit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand edit() {
        cmdAppend("--edit");
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--force</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public QNewCommand force() {
        cmdAppend("--force");
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--currentuser</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand currentuser() {
        cmdAppend("--currentuser");
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--user</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand user(String user) {
        cmdAppend("--user", user);
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--currentdate</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand currentdate() {
        cmdAppend("--currentdate");
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--date</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand date(String date) {
        cmdAppend("--date", date);
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--include</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand include(String... patterns) {
        cmdAppend("--include", patterns);
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--exclude</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand exclude(String... patterns) {
        cmdAppend("--exclude", patterns);
        return (QNewCommand) this;
    }

    /**
     * Set the <tt>--message</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qnew">Mercurial documentation</a>
     * @return this instance
     */
    public QNewCommand message(String text) {
        cmdAppend("--message", text);
        return (QNewCommand) this;
    }

}
