package com.aragost.javahg.internals;

/**
 * This exception is thrown if an error occurs during load of a service with the {@link ServiceLoader}.
 *
 * @author Sebastian Sdorra
 */
public final class ServiceException extends Exception {
    private static final long serialVersionUID = 4453421798347799570L;

    public ServiceException() {
    }

    public ServiceException(String message) {
        super(message);
    }

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceException(Throwable cause) {
        super(cause);
    }

}
