package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QCloneCommandFlags;

public class QCloneCommand extends QCloneCommandFlags {

    public QCloneCommand(Repository repository) {
        super(repository);
    }
}
