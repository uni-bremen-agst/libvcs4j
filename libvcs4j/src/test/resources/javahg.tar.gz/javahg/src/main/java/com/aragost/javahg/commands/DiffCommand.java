/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.DiffCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.Utils;

/**
 * Command class for executing <tt>hg diff</tt>. Set flags from {@link DiffCommandFlags} and call the {@link #execute}
 * method.
 */
public class DiffCommand extends DiffCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public DiffCommand(Repository repository) {
        super(repository);
        cmdAppend(Args.GIT);
    }

    /**
     * Run <tt>hg diff</tt>.
     * 
     * @return the diff as a String.
     */
    public String execute() {
        return launchString();
    }

    /**
     * Run <tt>hg diff</tt> on the files.
     * 
     * @param files
     *            the input files
     * @return the diff as a String.
     */
    public String execute(String... files) {
        return launchString(files);
    }

    /**
     * Run <tt>hg diff</tt> on the files.
     * 
     * @param files
     *            the input files
     * @return the diff as a String.
     */
    public String execute(File... files) {
        return execute(Utils.fileArray2StringArray(files));
    }

    /**
     * Run <tt>hg diff</tt> on the files. Note: The caller is responsible for fully consuming the returned stream
     * 
     * @param files
     *            the input files
     * @return the diff as a stream
     */
    public HgInputStream stream(File... files) {
        return launchStream(Utils.fileArray2StringArray(files));
    }
}
