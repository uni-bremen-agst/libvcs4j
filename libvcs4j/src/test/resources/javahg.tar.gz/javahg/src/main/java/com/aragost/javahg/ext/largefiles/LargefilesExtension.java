package com.aragost.javahg.ext.largefiles;

import com.aragost.javahg.MercurialExtension;

public class LargefilesExtension extends MercurialExtension {

    @Override
    public String getName() {
        return "largefiles";
    }

}
