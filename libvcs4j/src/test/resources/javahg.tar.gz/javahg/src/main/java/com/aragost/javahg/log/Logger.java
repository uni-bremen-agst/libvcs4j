package com.aragost.javahg.log;

/**
 * General interface for logging. This interface is used by each JavaHG class for logging. A implementation of the
 * logger interface can be retrieved by {@link LoggerFactory#getLogger(java.lang.Class)}.
 * 
 */
public interface Logger {

    /**
     * Logs a debugging message - detailed debugging information that can be used for identifying problems without a
     * debugger, e.g. entry/exit points, user errors, recoverable errors, algorithm steps. The application performance
     * is significantly reduced when this logging level is enabled. Not for production use.
     * 
     * @param msg
     *            The message to log.
     */
    public void debug(String msg);

    /**
     * Logs a debugging message - detailed debugging information that can be used for identifying problems without a
     * debugger, e.g. entry/exit points, user errors, recoverable errors, algorithm steps. The application performance
     * is significantly reduced when this logging level is enabled. Not for production use.
     * 
     * @param msg
     *            The message to log.
     */
    public void debug(String msg, Object... args);

    public void debug(String msg, Throwable thrown);

    /**
     * Logs an informational message - information about application progress, e.g. configuration values, service
     * startup/shutdown.
     * 
     * @param msg
     *            The message to log.
     */
    public void info(String msg);

    public void info(String msg, Object... args);

    public void info(String msg, Throwable thrown);

    public void warn(String msg);

    public void warn(String msg, Object... args);

    public void warn(String msg, Throwable thrown);

    public void error(String msg);

    public void error(String msg, Object... args);

    public void error(String msg, Throwable thrown);

    public boolean isInfoEnabled();

    public boolean isDebugEnabled();

    public boolean isWarnEnabled();

    public boolean isErrorEnabled();
}
