package com.aragost.javahg.ext.rebase;

import com.aragost.javahg.MercurialExtension;

public class RebaseExtension extends MercurialExtension {

    @Override
    public String getName() {
        return "rebase";
    }

}
