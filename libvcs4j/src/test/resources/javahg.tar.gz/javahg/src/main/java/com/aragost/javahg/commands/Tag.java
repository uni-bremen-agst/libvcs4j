package com.aragost.javahg.commands;

import com.aragost.javahg.Changeset;

public class Tag implements Comparable<Tag> {

    private final String name;
    private final Changeset changeset;
    private final boolean local;

    public Tag(String name, Changeset changeset, boolean local) {
        this.name = name;
        this.changeset = changeset;
        this.local = local;
    }

    public String getName() {
        return name;
    }

    public Changeset getChangeset() {
        return changeset;
    }

    public boolean isLocal() {
        return local;
    }

    @Override
    public int compareTo(Tag that) {
        return this.getName().compareTo(that.getName());
    }

    @Override
    public String toString() {
        return "tag[" + getName() + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((changeset == null) ? 0 : changeset.hashCode());
        result = prime * result + (local ? 1231 : 1237);
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Tag other = (Tag) obj;
        if (changeset == null) {
            if (other.changeset != null) {
                return false;
            }
        } else if (!changeset.equals(other.changeset)) {
            return false;
        }
        if (local != other.local) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }

}
