/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.3+10-9d9d15928521.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.commands.flags;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.StatusCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class StatusCommandFlags extends AbstractCommand {

    protected StatusCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "status";
    }

    public static StatusCommand on(Repository repository) {
        return new StatusCommand(repository);
    }

    /**
     * Set the <tt>--all</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand all() {
        cmdAppend("--all");
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--modified</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand modified() {
        cmdAppend(Args.MODIFIED);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--added</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand added() {
        cmdAppend(Args.ADDED);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--removed</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand removed() {
        cmdAppend(Args.REMOVED);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--deleted</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand deleted() {
        cmdAppend(Args.DELETED);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--clean</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand clean() {
        cmdAppend(Args.CLEAN);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--unknown</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand unknown() {
        cmdAppend(Args.UNKNOWN);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--ignored</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand ignored() {
        cmdAppend(Args.IGNORED);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--copies</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand copies() {
        cmdAppend("--copies");
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand rev(String... revs) {
        cmdAppend(Args.REVISION, revs);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--change</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand change(String rev) {
        cmdAppend("--change", rev);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--include</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand include(String... patterns) {
        cmdAppend(Args.INCLUDE, patterns);
        return (StatusCommand) this;
    }

    /**
     * Set the <tt>--exclude</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#status">Mercurial documentation</a>
     * @return this instance
     */
    public StatusCommand exclude(String... patterns) {
        cmdAppend(Args.EXCLUDE, patterns);
        return (StatusCommand) this;
    }

}
