/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.internals;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.aragost.javahg.Args;
import com.aragost.javahg.MercurialExtension;
import com.aragost.javahg.log.Logger;
import com.aragost.javahg.log.LoggerFactory;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;

/**
 * This is a singleton to manage Mercurial extensions.
 * <p>
 * To use a Mercurial extension with JavaHg there has to be an implementation of {@link MercurialExtension}. Call the
 * process() method with this class to enable an extension.
 */
public class ExtensionManager {

    private static final Logger LOG = LoggerFactory.getLogger(ExtensionManager.class);

    private static final ExtensionManager INSTANCE = new ExtensionManager();

    private CacheLoader<Class<? extends MercurialExtension>, MercurialExtension> createExtInstance = new CacheLoader<Class<? extends MercurialExtension>, MercurialExtension>() {
        @Override
        public MercurialExtension load(Class<? extends MercurialExtension> klass) {
            MercurialExtension instance = null;
            try {
                instance = klass.newInstance();
            } catch (InstantiationException e) {
                throw Utils.asRuntime(e);
            } catch (IllegalAccessException e) {
                throw Utils.asRuntime(e);
            }
            try {
                instance.initialize();
            } catch (Exception e) {
                getLog().error("Initialization of {} failed", klass);
                getLog().error("The extension will be used anyway");
                getLog().error("Exception: {}", e);
            }
            return instance;
        }
    };

    private LoadingCache<Class<? extends MercurialExtension>, MercurialExtension> extInstances = CacheBuilder.newBuilder().build(
            createExtInstance);

    public static ExtensionManager getInstance() {
        return INSTANCE;
    }

    /**
     * Enable the Mercurial extension for the classes.
     * 
     * @param classes
     * @return list of command line flags needed to enable the extensions
     */
    public List<String> process(Collection<Class<? extends MercurialExtension>> classes) {
        List<String> result = Lists.newArrayList();
        for (Class<? extends MercurialExtension> k : classes) {
            MercurialExtension ext;
            try {
                ext = this.extInstances.get(k);
            } catch (ExecutionException e) {
                throw Utils.asRuntime(e);
            }
            String path = ext.getPath();
            if (path == null) {
                path = "";
            }
            result.add(Args.CONFIG);
            result.add("extensions." + ext.getName() + "=" + path);
        }
        return result;
    }

    public static Logger getLog() {
        return LOG;
    }

}
