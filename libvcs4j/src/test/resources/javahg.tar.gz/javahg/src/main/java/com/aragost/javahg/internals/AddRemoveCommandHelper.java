package com.aragost.javahg.internals;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * Helper class to implement Add and Removed Command.
 */
public class AddRemoveCommandHelper {

    private AbstractCommand command;

    private String prefix;

    public AddRemoveCommandHelper(AbstractCommand command, String prefix) {
        super();
        this.command = command;
        this.prefix = prefix;
    }

    public List<String> execute(String... files) {
        List<String> result = Lists.newArrayList();
        for (String line : command.launchIterator(files)) {
            if (line.startsWith(prefix)) {
                String file = new String(line.substring(prefix.length()));
                result.add(file);
            } else if (line.startsWith("filtering")) { // ignore
                // e.g. filtering <file name> through
            } else {
                command.cleanUp();
                throw new UnexpectedCommandOutputException(this.command, line);
            }
        }
        return result;
    }

    public List<File> execute(File... files) {
        return stringList2fileList(execute(fileArray2StringArray(files)));
    }

    public List<File> execute() {
        return execute(new File[0]);
    }

    /**
     * Helper method to convert Files to Strings
     * 
     * @param files
     * @return
     */
    private final static String[] fileArray2StringArray(File[] files) {
        return Utils.fileArray2StringArray(files);
    }

    /**
     * Helper method to convert Strings to Files
     * 
     * @param strings
     * @return
     * @throws IOException
     */
    private final List<File> stringList2fileList(List<String> strings) {
        String[] strArray = strings.toArray(new String[strings.size()]);
        File[] fileArray = Utils.stringArray2FileArray(this.command.getRepository().getDirectory(), strArray);
        return Lists.newArrayList(fileArray);
    }

}
