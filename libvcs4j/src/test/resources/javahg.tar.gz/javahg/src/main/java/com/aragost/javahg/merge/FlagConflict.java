package com.aragost.javahg.merge;

/**
 * Represent a file where merge gave a flag conflict.
 * <p>
 * Current JavaHg does not provide any API to manipulate this merge. It is merge with the default settings (i.e. no
 * flags)
 */
public class FlagConflict extends MergeFile {

    public FlagConflict(ConflictResolvingContext mergeState, String file) {
        super(mergeState, file);
    }
}
