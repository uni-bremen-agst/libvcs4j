/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.aragost.javahg.internals.UnexpectedCommandOutputException;

/**
 * The statistic returned by running <tt>hg update</tt>.
 */
public class UpdateResult {

    /**
     * This is the main result line returned by hg after an update command is issued.
     */
    private static final Pattern UPDATE_LINE_PATTERN = Pattern.compile(
            "^(.*) files updated, (.*) files merged, (.*) files removed, (.*) files unresolved$");

    /**
     * On some executions, there may be a second line in the console output returned by hg after an update. This pattern
     * handles such cases.
     * <p>
     * An example case is that in {@link UpdateCommandTest#testUpdateCrossesBranches2()}.
     */
    private static final Pattern MULTIPLE_HEADS_PATTERN = Pattern.compile("^(.*) other heads for branch (.*)$");

    private int updated;

    private int merged;

    private int removed;

    private int unresolved;

    /**
     * Tells whether Mercurial reported that the working copy has multiple heads as a result of an update (with no
     * revision specified). This flag can only be set when a merge tool is specified. The exact set of tools (other than
     * internal:fail) remains to be determined.
     */
    private boolean multipleHeads = false;

    private UpdateResult() {
    }

    /**
     * @return number of updated files.
     */
    public int getUpdated() {
        return updated;
    }

    /**
     * @return number of merged files. These are the files that were merged without conflict, see
     *         {@link #getUnresolved()} for the number of files with merge conflicts.
     */
    public int getMerged() {
        return merged;
    }

    /**
     * @return number of removed files.
     */
    public int getRemoved() {
        return removed;
    }

    /**
     * @return number of unresolved files.
     */
    public int getUnresolved() {
        return unresolved;
    }

    /**
     * @return whether the update reported the working copy as having multiple heads.
     */
    public boolean hasMultipleHeads() {
        return multipleHeads;
    }

    /**
     * Factory method to create an {@link UpdateResult}.
     * 
     * @param line
     *            the final line of <tt>hg update</tt>
     * @return the parsed update result.
     */
    public static UpdateResult fromLine(String line) {
        // The format of lines in defined by the patterns (see private fields).
        UpdateResult result = new UpdateResult();
        Matcher matcher = UPDATE_LINE_PATTERN.matcher(line);
        if (!matcher.matches()) {
            Matcher matcherMultipleHeads = MULTIPLE_HEADS_PATTERN.matcher(line);
            if (matcherMultipleHeads.matches()) {
                result.multipleHeads = true;
                return result;
            }
            throw new UnexpectedCommandOutputException("Unexpected format: " + line);
        }
        int[] numbers = new int[4];
        for (int i = 0; i < 4; i++) {
            numbers[i] = Integer.parseInt(line.substring(matcher.start(i + 1), matcher.end(i + 1)));
        }
        result.updated = numbers[0];
        result.merged = numbers[1];
        result.removed = numbers[2];
        result.unresolved = numbers[3];
        return result;
    }

    @Override
    public String toString() {
        String res = "updated " + getUpdated() + ", merged " + getMerged() + ", removed " + getRemoved()
                + ", unresolved " + getUnresolved();
        if (multipleHeads) {
            res = res + " | with multiple heads";
        }
        return res;
    }
}
