package com.aragost.javahg;

import java.util.Date;
import java.util.TimeZone;

/**
 * Represents a timestamp and a timezone offset
 */
public class DateTime {

    /**
     * Timestamp in milliseconds since 1970
     */
    private long timestamp;

    /**
     * Timezone offset in milliseconds (hg format, ms *west* of UTC)
     */
    private int tzOffset;

    /**
     * Construct a new DateTime with the specified timestamp and timezone
     * 
     * @param timestamp
     * @param tzOffset
     *            (hg format, ms *west* of UTC)
     */
    public DateTime(long timestamp, int tzOffset) {
        this.timestamp = timestamp;
        this.tzOffset = tzOffset;
    }

    /**
     * Construct a new DateTime with the specified date and timezone
     * 
     * @param date
     * @param tz
     *            (Java format, east of UTC, like ISO8601)
     */
    public DateTime(Date date, TimeZone tz) {
        this.timestamp = date.getTime();
        // Hg uses reversed (relative to Java) timezones
        this.tzOffset = -tz.getOffset(this.timestamp);
    }

    /**
     * @deprecated Use constructor with tz argument
     * @param date
     */
    @Deprecated
    public DateTime(Date date) {
        this(date, TimeZone.getDefault());
    }

    /**
     * Create a new instance by parsing the given String.
     * <p>
     * The string should be in standard Mercurial format, i.e. '&lt;seconds since 1970&gt; &lt;timezone offset in
     * seconds&gt;'
     * 
     * @param string
     * @return
     */
    public static DateTime parse(String string) {
        String[] parts = string.split(" ");
        if (parts.length != 2) {
            throw new IllegalArgumentException("Wrong date format: " + string);
        }
        long millis = 1000L * Long.valueOf(parts[0]);
        int timezoneOffset = 1000 * Integer.valueOf(parts[1]);
        return new DateTime(millis, timezoneOffset);
    }

    /**
     * 
     * @return the timestamp as a java.util.Date object
     */
    public Date getDate() {
        return new Date(this.timestamp);
    }

    /**
     * 
     * @return the time/zone formatted for Mercurial
     */
    public String getHgString() {
        return "" + (this.timestamp / 1000) + " " + this.tzOffset / 1000;
    }

    @Override
    public String toString() {
        return getHgString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
        result = prime * result + tzOffset;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DateTime other = (DateTime) obj;
        if (timestamp != other.timestamp) {
            return false;
        }
        if (tzOffset != other.tzOffset) {
            return false;
        }
        return true;
    }

}
