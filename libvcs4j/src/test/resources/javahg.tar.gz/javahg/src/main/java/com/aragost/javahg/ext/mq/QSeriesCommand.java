package com.aragost.javahg.ext.mq;

import java.util.ArrayList;
import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QSeriesCommandFlags;

public class QSeriesCommand extends QSeriesCommandFlags {

    public QSeriesCommand(Repository repository) {
        super(repository);
        summary();
        cmdAppend("--verbose");
    }

    public List<Patch> execute() {
        return parse(launchString());
    }

    /**
     * TODO: use stream based parsing rather than splitting strings
     * 
     * @param output
     *            The output to parse
     * @return Non null list of patches in output
     */
    protected static List<Patch> parse(String output) {
        List<Patch> list = new ArrayList<Patch>();
        if (output != null && output.indexOf("\n") >= 0) {
            String[] patches = output.split("\n");
            int i = 1;

            for (String string : patches) {
                String[] components = string.split(":", 2);
                String[] patchData = components[0].trim().split(" ", 3);

                list.add(new Patch(patchData[2].trim(), "A".equals(patchData[1]), components[1].trim(), i++));
            }
        }
        return list;
    }

}
