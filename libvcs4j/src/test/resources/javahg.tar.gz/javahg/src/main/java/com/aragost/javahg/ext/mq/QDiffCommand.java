package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QDiffCommandFlags;

public class QDiffCommand extends QDiffCommandFlags {

    public QDiffCommand(Repository repository) {
        super(repository);
    }

}
