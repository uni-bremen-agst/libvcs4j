/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import com.aragost.javahg.internals.AbstractCommand;
import com.google.common.base.Strings;

/**
 * Generic exception thrown when executing a Mercurial command fails.
 */
public class ExecutionException extends RuntimeException {

    private static final String ABORT_PREFIX = "abort: ";

    private static final long serialVersionUID = 1L;

    // TODO Exceptions are Serializable, AbstractCommand not. So we
    // should not have it as a non-transient field.
    private final AbstractCommand command;

    /**
     * @param message
     *            the exception message
     * @param command
     *            the command that failed.
     */
    public ExecutionException(AbstractCommand command, String message) {
        super(message);
        this.command = command;
    }

    /**
     * @param command
     *            the command that failed.
     */
    public ExecutionException(AbstractCommand command) {
        this(command, generateMessage(command));
    }

    /**
     * @return the command that failed.
     */
    public AbstractCommand getCommand() {
        return command;
    }

    /**
     * Generate generic exception message based on the command.
     * 
     * @param cmd
     * @return
     */
    private static String generateMessage(AbstractCommand cmd) {
        String s = cmd.getErrorString().trim();
        if (Strings.isNullOrEmpty(s)) {
            s = "Error in command '" + cmd.getCommandName() + "' [rc: " + cmd.getReturnCode() + "]";
        }
        if (s.startsWith(ABORT_PREFIX)) {
            s = s.substring(ABORT_PREFIX.length());
        }
        return s;
    }

}
