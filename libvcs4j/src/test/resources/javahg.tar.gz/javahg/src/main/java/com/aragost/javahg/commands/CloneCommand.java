/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.CloneCommandFlags;

/**
 * Command class for executing <tt>hg clone</tt>. Set flags from {@link CloneCommandFlags} and call the {@link #execute}
 * method.
 * <p>
 * Use this command class to clone the current repository to somewhere else without opening the destination. An example
 * of this is cloning to a remote SSH path.
 * <p>
 * To clone a remote repository to a local destination, use the {@link Repository#clone(java.io.File, String)} factory
 * method.
 */
public class CloneCommand extends CloneCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public CloneCommand(Repository repository) {
        super(repository);
        cmdAppend(repository.getDirectory().toString());
        cmdAppend("-y");
    }

    /**
     * Clone the current repository to another destination.
     * <p>
     * The equivalent command line call is <tt>hg clone . destination</tt>.
     * 
     * @param destination
     *            a path to a local destination or a (SSH) URL to a remote destination.
     * @return the output of the clone operation.
     * @throws IOException
     */
    public String execute(String destination) throws IOException {
        return launchString(destination);
    }

}
