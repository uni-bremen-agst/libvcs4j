/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.BranchCommandFlags;
import com.aragost.javahg.internals.HgInputStream;

/**
 * Command class for executing <tt>hg branch</tt>. Set flags from {@link BranchCommandFlags} and run
 * {@link #set(String)} to set a branch or {@link #clean()} to reset the branch name.
 */
public class BranchCommand extends BranchCommandFlags {

    private static final byte[] CLEAN_PREFIX = "reset working directory to branch ".getBytes();

    public BranchCommand(Repository repository) {
        super(repository);
    }

    /**
     * Get the branch for working directory.
     * 
     * @return name of branch for working copy
     */
    public String get() {
        return launchString().trim();
    }

    /**
     * Set the branch for working directory.
     * 
     * @param branchName
     */
    public void set(String branchName) {
        // Trim branchName. Mercurial commandserver seems to be bit
        // confused otherwise.
        launchString(branchName.trim());
    }

    /**
     * Reset the branch name for working directory to branch name of first parent
     * 
     * @return old branch name
     * @throws IOException
     */
    public String clean() throws IOException {
        HgInputStream stream = launchStream(Args.CLEAN);
        stream.mustMatch(CLEAN_PREFIX);
        String oldName = stream.textUpTo('\n');
        stream.consumeAll();
        return oldName;
    }

}
