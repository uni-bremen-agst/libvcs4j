package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QNextCommandFlags;

public class QNextCommand extends QNextCommandFlags {

    public QNextCommand(Repository repository) {
        super(repository);
    }

}
