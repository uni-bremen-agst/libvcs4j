/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.internals;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.aragost.javahg.commands.CancelledExecutionException;
import com.aragost.javahg.internals.AbstractCommand.State;
import com.aragost.javahg.log.Logger;
import com.aragost.javahg.log.LoggerFactory;

/**
 * An input stream that will make everything written to the output channel for one command available as an input stream.
 * <p>
 * Reading from this stream will add to the {@link ByteArrayOutputStream} for the other channels, as blocks for other
 * channels are detected.
 * <p>
 * The stream will indicate EOF when the 'r'esult block has been read.
 * <p>
 * If a 'L' block is read it will also indicate EOF. After a respond to the 'L' block is sent to the server, you can
 * call reopen() and read the rest of the input.
 */
public class OutputChannelInputStream extends InputStream {

    private static final Logger LOG = LoggerFactory.getLogger(OutputChannelInputStream.class);

    private final InputStream channelStream;

    private final AbstractCommand cmd;

    private final Server server;

    /**
     * The current 'o' channel. If this is {@code null} then eof has been reached.
     */
    private BlockInputStream currentOutputChannelBlock = BlockInputStream.EMPTY;

    /**
     * 
     * @param channelStream
     * @param cmd
     * @throws IOException
     */
    OutputChannelInputStream(InputStream channelStream, Server server, AbstractCommand cmd) throws IOException {
        this.channelStream = channelStream;
        this.cmd = cmd;
        this.server = server;
        try {
            findNextOutputChannelBlock();
        } catch (RuntimeException e) {
            verifyServerProcess(e);
            throw e;
        } catch (IOException e) {
            verifyServerProcess(e);
            throw e;
        }
    }

    @Override
    public int read() throws IOException {
        if (this.currentOutputChannelBlock == null) {
            return -1;
        }
        try {
            int ch = this.currentOutputChannelBlock.read();
            if (ch == -1) {
                findNextOutputChannelBlock();
                return read();
            }
            return ch;
        } catch (RuntimeException e) {
            verifyServerProcess(e);
            throw e;
        } catch (IOException e) {
            verifyServerProcess(e);
            throw e;
        }
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (this.currentOutputChannelBlock == null) {
            return -1;
        }
        try {
            int n = this.currentOutputChannelBlock.read(b, off, len);
            if (n > 0) {
                return n;
            } else if (n == -1) {
                findNextOutputChannelBlock();
                return read(b, off, len);
            } else {
                return 0;
            }
        } catch (RuntimeException e) {
            verifyServerProcess(e);
            throw e;
        } catch (IOException e) {
            verifyServerProcess(e);
            throw e;
        }
    }

    @Override
    public int available() throws IOException {
        if (this.currentOutputChannelBlock == null) {
            return 0;
        }
        return this.currentOutputChannelBlock.available();
    }

    /**
     * Find the next output channel block.
     * <p>
     * The method will handle other channels while looking for an o-channel block.
     * 
     * @throws IOException
     */
    private void findNextOutputChannelBlock() throws IOException {
        if (this.currentOutputChannelBlock == null) {
            throw new IllegalStateException();
        }
        if (this.currentOutputChannelBlock.getBytesLeft() > 0) {
            throw new IllegalStateException("Still bytes available in currentOutputChannelBlock");
        }
        this.currentOutputChannelBlock = null;
        BlockInputStream blockInputStream = null;
        while (true) {
            if (cmd.getState() == State.CANCELING) {
                throw new CancelledExecutionException(cmd);
            }

            blockInputStream = new BlockInputStream(this.channelStream);
            char channel = blockInputStream.getChannel();
            switch (channel) {
            case 'o':
                this.currentOutputChannelBlock = blockInputStream;
                return;
            case 'e':
                this.cmd.addToError(blockInputStream);
                break;
            case 'r':
                if (blockInputStream.getLength() != 4) {
                    throw new IllegalStateException("Length 4 expected for channel 'r'");
                }
                int returnCode = blockInputStream.readInt();
                LOG.debug("Command '{}' gave return code: {}", this.cmd.getCommandName(), returnCode);
                this.cmd.handleReturnCode(returnCode);
                return;
            case 'L':
                this.cmd.setLineChannelLength(blockInputStream.getLength());
                return;
            default:
                if (Character.isLowerCase(channel)) {
                    // Ignore an unrecognized channel
                    Utils.consumeAll(blockInputStream);
                } else {
                    // Unrecognized but mandatory channel
                    throw new IllegalStateException("Unknown channel: " + channel);
                }
            }
        }
    }

    /**
     * Reopen this stream to read pending 'o' blocks.
     * <p>
     * The stream is indicating EOF when an 'L' block is encountered. With this method the rest of the rest of the 'o'
     * blocks can be read.
     */
    public void reopen() {
        this.currentOutputChannelBlock = BlockInputStream.EMPTY;
        try {
            findNextOutputChannelBlock();
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
    }

    /**
     * @param e
     */
    private void verifyServerProcess(Exception e) {
        this.server.verifyServerProcess(e);
    }
}
