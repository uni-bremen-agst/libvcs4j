/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.3+10-9d9d15928521.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.commands.flags;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.OutgoingCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class OutgoingCommandFlags extends AbstractCommand {

    protected OutgoingCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "outgoing";
    }

    public static OutgoingCommand on(Repository repository) {
        return new OutgoingCommand(repository);
    }

    /**
     * Set the <tt>--force</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand force() {
        cmdAppend(Args.FORCE);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand rev(String... revs) {
        cmdAppend(Args.REVISION, revs);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--newest-first</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand newestFirst() {
        cmdAppend("--newest-first");
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--bookmarks</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand bookmarks() {
        cmdAppend(Args.BOOKMARKS);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--branch</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand branch(String... branches) {
        cmdAppend(Args.BRANCH, branches);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--limit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand limit(String num) {
        cmdAppend("--limit", num);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--no-merges</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand noMerges() {
        cmdAppend("--no-merges");
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--ssh</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand ssh(String cmd) {
        cmdAppend("--ssh", cmd);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--remotecmd</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand remotecmd(String cmd) {
        cmdAppend("--remotecmd", cmd);
        return (OutgoingCommand) this;
    }

    /**
     * Set the <tt>--insecure</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#outgoing">Mercurial documentation</a>
     * @return this instance
     */
    public OutgoingCommand insecure() {
        cmdAppend("--insecure");
        return (OutgoingCommand) this;
    }

}
