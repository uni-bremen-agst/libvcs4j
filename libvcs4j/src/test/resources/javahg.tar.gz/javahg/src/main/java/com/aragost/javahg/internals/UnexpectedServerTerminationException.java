package com.aragost.javahg.internals;

public class UnexpectedServerTerminationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int exitValue;

    public UnexpectedServerTerminationException(int rc, Throwable cause) {
        super("Server process terminated unexpectedly with exitvalue: " + rc, extractRealCause(cause));
        this.exitValue = rc;
    }

    private static Throwable extractRealCause(Throwable cause) {
        if (cause instanceof RuntimeIOException) {
            return cause.getCause();
        }
        return cause;
    }

    public int getExitValue() {
        return exitValue;
    }

}
