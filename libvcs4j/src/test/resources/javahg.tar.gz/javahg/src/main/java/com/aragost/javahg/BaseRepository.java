/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

import java.io.File;
import java.nio.charset.CharsetDecoder;

import com.aragost.javahg.internals.ServerPool;
import com.aragost.javahg.internals.Utils;

/**
 * This is a standard Repository with no bundle overlaid
 */
public class BaseRepository extends Repository {

    private RepositoryConfiguration configuration;

    private final File directory;

    private ServerPool serverPool;

    BaseRepository(RepositoryConfiguration conf, File directory, boolean performInit, String cloneUrl) {
        super(conf.getCachePolicy());
        this.configuration = conf;
        this.directory = Utils.resolveSymlinks(directory);

        String hgBin = this.configuration.getHgBin();
        File hgBinFile = new File(hgBin);
        if (hgBinFile.isAbsolute() && !hgBinFile.exists()) {
            throw new IllegalArgumentException("" + hgBin + " does not exist");
        }

        serverPool = new ServerPool(configuration, this.directory, performInit, cloneUrl);
        serverPool.incrementRefCount();
    }

    @Override
    public ServerPool getServerPool() {
        return this.serverPool;
    }

    @Override
    public File getDirectory() {
        return this.directory;
    }

    public RepositoryConfiguration getConfiguration() {
        return configuration;
    }

    @Override
    public BaseRepository getBaseRepository() {
        return this;
    }

    /**
     * @return a new {@link CharsetDecoder} instance for this server.
     */
    @Override
    public CharsetDecoder newDecoder() {
        return getServerPool().newDecoder();
    }
}
