package com.aragost.javahg.ext.rebase;

import java.io.IOException;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.rebase.flags.RebaseCommandFlags;
import com.aragost.javahg.ext.rebase.merge.RebaseConflictResolvingContext;
import com.aragost.javahg.internals.RuntimeIOException;

public class RebaseCommand extends RebaseCommandFlags {

    private boolean abort;
    private boolean hasConflicts;

    public RebaseCommand(Repository repository) {
        super(repository);
    }

    @Override
    protected boolean isSuccessful() {
        return super.isSuccessful() || hasConflicts;
    }

    /**
     * @see #executeAbort()
     * @see com.aragost.javahg.ext.rebase.flags.RebaseCommandFlags#abort()
     */
    @Override
    public RebaseCommand abort() {
        this.abort = true;

        return super.abort();
    }

    /**
     * Execute a rebase.
     * 
     * Note: keep/delete conficts are not currently supported - the decision can't be changed. getRemote() of the
     * returned context will return null.
     * 
     * Note: do not use {@link #abort()} with this, instead use {@link #executeAbort()}.
     * 
     * @return Conflict context.
     */
    public RebaseConflictResolvingContext execute() {
        if (abort) {
            throw new IllegalStateException("Use executeAbort() instead");
        }

        try {
            RebaseConflictResolvingContext result = new RebaseConflictResolvingContext(this);
            result.processStream(launchStream("-y", "--tool", "internal:fail"));
            return result;
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
    }

    public RebaseConflictResolvingContext executeContinue() {
        cmdAppend("--continue");
        return execute();
    }

    public void executeAbort() {
        abort();
        launchString();
    }

    @Override
    protected void doneHook() {
        String errorString = getErrorString();
        this.hasConflicts = errorString.indexOf("abort: unresolved conflicts, can't continue") >= 0
                || errorString.indexOf("abort: unresolved conflicts (see hg resolve, then hg rebase --continue") >= 0
                || errorString.indexOf("unresolved conflicts (see hg resolve, then hg rebase --continue)") >= 0;
    }

    @Override
    protected void clear() {
        super.clear();
        this.hasConflicts = false;
    }
}
