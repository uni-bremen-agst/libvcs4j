/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.AnnotateCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * Command class for executing <tt>hg annotate</tt>. Set flags from {@link AnnotateCommandFlags} and see the
 * {@link #execute} method for how to run the command.
 */
public class AnnotateCommand extends AnnotateCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public AnnotateCommand(Repository repository) {
        super(repository);
        cmdAppend("--number");
    }

    /**
     * Execute <tt>hg annotate</tt> for the specified file.
     * <p>
     * On the command line, Mercurial can annotate more than one file, JavaHg can only annotate one file for each call
     * (but the overhead is negligible to make multiple calls).
     * 
     * @param file
     * @return list of annotated lines.
     * @throws IOException
     */
    public List<AnnotateLine> execute(String file) throws IOException {
        Repository repo = getRepository();
        List<Integer> revisions = Lists.newArrayList();
        List<String> lines = Lists.newArrayList();
        HgInputStream stream = launchStream(file);
        while (stream.peek() != -1) {
            revisions.add(stream.revisionUpTo(':'));
            long res = stream.skip(1);
            lines.add(stream.textUpTo('\n'));
        }
        Map<Integer, Changeset> revNumMap = createRevNumMap(repo, revisions);
        int size = lines.size();
        List<AnnotateLine> result = Lists.newArrayListWithCapacity(size);
        for (int i = 0; i < size; i++) {
            Changeset changeset = revNumMap.get(revisions.get(i));
            result.add(new AnnotateLine(changeset, lines.get(i)));
        }
        return result;
    }

    /**
     * Create a map mapping revision numbers to Changesets
     * 
     * @param repo
     * @param revisions
     * @return
     */
    private static Map<Integer, Changeset> createRevNumMap(Repository repo, List<Integer> revisions) {
        Collection<Integer> uniqRevs = Sets.newHashSet(revisions);
        String[] revs = new String[uniqRevs.size()];
        int index = 0;
        for (Integer rev : uniqRevs) {
            revs[index++] = String.valueOf(rev);
        }
        LogCommand logCmd = LogCommand.on(repo).rev(revs);
        Map<Integer, Changeset> revNumMap = Maps.newHashMap();
        for (Changeset cs : logCmd.execute()) {
            revNumMap.put(cs.getRevision(), cs);
        }
        return revNumMap;
    }

}
