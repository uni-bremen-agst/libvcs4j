/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.3+10-9d9d15928521.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.commands.flags;

import com.aragost.javahg.Args;
import com.aragost.javahg.DateTime;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.TagCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class TagCommandFlags extends AbstractCommand {

    protected TagCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "tag";
    }

    public static TagCommand on(Repository repository) {
        return new TagCommand(repository);
    }

    /**
     * Set the <tt>--force</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand force() {
        cmdAppend(Args.FORCE);
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--local</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand local() {
        cmdAppend("--local");
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand rev(String rev) {
        cmdAppend(Args.REVISION, rev);
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--remove</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand remove() {
        cmdAppend("--remove");
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--message</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand message(String text) {
        cmdAppend(Args.MESSAGE, text);
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--date</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand date(DateTime date) {
        cmdAppend(Args.DATE, date);
        return (TagCommand) this;
    }

    /**
     * Set the <tt>--user</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#tag">Mercurial documentation</a>
     * @return this instance
     */
    public TagCommand user(String user) {
        cmdAppend(Args.USER, user);
        return (TagCommand) this;
    }

}
