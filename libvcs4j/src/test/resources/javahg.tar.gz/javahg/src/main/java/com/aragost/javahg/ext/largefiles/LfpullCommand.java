package com.aragost.javahg.ext.largefiles;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.largefiles.flags.LfpullCommandFlags;

public class LfpullCommand extends LfpullCommandFlags {

    public LfpullCommand(Repository repository) {
        super(repository);
        cmdAppend("-y");
    }

    public void execute() {
        launchStream();
    }
}
