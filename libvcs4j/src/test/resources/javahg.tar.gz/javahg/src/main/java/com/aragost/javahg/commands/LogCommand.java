/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.List;

import com.aragost.javahg.Args;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.LogCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.Utils;

/**
 * Command class for executing <tt>hg log</tt>. Set flags from {@link LogCommandFlags} and call the
 * {@link #execute(String...)} method.
 */
public class LogCommand extends LogCommandFlags {

    private String stylePath;
    private boolean eager = false;

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public LogCommand(Repository repository) {
        this(repository, Changeset.CHANGESET_STYLE_PATH);
    }

    /**
     * Construct a LogCommand using the specified template.
     * 
     * @param repository
     * @param stylePath
     */
    protected LogCommand(Repository repository, String stylePath) {
        super(repository);
        withDebugFlag();
        this.stylePath = stylePath;
    }

    /**
     * Enable eager load for changeset file data.
     * 
     * @return {@code this}
     */
    public LogCommand fileStatus() {
        eager = true;
        stylePath = Changeset.CHANGESET_EAGER_STYLE_PATH;
        return this;
    }

    /**
     * @param files
     *            an optional list of files to retrieve the log for. With no files, all changesets are considered.
     * @return the log as a list of changesets
     */
    public List<Changeset> execute(String... files) {
        if (stylePath != null) {
            cmdAppend(Args.STYLE, stylePath);
        }
        HgInputStream stream = launchStream(files);
        return Changeset.readListFromStream(getRepository(), stream, eager);
    }

    /**
     * Execute the log command and return a single Changeset.
     * <p>
     * If the log command gives more than one changeset an {@link IllegalArgumentException} is thrown. <code>null</code>
     * is returned if the log command gives no Changesets.
     * 
     * @param files
     * @return a single Changeset
     * @throws IllegalArgumentException
     *             if the log command returns more than one changeset
     */
    public Changeset single(String... files) {
        return Utils.single(execute(files));
    }

}
