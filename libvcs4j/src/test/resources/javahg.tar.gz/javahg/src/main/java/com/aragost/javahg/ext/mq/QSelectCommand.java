package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QSelectCommandFlags;

public class QSelectCommand extends QSelectCommandFlags {

    public QSelectCommand(Repository repository) {
        super(repository);
    }

}
