package com.aragost.javahg.internals;

import java.io.File;
import java.util.Map;

import com.aragost.javahg.Repository;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Maps;

public class CopyRenameHelper {

    public static Map<File, File> parse(Repository repo, File[] files, LineIterator output, String prefix) {
        Map<File, File> result = Maps.newHashMap();

        // Make all files relative to repository
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            files[i] = repo.relativeFile(file);
        }

        int currentSrc = 0;
        File src = files[currentSrc];
        for (String line : output) {
            if (line.startsWith(prefix)) {
                if (!line.substring(prefix.length()).startsWith(src.getPath())) {
                    currentSrc++;
                    src = files[currentSrc];
                }
                String[] names = CopyRenameHelper.parseCopyLine(line, prefix);

                if (names != null) {
                    result.put(new File(names[1]), new File(names[0]));
                }
            } else if (line.startsWith("filtering")) { // ignore
                // e.g. filtering <file name> through
            } else {
                throw new UnexpectedCommandOutputException("could not parse '" + line + "'");
            }
        }
        return result;
    }

    @VisibleForTesting
    public static String[] parseCopyLine(String line, String prefix) {
        String lLine = line;
        lLine = lLine.substring(prefix.length()).trim();

        int nCut = lLine.indexOf(" to ");

        if (nCut < 0) {
            return null;
        }

        return new String[] { lLine.substring(0, nCut), lLine.substring(nCut + 4) };
    }

}
