/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;

import com.aragost.javahg.internals.BaseStatusLine;
import com.aragost.javahg.internals.HgInputStream;

/**
 * A parsed line from the <tt>hg status</tt> output.
 */
public class StatusLine extends BaseStatusLine<StatusLine.Type> {

    /**
     * Status line types.
     */
    public enum Type {

        /**
         * A modified file.
         */
        MODIFIED('M'),
        /**
         * An added file.
         */
        ADDED('A'),
        /**
         * A removed file.
         */
        REMOVED('R'),
        /**
         * A clean file.
         */
        CLEAN('C'),
        /**
         * A missing file (deleted outside of Mercurial)
         */
        MISSING('!'),
        /**
         * An unknown file.
         */
        UNKNOWN('?'),
        /**
         * An ignored file.
         */
        IGNORED('I'),
        /**
         * The origin of a copied file.
         */
        ORIGIN(' ');

        private final char discriminator;

        private Type(char discriminator) {
            this.discriminator = discriminator;
        }

        public int getDiscriminator() {
            return this.discriminator;
        }
    }

    /**
     * @param stream
     *            the output of <tt>hg status</tt>
     * @return the parsed status line
     * @throws IOException
     */
    public static StatusLine fromStream(HgInputStream stream) throws IOException {
        StatusLine result = new StatusLine();
        result.initFromStream(stream);
        return result;
    }

    @Override
    protected Type typeForChar(char ch) {
        for (Type t : Type.values()) {
            if (t.getDiscriminator() == ch) {
                return t;
            }
        }
        throw new IllegalArgumentException("No status type for " + ch);
    }
}
