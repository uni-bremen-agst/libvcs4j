/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.AddRemoveCommandFlags;
import com.aragost.javahg.internals.UnexpectedCommandOutputException;
import com.google.common.collect.Lists;

/**
 * Command class for executing <tt>hg addremove</tt>. Set flags from {@link AddRemoveCommandFlags} and see the
 * {@link #execute()} method for how to run the command.
 */
public class AddRemoveCommand extends AddRemoveCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public AddRemoveCommand(Repository repository) {
        super(repository);
        withDebugFlag();
    }

    /**
     * Check if the command ended successfully.
     * <p>
     * In contrast with Mercurial, a return code of 1 is considered to be successful. Mercurial returns 1 if some files
     * could not be found, but at the same time it does add the files that could be found.
     * 
     * @return true if the command exited with 0 or 1.
     */
    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    /**
     * @return List of added or removed files
     */
    public List<String> execute() {
        List<String> result = Lists.newArrayList();
        for (String line : launchIterator(new String[0])) {
            String prefix = null;

            final String ADDING = "adding ";
            final String REMOVING = "removing ";

            if (line.startsWith(ADDING)) {
                prefix = ADDING;
            } else if (line.startsWith(REMOVING)) {
                prefix = REMOVING;
            }

            if (prefix != null) {
                String file = new String(line.substring(prefix.length()));
                result.add(file);
            } else {
                if (line.startsWith("searching for exact renames")) {
                    continue;
                }

                // TODO: should clean up be called here? If so it should be for all
                // other uses of launchIterator in a finally block
                // cleanUp();
                throw new UnexpectedCommandOutputException(this, line);
            }
        }
        return result;
    }
}
