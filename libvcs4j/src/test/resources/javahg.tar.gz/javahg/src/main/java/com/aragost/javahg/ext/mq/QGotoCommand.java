package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QGotoCommandFlags;

public class QGotoCommand extends QGotoCommandFlags {

    public QGotoCommand(Repository repository) {
        super(repository);
    }

}
