/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aragost.javahg.log;

/**
 *
 * @author Sebastian Sdorra
 */
public class JULLoggerFactory extends LoggerFactory {

    @Override
    protected Logger getLoggerInstance(Class<?> cls) {
        return new JULLogger(cls.getName());
    }

}
