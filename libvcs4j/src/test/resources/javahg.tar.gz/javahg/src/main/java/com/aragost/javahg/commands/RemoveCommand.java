/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.RemoveCommandFlags;
import com.aragost.javahg.internals.AddRemoveCommandHelper;

/**
 * Command class for executing <tt>hg remove</tt>. Set flags from {@link RemoveCommandFlags} and call the
 * {@link #execute} method.
 */
public class RemoveCommand extends RemoveCommandFlags {

    private AddRemoveCommandHelper helper;

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public RemoveCommand(Repository repository) {
        super(repository);
        helper = new AddRemoveCommandHelper(this, "removing ");
        withDebugFlag();
    }

    /**
     * Check if the command ended successfully.
     * <p>
     * In contrast with Mercurial, a return code of 1 is considered to be successful. Mercurial returns 1 if some files
     * could not be found, but at the same time it does remove the files that could be found.
     * 
     * @return true if the command exited with 0 or 1.
     */
    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    /**
     * Execute the remove command, and return list of files removed.
     * 
     * @param files
     *            the files and directories to remove.
     * @return list of removed files.
     */
    public List<String> execute(String... files) {
        return this.helper.execute(files);
    }

    /**
     * Execute the remove command, and return list of files removed.
     * 
     * @param files
     *            the files and directories to remove.
     * @return list of removed files.
     */
    public List<File> execute(File... files) {
        return this.helper.execute(files);
    }

    public List<File> execute() {
        return this.helper.execute();
    }
}
