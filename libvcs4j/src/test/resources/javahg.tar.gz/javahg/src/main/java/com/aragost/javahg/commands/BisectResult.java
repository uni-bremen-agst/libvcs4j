package com.aragost.javahg.commands;

public class BisectResult {
    private final String message;

    protected BisectResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public boolean isComplete() {
        return message.indexOf("The first bad revision is:") >= 0;
    }
}
