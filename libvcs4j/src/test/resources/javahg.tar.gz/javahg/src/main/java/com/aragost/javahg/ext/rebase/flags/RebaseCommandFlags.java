/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.1.1+41-63a1bed65fa3.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.ext.rebase.flags;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.rebase.RebaseCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class RebaseCommandFlags extends AbstractCommand {

    protected RebaseCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "rebase";
    }

    public static RebaseCommand on(Repository repository) {
        return new RebaseCommand(repository);
    }

    /**
     * Set the <tt>--source</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand source(String rev) {
        cmdAppend("--source", rev);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--base</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand base(String rev) {
        cmdAppend("--base", rev);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand rev(String... revs) {
        cmdAppend("--rev", revs);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--dest</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand dest(String rev) {
        cmdAppend("--dest", rev);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--collapse</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand collapse() {
        cmdAppend("--collapse");
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--message</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand message(String text) {
        cmdAppend("--message", text);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--edit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand edit() {
        cmdAppend("--edit");
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--keep</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand keep() {
        cmdAppend("--keep");
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--keepbranches</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand keepbranches() {
        cmdAppend("--keepbranches");
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--detach</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand detach() {
        cmdAppend("--detach");
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--tool</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand tool(String value) {
        cmdAppend("--tool", value);
        return (RebaseCommand) this;
    }

    /**
     * Set the <tt>--abort</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#rebase">Mercurial documentation</a>
     * @return this instance
     */
    public RebaseCommand abort() {
        cmdAppend("--abort");
        return (RebaseCommand) this;
    }

}
