/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.internals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.aragost.javahg.commands.ManifestMergeOracle;
import com.aragost.javahg.commands.UpdateResult;
import com.google.common.io.ByteStreams;

/**
 * A helper class to parse output from update and merge commands.
 */
public class UpdateMergeHelper {

    /**
     * Pattern of the message output by hg which denotes that some answers are expected and need to be provided
     * interactively.
     * <p>
     * TODO: check whether this message is equivalent because hg 4.0 (Dec 2016) gave me this on Windows in a manual test
     * (when no merge tool is specified): <br>
     * 
     * <pre>
     * other [destination] changed test.txt which local [working copy] deleted 
     * use (c)hanged version, leave (d)eleted, or leave (u)nresolved?
     * </pre>
     * 
     * Scenario of the test: csetBase (#0) has two descendants cset1 and cset2. One file in all csets, modified in each.
     * At cset2, the working copy deletes the file. <code>hg update 0</code> produces the message above, but not the
     * message in the variable below. Interactivity must be enabled, and consequently, <code>--tool internal:fail</code>
     * must not be specified.
     */
    private static final Pattern MANIFEST_MERGE_PATTERN = Pattern.compile(
            "remote changed (.*) which local deleted\n" + "use \\(c\\)hanged version or leave \\(d\\)eleted\\? ");

    private InputStream stdout;

    private ManifestMergeOracle oracle;

    private AbstractCommand command;

    public UpdateMergeHelper(InputStream stdout, ManifestMergeOracle oracle, AbstractCommand command) {
        this.stdout = stdout;
        this.oracle = oracle;
        this.command = command;
    }

    public void merge() throws IOException {
        processManifestMergeConflictPrompting();
    }

    public UpdateResult update() throws IOException {
        String output = processManifestMergeConflictPrompting();
        BufferedReader reader = new BufferedReader(new StringReader(output));
        String line;
        UpdateResult result = null;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("merging ")) {
                // Just ignore
            } else if (line.equals("use 'hg resolve' to retry unresolved file merges")) {
                // Ignore
            } else if (line.contains("largefiles")) {
                // Ignore
            } else if (line.contains("activating bookmark") || line.contains("leaving bookmark ")) {
                // Ignore
            } else {
                result = UpdateResult.fromLine(line);
            }
        }
        if (result == null) {
            throw new IllegalStateException("No 'update' line found in output");
        }
        return result;
    }

    private String processManifestMergeConflictPrompting() throws IOException {
        if (this.oracle != null) {
            this.oracle.getMissingAnswers().clear();
        }

        String output = null;
        while (true) {
            // FIXME potential encoding problem: platform default charset!
            output = new String(ByteStreams.toByteArray(this.stdout));
            Matcher matcher = MANIFEST_MERGE_PATTERN.matcher(output);
            if (matcher.matches()) {
                if (oracle == null) {
                    throw new RuntimeException("Manifest merge conflict, but no oracle");
                }
                String filename = output.substring(matcher.start(1), matcher.end(1));
                String answer = oracle.ask(filename);
                this.command.sendLine(answer);
                this.command.reopenOutputChannelStream();
            } else {
                break;
            }
        }
        return output;
    }
}
