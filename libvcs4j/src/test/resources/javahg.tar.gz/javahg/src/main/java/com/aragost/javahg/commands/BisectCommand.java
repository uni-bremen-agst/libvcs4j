package com.aragost.javahg.commands;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.BisectCommandFlags;

public class BisectCommand extends BisectCommandFlags {

    public BisectCommand(Repository repository) {
        super(repository);
    }

    /**
     * Run <tt>hg bisect</tt>.
     */
    public BisectResult execute() {
        return new BisectResult(launchString());
    }

    /**
     * Run <tt>hg bisect</tt>.
     */
    public BisectResult execute(String rev) {
        return new BisectResult(launchString(rev));
    }
}
