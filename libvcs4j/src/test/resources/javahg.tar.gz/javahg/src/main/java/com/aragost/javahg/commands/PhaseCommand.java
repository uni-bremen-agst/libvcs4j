/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.PhaseCommandFlags;

/**
 * Command class for executing <tt>hg phase</tt>. Set flags from {@link PhaseCommandFlags} and call the {@link #execute}
 * method.
 */
public class PhaseCommand extends PhaseCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public PhaseCommand(Repository repository) {
        super(repository);
    }

    /**
     * Set the <tt>--public</tt> command line flag.
     * <p>
     * Since <em>public</em> is a keyword in Java, the method can not - as other flags - be named as the flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#phase">Mercurial documentation</a>
     * @return this instance
     */
    public PhaseCommand pub() {
        cmdAppend(Args.PUBLIC);
        return this;
    }

    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    public boolean execute() {
        launchString();
        return getReturnCode() == 0;
    }

}
