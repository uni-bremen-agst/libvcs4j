package com.aragost.javahg.ext.mq;

import java.io.File;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QRefreshCommandFlags;
import com.aragost.javahg.internals.Utils;

public class QRefreshCommand extends QRefreshCommandFlags {

    public QRefreshCommand(Repository repository) {
        super(repository);
        cmdAppend("--git");
    }

    /**
     * Set the <tt>--edit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand shortOpt() {
        cmdAppend("--short");
        return this;
    }

    public void execute(File... files) {
        execute(Utils.fileArray2StringArray(files));
    }

    public void execute(String... files) {
        launchString(files);
    }
}
