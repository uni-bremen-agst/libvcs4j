package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.ImportCommandFlags;
import com.aragost.javahg.internals.Utils;

public class ImportCommand extends ImportCommandFlags {

    public ImportCommand(Repository repository) {
        super(repository);
    }

    /**
     * Run <tt>hg import</tt> on the files.
     * 
     * @param files
     *            the input files
     * @throws IOException
     */
    public void execute(String... files) throws IOException {
        launchString(files);
    }

    /**
     * Run <tt>hg import</tt> on the files.
     * 
     * @param files
     *            the input files
     * @throws IOException
     */
    public void execute(File... files) throws IOException {
        launchString(Utils.fileArray2StringArray(files));
    }
}
