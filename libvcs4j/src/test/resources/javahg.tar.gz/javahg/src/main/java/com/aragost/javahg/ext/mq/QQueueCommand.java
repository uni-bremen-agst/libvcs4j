package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QQueueCommandFlags;

public class QQueueCommand extends QQueueCommandFlags {

    public QQueueCommand(Repository repository) {
        super(repository);
        // TODO Auto-generated constructor stub
    }

}
