package com.aragost.javahg.merge;

import java.util.List;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.commands.RemoveCommand;
import com.aragost.javahg.commands.RevertCommand;

public class KeepDeleteConflict extends MergeFile {

    private State state = State.KEEP;

    /**
     * Is the local parent the parent where the file is kept
     */
    private boolean localKeep;

    public enum State {
        KEEP, DELETE
    }

    public KeepDeleteConflict(ConflictResolvingContext mergeState, String fileName, State localState) {
        super(mergeState, fileName);
        this.localKeep = localState.equals(State.KEEP);
    }

    public State getState() {
        return state;
    }

    public void update(State state) {
        if (this.state.equals(state)) {
            return;
        }
        String fn = getFilename();
        switch (state) {
        case KEEP:
            RevertCommand.on(getRepository()).rev(getKeepParent().getNode()).noBackup().execute(fn);
            break;
        case DELETE:
            List<String> removed = RemoveCommand.on(getRepository()).force().execute(fn);
            if (removed.size() != 1 || !removed.get(0).equals(fn)) {
                throw new RuntimeException("remove failed to removed file: " + fn);
            }
            break;
        default:
            throw new IllegalStateException("Unhandled state");
        }
        this.state = state;
    }

    public void keep() {
        update(State.KEEP);
    }

    public void delete() {
        update(State.DELETE);
    }

    public Changeset getKeepParent() {
        if (this.localKeep) {
            return getMergeCtx().getLocal();
        }
        return getMergeCtx().getRemote();
    }
}
