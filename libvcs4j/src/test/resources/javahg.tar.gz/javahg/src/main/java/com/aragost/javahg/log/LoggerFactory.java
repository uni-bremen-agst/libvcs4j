package com.aragost.javahg.log;

import com.aragost.javahg.internals.ServiceLoader;
import com.google.common.base.Strings;

/**
 * Factory class to retrieve a {@link Logger} instance. The LoggerFactory searches a implementation with the use of
 * {@link ServiceLoader}, if no implementation could be found it uses the default implementation
 * {@link JULLoggerFactory}.
 */
public abstract class LoggerFactory {

    private static LoggerFactory instance;

    static {
        String loggerFactoryName = System.getProperty(LoggerFactory.class.getName());
        try {
            if (!Strings.isNullOrEmpty(loggerFactoryName)) {
                instance = (LoggerFactory) Class.forName(loggerFactoryName).newInstance();
            } else {
                instance = ServiceLoader.loadService(LoggerFactory.class);
            }
        } catch (Exception ex) {
            // do nothing
        }
        if (instance == null) {
            instance = new JULLoggerFactory();
        }
    }

    /**
     * Return a logger for the class
     * 
     * @param cls
     * @return
     */
    public static Logger getLogger(Class<?> cls) {
        return instance.getLoggerInstance(cls);
    }

    protected abstract Logger getLoggerInstance(Class<?> cls);

}
