/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2017 aragost Trifork ag & contributors
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

/**
 * 
 * This class defines character sequences that mark the beginning of pieces of information expected by JavaHg as per the
 * style templates.
 * <p>
 * This is needed to deal with the fact that the output expected from Hg is sometimes polluted with messages from Hg
 * extensions, e.g. evolve. With the markers defined here, JavaHg can operate (probably not in all cases) without being
 * thrown off course by extensions over which we have no control.
 * <p>
 * To sum up, these markers help JavaHg pick what it needs from the Hg output even when that output is polluted by
 * external sources.
 * <p>
 * <b>NOTE: It is important that the wording and case be exactly the same as specified in the style templates.</b>
 * 
 * @since 2017-09-23
 * @author waav / W. Amenel VOGLOZIN
 *
 */
public class TemplateMarkers {

    //@formatter:off
    public static final byte[] JAVAHG_MARKER     = "JavaHg:".getBytes();
    public static final byte[] JAVAHG_MARKER_TAG = "jHg1tag:".getBytes();
    //@formatter:on

    private TemplateMarkers() {
        // Utility class.
    }

}
