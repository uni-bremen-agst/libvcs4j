/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.util.List;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.ResolveCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.RuntimeIOException;
import com.aragost.javahg.internals.Utils;
import com.google.common.collect.Lists;

/**
 * Command class for executing <tt>hg resolve</tt>. The resolve command is actually a front-end for several
 * sub-commands:
 * <ul>
 * <li>with <tt>--list</tt>, it lists the current merge state. Use {@link #list()} for this command.</li>
 * <li>with <tt>--mark</tt> and <tt>--unmark</tt> it manipulates the current merge state. Use {@link #mark(String...)}
 * and {@link #unmark(String...)} for these commands.</li>
 * <li>without the above flags it re-merges files. Use {@link #execute(String...)} for this command.</li>
 * </ul>
 */
public class ResolveCommand extends ResolveCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public ResolveCommand(Repository repository) {
        super(repository);
    }

    /**
     * @param files
     *            the files to re-merge
     * @return the command output
     */
    public String execute(String... files) {
        return launchString(files);
    }

    /**
     * This correspond to the --list option for resolve.
     * 
     * @return List we status of merge files
     */
    public List<ResolveStatusLine> list() {
        HgInputStream stream = launchStream(Args.LIST);
        List<ResolveStatusLine> result = Lists.newArrayList();
        try {
            while (stream.peek() != -1) {
                result.add(ResolveStatusLine.fromStream(stream));
            }
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        }
        return result;
    }

    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    /**
     * @param files
     *            the files to mark as resolved.
     */
    public void mark(String... files) {
        launchString(Utils.arrayUnshift(Args.MARK, files));
    }

    /**
     * @param files
     *            the files to mark as unresolved.
     */
    public void unmark(String... files) {
        launchString(Utils.arrayUnshift(Args.UNMARK, files));
    }

}
