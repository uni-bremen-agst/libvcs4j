package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QFoldCommandFlags;

public class QFoldCommand extends QFoldCommandFlags {

    public QFoldCommand(Repository repository) {
        super(repository);
    }

    /**
     * Fold the given patch files into the current patch
     * 
     * @param files
     *            The files to fold
     */
    public void execute(String... files) {
        launchString(files);
    }
}
