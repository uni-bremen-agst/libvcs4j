package com.aragost.javahg;

/**
 * Enum type to represent phases introduced in Mercurial 2.1
 */
public enum Phase {

    PUBLIC, DRAFT, SECRET;

    /**
     * Return the Phase that correspond to the specified text.
     * <p>
     * The text is what mercurial uses in the command output (i.e. public, draft, or secret).
     * 
     * @param s
     * @return the Phase that correspond to the specified text. null is returned for the empty string.
     * @throws IllegalArgumentException
     *             if no phase correspond to the specified text
     */
    public static Phase fromText(String s) {
        for (Phase p : Phase.values()) {
            if (p.text.equals(s)) {
                return p;
            }
        }
        if (s.equals("")) {
            return null;
        }
        throw new IllegalArgumentException("No phase for " + s);
    }

    private String text;

    private Phase() {
        this.text = name().toLowerCase();
    }
}
