package com.aragost.javahg;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;

/**
 * Representing a Mercurial version.
 * <p>
 * The version has the format [major].[minor]{.[release]}{-rc}{+[suffix]} where parts enclosed in {...} is optional. The
 * major, minor, and release part can at most be 2 digits, the suffix part can be any string.
 * 
 */
public class HgVersion implements Comparable<HgVersion> {

    private static final HgVersion UNKNOWN = new HgVersion(null);

    private final String versionString;

    private final byte major;

    private final byte minor;

    private final Integer release;

    private final boolean releaseCandidate;

    private final String suffix;

    /**
     * Private constuctor, use factory method to create an instance.
     * 
     * @param versionString
     */
    private HgVersion(String versionString) {
        if (versionString == null) {
            this.versionString = "unknown";
            this.major = 0;
            this.minor = 0;
            this.release = 0;
            this.releaseCandidate = false;
            this.suffix = null;
        } else {
            this.versionString = versionString;
            int pos = versionString.indexOf('.');
            // All current versions number as 2.1 has major number 1
            // digit
            // but we allow for 2
            if (pos != 1 && pos != 2) {
                throw new IllegalArgumentException();
            }
            this.major = parseInt(versionString.substring(0, pos));
            // Like major allow for 1 or 2 digit minor
            String rest = versionString.substring(pos + 1);
            pos = indexOfFirstNonDigit(rest);
            this.minor = parseInt(rest.substring(0, pos));
            if (rest.length() > pos && rest.charAt(pos) == '.') {
                rest = rest.substring(pos + 1);
                pos = indexOfFirstNonDigit(rest);
                this.release = Integer.valueOf(parseInt(rest.substring(0, pos)));
            } else {
                this.release = null;
            }
            rest = rest.substring(pos);

            this.releaseCandidate = rest.startsWith("-rc+") || rest.equals("-rc");

            if (this.releaseCandidate) {
                rest = rest.substring(3);
            }
            if (rest.length() != 0) {
                if (rest.charAt(0) != '+') {
                    throw new IllegalArgumentException();
                }
                this.suffix = rest.substring(1);
            } else {
                this.suffix = null;
            }
        }
    }

    /**
     * Factory method to create a HgVersion from a version string from Mercurial
     * <p>
     * Examples of valid input:
     * <ul>
     * <li>2.1</li>
     * <li>1.9.3</li>
     * <li>2.0.1+20120221</li>
     * </ul>
     * 
     * @param versionString
     * @return
     */
    public static HgVersion fromString(String versionString) {
        if (versionString == null) {
            throw new IllegalArgumentException();
        }
        return new HgVersion(versionString);
    }

    /**
     * @return a HgVersion representing the unknow version
     */
    public static HgVersion unknown() {
        return UNKNOWN;
    }

    /**
     * @return the String that this HgVersion was created from
     */
    public String getVersionString() {
        return versionString;
    }

    /**
     * 
     * @return the major (i.e. first) version number
     */
    public int getMajor() {
        return major;
    }

    /**
     * 
     * @return the minor (i.e. second) version number
     */
    public int getMinor() {
        return minor;
    }

    /**
     * 
     * @return the release (i.e. third and last) version number
     */
    public Integer getRelease() {
        return release;
    }

    /**
     * 
     * @return true if the version number is a relase candidate, otherwise false
     */
    public boolean isReleaseCandidate() {
        return releaseCandidate;
    }

    /**
     * 
     * @return the suffix part
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * 
     * @return true if the receiver is a <em>unknown</em> instance.
     */
    public boolean isUnknown() {
        return this.equals(UNKNOWN);
    }

    /**
     * Compare this to the other version.
     * <p>
     * All parts of the version is used except the suffix part.
     */
    @Override
    public int compareTo(HgVersion that) {
        if (that.equals(UNKNOWN) || this.equals(UNKNOWN)) {
            throw new IllegalArgumentException();
        }
        // Note releaseCandidate parameters are first 'that' then
        // 'this'
        return ComparisonChain.start().compare(this.major, that.major).compare(this.minor, that.minor).compare(
                this.release, that.release, Ordering.natural().nullsFirst()).compare(that.releaseCandidate,
                        this.releaseCandidate).result();
    }

    /**
     * 
     * @param ver
     * @return true if the receiver is strictly an earlier version than the argument
     */
    public boolean isBefore(HgVersion ver) {
        return this.compareTo(ver) < 0;
    }

    @Override
    public String toString() {
        return this.versionString;
    }

    /**
     * Return the index of the first character that isn't a digit. If all characters is a digit then the length of the
     * String is returned.
     * 
     * @param s
     * @return
     */
    private static int indexOfFirstNonDigit(String s) {
        int length = s.length();
        for (int i = 0; i < length; i++) {
            if (!Character.isDigit(s.charAt(i))) {
                return i;
            }
        }
        return length;
    }

    /**
     * Parse the specified String as an integer and return it as a byte.
     * <p>
     * The String must have 1 or 2 characters and contain only digits.
     * 
     * @param s
     * @return
     */
    private static byte parseInt(String s) {
        int length = s.length();
        if (length == 0 || length > 2) {
            throw new IllegalArgumentException();
        }
        int result = 0;
        for (int i = 0; i < length; i++) {
            if (Character.isDigit(s.charAt(i))) {
                result = result * 10 + s.charAt(i) - '0';
            } else {
                throw new IllegalArgumentException();
            }
        }
        return (byte) result;
    }

}
