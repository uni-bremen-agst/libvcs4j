package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QGuardCommandFlags;

public class QGuardCommand extends QGuardCommandFlags {

    public QGuardCommand(Repository repository) {
        super(repository);
        // TODO Auto-generated constructor stub
    }

}
