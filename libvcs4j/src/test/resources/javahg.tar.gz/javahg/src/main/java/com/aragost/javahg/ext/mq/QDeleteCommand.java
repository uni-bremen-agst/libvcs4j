package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QDeleteCommandFlags;

public class QDeleteCommand extends QDeleteCommandFlags {

    public QDeleteCommand(Repository repository) {
        super(repository);
    }

    /**
     * Delete the specified patches
     * 
     * @param patches
     *            The names of patches to delete
     */
    public void execute(String... patches) {
        launchString(patches);
    }
}
