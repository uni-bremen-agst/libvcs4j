/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.aragost.javahg.internals.Utils;
import com.google.common.base.Strings;
import com.google.common.collect.Sets;

/**
 * Settings for repository and underlying server process
 */
public class RepositoryConfiguration {

    static {
        String hgBin = System.getProperty("com.aragost.javahg.hgbin");
        if (Strings.isNullOrEmpty(hgBin)) {
            hgBin = "hg";
        }
        DEFAULT_HG_BIN = hgBin;
        DEFAULT_ENCODING = Utils.getPlatformCharset();
    }

    private static final String DEFAULT_HG_BIN;

    /**
     * The default encoding for the repository.
     */
    protected static final Charset DEFAULT_ENCODING;

    /**
     * Mercurial repository encoding. Default is UTF-8.
     */
    private Charset encoding = DEFAULT_ENCODING;

    /**
     * The default configuration, used in case no explicit configuration is given to a {@link Repository}
     */
    public static final RepositoryConfiguration DEFAULT = new RepositoryConfiguration();

    public enum CachePolicy {
        STRONG, SOFT, WEAK, NONE
    }

    /**
     * The Mercurial executable
     */
    private String hgBin = DEFAULT_HG_BIN;

    /**
     * The hgrc property file to use. If it is the empty string then no hgrc file is used, if it is null Mercurial uses
     * its normal logic to determine the hgrc file. Otherwise it is the path to a file
     */
    private String hgrcPath = "";

    /**
     * How should Changesets be cached
     */
    private CachePolicy cachePolicy = CachePolicy.SOFT;

    /**
     * What to do if we encounter some decoding problems with the output from Mercurial
     */
    private CodingErrorAction codingErrorAction = CodingErrorAction.REPORT;

    /**
     * Size of buffer for stderr from Mercurial command server.
     * <p>
     * Most likely no reason to change this. Main reason it is configurable is so buffer overflow can be tested.
     */
    private int stderrBufferSize = 1024;

    /**
     * Extensions to enable.
     */
    private Collection<Class<? extends MercurialExtension>> extensionClasses = Sets.newHashSet();

    /**
     * The maximum number of command server processes to use. Default is 1.
     */
    private int concurrency = 1;

    /**
     * The maximum number of seconds to wait for a command server instance to become available. Default is 2 minutes.
     */
    private int commandWaitTimeoutSeconds = 120;

    /**
     * After a command server is idle for this many seconds the server pool may stop it. Default is
     * {@link Integer#MAX_VALUE}.
     */
    private int serverIdleTimeSeconds = Integer.MAX_VALUE;

    /**
     * A custom SSH executable which should be used by Mercurial.
     */
    private String sshBin;

    /**
     * Enable access to pending changesets.
     */
    private boolean enablePendingChangesets = false;

    /**
     * Environment variables to set before starting command servers
     */
    private final Map<String, String> environment = new HashMap<String, String>();

    public boolean isEnablePendingChangesets() {
        return enablePendingChangesets;
    }

    public void setEnablePendingChangesets(boolean enablePendingChangesets) {
        this.enablePendingChangesets = enablePendingChangesets;
    }

    public String getHgBin() {
        return hgBin;
    }

    public void setHgBin(String hgBin) {
        this.hgBin = hgBin;
    }

    public String getHgrcPath() {
        return hgrcPath;
    }

    public void setHgrcPath(String hgrcPath) {
        this.hgrcPath = hgrcPath;
    }

    public CachePolicy getCachePolicy() {
        return cachePolicy;
    }

    public void setCachePolicy(CachePolicy cachePolicy) {
        this.cachePolicy = cachePolicy;
    }

    public CodingErrorAction getCodingErrorAction() {
        return codingErrorAction;
    }

    public void setCodingErrorAction(CodingErrorAction codingErrorAction) {
        this.codingErrorAction = codingErrorAction;
    }

    public int getStderrBufferSize() {
        return stderrBufferSize;
    }

    public void setStderrBufferSize(int stderrBufferSize) {
        this.stderrBufferSize = stderrBufferSize;
    }

    public Collection<Class<? extends MercurialExtension>> getExtensionClasses() {
        return extensionClasses;
    }

    public void setExtensionClasses(Collection<Class<? extends MercurialExtension>> extensionClasses) {
        this.extensionClasses = extensionClasses;
    }

    public void addExtension(Class<? extends MercurialExtension> extClass) {
        this.extensionClasses.add(extClass);
    }

    public void removeExtension(Class<? extends MercurialExtension> extClass) {
        this.extensionClasses.remove(extClass);
    }

    public Charset getEncoding() {
        return encoding;
    }

    public void setEncoding(Charset encoding) {
        this.encoding = encoding;
    }

    /**
     * @return The maximum number of command server processes to use. Default is 1.
     */
    public int getConcurrency() {
        return concurrency;
    }

    /**
     * The maximum number of command server processes to use. Default is 1.
     * 
     * @param concurrency
     *            The maximum number of command server processes to use.
     */
    public void setConcurrency(int concurrency) {
        this.concurrency = concurrency;
    }

    /**
     * @return The maximum number of seconds to wait for a command server instance to become available. Default is 2
     *         minutes.
     */
    public int getCommandWaitTimeout() {
        return commandWaitTimeoutSeconds;
    }

    /**
     * Set the maximum number of seconds to wait for a command server instance to become available. Default is 2
     * minutes.
     * 
     * Note: this is not command execution timeout.
     * 
     * @param seconds
     *            The amount of time to wait for a server to become available in seconds.
     */
    public void setCommandWaitTimeout(int seconds) {
        this.commandWaitTimeoutSeconds = seconds;
    }

    /**
     * After a command server is idle for this many seconds the server pool may stop it. Default is
     * {@link Integer#MAX_VALUE}.
     * 
     * @return The idle time for a server
     */
    public int getServerIdleTime() {
        return this.serverIdleTimeSeconds;
    }

    /**
     * After a command server is idle for this many seconds the server pool may stop it. Default is
     * {@link Integer#MAX_VALUE}.
     * 
     * @param seconds
     *            The idle time for a server
     */
    public void setServerIdleTime(int seconds) {
        this.serverIdleTimeSeconds = seconds;
    }

    /**
     * Returns the custom SSH executable which should be used by Mercurial.
     * 
     * @return the custom SSH executable
     */
    public String getSshBin() {
        return sshBin;
    }

    /**
     * Sets the custom SSH executable which should be used by Mercurial.
     * 
     * @param sshBin
     *            the custom SSH executable
     */
    public void setSshBin(String sshBin) {
        this.sshBin = sshBin;
    }

    /**
     * @return A map of custom environment variables that will be set when command servers are started.
     */
    public Map<String, String> getEnvironment() {
        return this.environment;
    }
}
