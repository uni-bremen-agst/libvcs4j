package com.aragost.javahg.ext.purge;

import com.aragost.javahg.MercurialExtension;

public class PurgeExtension extends MercurialExtension {

    @Override
    public String getName() {
        return "purge";
    }

}
