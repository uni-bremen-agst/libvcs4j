package com.aragost.javahg.merge;

import java.io.File;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.RevertCommand;

/**
 * Base class for files somehow related to a merge.
 * <p>
 * 
 * @see MergeContext
 */
public abstract class MergeFile {

    private String filename;

    private ConflictResolvingContext mergeCtx;

    public MergeFile(ConflictResolvingContext mergeCtx, String file) {
        this.mergeCtx = mergeCtx;
        this.filename = file;
    }

    public String getFilename() {
        return filename;
    }

    public File getFile() {
        return getRepository().file(getFilename());
    }

    public ConflictResolvingContext getMergeCtx() {
        return mergeCtx;
    }

    void setMergeState(ConflictResolvingContext mergeState) {
        this.mergeCtx = mergeState;
    }

    Repository getRepository() {
        return this.mergeCtx.getRepository();
    }

    void revertTo(Changeset changeset) {
        RevertCommand.on(getRepository()).rev(changeset.getNode()).execute(this.filename);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + getFilename() + "]";
    }

}
