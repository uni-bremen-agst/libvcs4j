package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QHeaderCommandFlags;

public class QHeaderCommand extends QHeaderCommandFlags {

    public QHeaderCommand(Repository repository) {
        super(repository);
    }

    public String execute() {
        return launchString();
    }
}
