/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.internals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.ExecutionException;
import com.aragost.javahg.commands.LogCommand;
import com.google.common.collect.Lists;
import com.google.common.io.ByteStreams;

public class PullPushHelper {

    private static final byte[] BEGIN = "list of changesets:\n".getBytes();
    private static final byte[] BEGIN_FALLBACK = "adding changesets\n".getBytes();
    private static final byte[] LINE_BEGIN = "add changeset ".getBytes();
    private static final byte[] REMOTE_ERROR = "remote: error: ".getBytes();

    /**
     * Tells whether the given string is a possible changeset ID as defined by Mercurial. This is needed because hg (as
     * of version 4.0.1, but probably much sooner) outputs several lines that are not changeset IDs between the two
     * lines that we use as delimiters of the list of changesets. Example output (hg 4.0.1):
     * 
     * <pre>
     * list of changesets:
     * 4a1d687b6656d0700a07bad8af8a820ea855d632
     * 72ec6f720b817fc8c19549f820d398fedefbc679
     * bundle2-output-bundle: "HG20", 4 parts total
     * bundle2-output-part: "replycaps" 155 bytes payload
     * bundle2-output-part: "changegroup" (params: 1 mandatory) streamed payload
     * bundle2-output-part: "pushkey" (params: 4 mandatory) empty payload
     * bundle2-output-part: "pushkey" (params: 4 mandatory) empty payload
     * bundle2-input-bundle: with-transaction
     * bundle2-input-part: "replycaps" supported
     * bundle2-input-part: total payload size 155
     * bundle2-input-part: "changegroup" (params: 1 mandatory) supported
     * adding changesets
     * </pre>
     * 
     * @param hexNumber
     *            candidate string
     * @return <code>true</code> if the string is a 40-character hexadecimal number.
     * @author Amenel Voglozin
     * @since 2016-12-10
     */
    private static boolean isChangesetId(String hexNumber) {
        return Changeset.isChangesetId(hexNumber);
    }

    public static List<Changeset> parseStream(AbstractCommand command, HgInputStream stream) throws IOException {
        Repository repo = command.getRepository();
        List<Changeset> result;

        // Pulling locally the full nodes are written after
        // "list of changesets:"
        // Over HTTP this isn't written.
        // In either case 12 character node prefixes are printed after
        // "adding changesets".
        // If possible use first case, otherwise fall back to node prefixes.

        // Make a copy
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ByteStreams.copy(stream, bos);
        stream.consumeAll();
        HgInputStream lstream = new HgInputStream(new ByteArrayInputStream(bos.toByteArray()), repo.newDecoder());

        if (lstream.find(BEGIN)) {
            result = Lists.newArrayList();
            while (!lstream.isEof() && !lstream.match(BEGIN_FALLBACK)) {
                String text = lstream.textUpTo('\n');
                if (isChangesetId(text)) {
                    result.add(repo.changeset(text));
                }
            }
        } else {
            lstream = new HgInputStream(new ByteArrayInputStream(bos.toByteArray()), repo.newDecoder());

            List<String> nodePrefixes = Lists.newArrayList();

            if (lstream.find(BEGIN_FALLBACK)) {
                while (lstream.find(LINE_BEGIN)) {
                    // 12 Character node prefix
                    nodePrefixes.add(lstream.textUpTo('\n'));
                }
            }
            if (nodePrefixes.isEmpty()) {
                result = Collections.emptyList();
            } else {
                result = LogCommand.on(repo).rev(nodePrefixes.toArray(new String[nodePrefixes.size()])).execute();
            }
        }

        lstream = new HgInputStream(new ByteArrayInputStream(bos.toByteArray()), repo.newDecoder());

        if (lstream.find(REMOTE_ERROR)) {
            throw new ExecutionException(command, lstream.textUpTo('\n'));
        }

        return result;
    }
}
