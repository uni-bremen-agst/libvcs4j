package com.aragost.javahg.merge;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.CommitCommand;
import com.aragost.javahg.commands.GraftCommand;
import com.aragost.javahg.commands.LogCommand;

public class GraftContext extends ConflictResolvingContext {

    private final int sourceRev;

    private Changeset source;

    /**
     * The graft command might decide to rollback a changeset. In which case the field is set.
     * <p>
     * If the changeset is rollback, a commit has to be done when conflicts are resolved, otherwise a graft --continue
     */
    private Changeset rollbackChangeset;

    public GraftContext(GraftCommand command, int sourceRev) {
        super(command);
        this.sourceRev = sourceRev;
    }

    public synchronized Changeset getSource() {
        if (this.source == null) {
            this.source = LogCommand.on(getRepository()).rev("" + this.sourceRev).single();
        }
        return this.source;
    }

    public Changeset commit() {
        Repository repo = getRepository();
        if (this.rollbackChangeset == null) {
            repo.lock();
            try {
                boolean createdNewChangeset = ((GraftCommand) getCommand()).executeContinue();
                return createdNewChangeset ? repo.tip() : null;
            } finally {
                repo.unlock();
            }
        }
        CommitCommand cmd = CommitCommand.on(repo);
        cmd.user(this.rollbackChangeset.getUser());
        cmd.date(this.rollbackChangeset.getTimestamp());
        cmd.message(this.rollbackChangeset.getMessage());
        cmd.extra("source", getSource().getNode());
        return cmd.execute();
    }

    public void setRollbackChangeset(Changeset rollbackChangeset) {
        this.rollbackChangeset = rollbackChangeset;
    }

}
