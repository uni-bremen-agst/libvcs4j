package com.aragost.javahg.ext.mq;

import java.io.File;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QNewCommandFlags;
import com.aragost.javahg.internals.Utils;

public class QNewCommand extends QNewCommandFlags {

    public QNewCommand(Repository repository) {
        super(repository);
        cmdAppend("--git");
    }

    public void execute(String name, File... files) {
        execute(name, Utils.fileArray2StringArray(files));
    }

    public void execute(String name, String... files) {
        cmdAppend(name);
        launchString(files);
    }
}
