/*
 * #%L
 * JavaHg parent POM
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;

/**
 * Represent a named branch returned by {@link BranchesCommand}
 */
public class Branch implements Comparable<Branch> {

    private static final String CLOSED_SUFFIX = " (closed)";

    private static final String INACTIVE_SUFFIX = " (inactive)";

    private final Changeset branchTip;

    private final boolean closed;

    private final String name;

    public static Branch fromLine(Repository repo, String line) {
        boolean isClosed = false;
        String lLine = line;
        if (lLine.endsWith(INACTIVE_SUFFIX)) {
            lLine = lLine.substring(0, lLine.length() - INACTIVE_SUFFIX.length());
        } else if (lLine.endsWith(CLOSED_SUFFIX)) {
            isClosed = true;
            lLine = lLine.substring(0, lLine.length() - CLOSED_SUFFIX.length());
        }
        // Note branch names can contain spaces so we find the last
        // one
        int lastSpace = lLine.lastIndexOf(' ');
        String node = lLine.substring(lLine.indexOf(':', lastSpace) + 1);
        String branchName = lLine.substring(0, lastSpace).trim();
        return new Branch(repo.changeset(node), branchName, isClosed);
    }

    private Branch(Changeset branchTip, String name, boolean closed) {
        this.branchTip = branchTip;
        this.name = name;
        this.closed = closed;
    }

    public Changeset getBranchTip() {
        return branchTip;
    }

    public boolean isClosed() {
        return closed;
    }

    public String getName() {
        return name;
    }

    @Override
    public int compareTo(Branch that) {
        return this.getName().compareTo(that.getName());
    }

    @Override
    public String toString() {
        return "branch[" + this.name + "]";
    }

}
