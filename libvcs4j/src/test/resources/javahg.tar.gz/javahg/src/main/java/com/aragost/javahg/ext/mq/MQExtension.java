package com.aragost.javahg.ext.mq;

import com.aragost.javahg.MercurialExtension;

public class MQExtension extends MercurialExtension {

    @Override
    public String getName() {
        return "mq";
    }

}
