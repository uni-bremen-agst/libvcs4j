/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.aragost.javahg.internals.GenericCommand;

public class Bundle {

    private final BaseRepository baseRepository;

    private OverlayRepository overlayRepository;

    private final File file;

    private boolean manageFile;

    private List<Changeset> changesets;

    /**
     * Create a new bundle. The bundle file will not be deleted on close.
     * 
     * @param baseRepository
     *            The base repository this bundle applies to
     * @param file
     *            The bundle file.
     */
    public Bundle(BaseRepository baseRepository, File file) {
        this(baseRepository, file, false);
    }

    /**
     * Create a new bundle.
     * 
     * @param baseRepository
     *            The base repository this bundle applies to
     * @param file
     *            The bundle file
     * @param manageFile
     *            Whether to delete the bundle file when this bundle is closed.
     */
    public Bundle(BaseRepository baseRepository, File file, boolean manageFile) {
        this.baseRepository = baseRepository;
        this.overlayRepository = new OverlayRepository(baseRepository, this);
        this.file = file;
        this.manageFile = manageFile;
    }

    /**
     * @return the underlying file for the bundle
     */
    public File getFile() {
        return file;
    }

    /**
     * @param manageFile
     *            Whether close should delete the bundle file
     */
    public void setManageFile(boolean manageFile) {
        this.manageFile = manageFile;
    }

    /**
     * Do the final initialization of the bundle.
     * <p>
     * This method is only public so it can be called from IncomingCommand
     * 
     * @param changesets
     *            the changesets contained in this Bundle
     */
    public void init(List<Changeset> changesets) {
        this.changesets = changesets;
    }

    /**
     * Return the changeset for this bundle. The are sorted from low revisions to high revisions.
     * 
     * @return The changesets
     */
    public List<Changeset> getChangesets() {
        return changesets;
    }

    public void close() {
        Repository repo = this.overlayRepository;
        repo.close();

        if (manageFile) {
            getFile().delete();
        }

        this.overlayRepository = null;
    }

    public BaseRepository getBaseRepository() {
        return baseRepository;
    }

    public Repository getOverlayRepository() {
        return overlayRepository;
    }

    /**
     * Push the changesets in the bundle to its base repository.
     * 
     * @throws IOException
     */
    public void pushToRepository() throws IOException {
        final BaseRepository base = getBaseRepository();
        GenericCommand cmd = new GenericCommand(base, "pull");
        cmd.execute(getFile().getPath());
    }
}
