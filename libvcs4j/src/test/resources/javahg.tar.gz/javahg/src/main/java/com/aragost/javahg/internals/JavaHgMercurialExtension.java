package com.aragost.javahg.internals;

import java.io.File;
import java.io.IOException;

import com.aragost.javahg.MercurialExtension;

/**
 * Extension class to load the JavaHg specific Mercurial extension
 */
public class JavaHgMercurialExtension extends MercurialExtension {

    private File pythonFile;

    @Override
    public String getName() {
        return "javahg";
    }

    public String getResourceName() {
        return "/" + getName() + ".py";
    }

    @Override
    public String getPath() {
        return this.pythonFile.getAbsolutePath();
    }

    @Override
    public void initialize() throws IOException {
        if (this.pythonFile == null || !this.pythonFile.exists()) {
            this.pythonFile = Utils.resourceAsFile(getResourceName());
        }
    }

}
