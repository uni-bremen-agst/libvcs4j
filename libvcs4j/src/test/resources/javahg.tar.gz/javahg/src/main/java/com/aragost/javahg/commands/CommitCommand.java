/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;

import com.aragost.javahg.Args;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.CommitCommandFlags;
import com.aragost.javahg.internals.Utils;

/**
 * Command class for executing <tt>hg commit</tt>. Set flags from {@link CommitCommandFlags} and call the
 * {@link #execute} method.
 */
public class CommitCommand extends CommitCommandFlags {

    final static String COMMITTED_CHANGESET_ANCHOR = "committed changeset ";

    private String message;

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public CommitCommand(Repository repository) {
        super(repository);
        withDebugFlag();
    }

    /**
     * Check if the commit was successful. In contrast with Mercurial, this returns true if <tt>hg commit</tt> exited
     * with a return code of 1. This happens if there were no changes and is signaled to the caller by returning null
     * instead of a changeset.
     */
    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    /**
     * Commit changes in the passed in files only
     * 
     * @param files
     *            the files to commit.
     * @return the changeset created by the commit, or null if nothing was committed.
     */
    public Changeset execute(String... files) {
        return doExecute(files);
    }

    private Changeset doExecute(String... files) {
        if (this.message == null) {
            throw new IllegalStateException("message not set for command");
        }

        String[] lFiles = files;
        if (files == null) {
            lFiles = new String[0];
        } else if (files.length == 0) {
            lFiles = new String[2];
            lFiles[0] = Args.EXCLUDE;
            lFiles[1] = "*";
        }

        String output = launchString(lFiles);
        int rc = getReturnCode();
        if (rc == 1) {
            return null;
        }

        //
        // We now retrieve the 40-hex char revision number.
        //

        // For hg versions before 4.0.0, the output ends with these three lines:
        // > committed changeset 0:56ed8b263b407d07c1d0fa0e9769437dad944076
        // > updating the branch cache
        // > <this is an empty line>
        // However, for hg >= 4.0.0, the middle line above is missing; we get:
        // > committed changeset 0:56ed8b263b407d07c1d0fa0e9769437dad944076
        // > <this is an empty line>
        // Therefore, we can't rely on extracting 40 chars from the end of the
        // output string as was previously done.
        String node;

        // In case the string contains the missing line, we need to remove it:
        int pos = output.indexOf(COMMITTED_CHANGESET_ANCHOR);
        node = output.substring(pos);
        // we only need the 40 characters of the sha1 code after the colon
        pos = node.indexOf(':');
        node = node.substring(pos + 1, pos + 1 + 40);

        return getRepository().changeset(node);
    }

    /**
     * 
     * @param files
     *            the files to commit.
     * @return the changeset created by the commit, or null if nothing was committed.
     */
    public Changeset execute(File... files) {
        return execute(Utils.fileArray2StringArray(files));
    }

    /**
     * Commit all changes
     * 
     * @return the changeset created by the commit, or null if nothing was committed.
     */
    public Changeset execute() {
        return doExecute((String[]) null);
    }

    /**
     * Set the commit message. A message is mandatory for commit.
     */
    @Override
    public CommitCommand message(String text) {
        this.message = text;
        return super.message(text);
    }

    /**
     * Add a field to the extra dictionary for the changeset.
     * <p>
     * Note this is implemented via the javahg extension for Mercurial.
     * 
     * @param key
     * @param value
     */
    public void extra(String key, String value) {
        cmdAppend("--javahg-extra", key + "=" + value);
    }
}
