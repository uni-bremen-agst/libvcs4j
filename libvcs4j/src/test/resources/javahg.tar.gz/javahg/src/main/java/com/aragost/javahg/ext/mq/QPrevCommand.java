package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QPrevCommandFlags;

public class QPrevCommand extends QPrevCommandFlags {

    public QPrevCommand(Repository repository) {
        super(repository);
        // TODO Auto-generated constructor stub
    }

}
