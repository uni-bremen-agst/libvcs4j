package com.aragost.javahg.internals;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.LogCommand;

/**
 * A generic log command where the client is responsible to consume the output from the command server.
 */
public class GenericLogCommand extends LogCommand {

    public GenericLogCommand(Repository repository) {
        super(repository, null);
    }

    /**
     * Specify style to use
     * 
     * @param style
     * @return this instance
     */
    public GenericLogCommand style(String style) {
        cmdAppend(Args.STYLE, pathToStyle(style));
        return this;
    }

    /**
     * Specify template to use
     * 
     * @param template
     * @return this instance
     */
    public GenericLogCommand template(String template) {
        cmdAppend(Args.TEMPLATE, template);
        return this;
    }

    private static String pathToStyle(String style) {
        return Utils.resourceAsFile("/styles/" + style + ".style").getAbsolutePath();
    }

    public HgInputStream stream(String... args) {
        return launchStream(args);
    }

}
