/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.1.1+41-63a1bed65fa3.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.ext.mq.flags;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.QRefreshCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class QRefreshCommandFlags extends AbstractCommand {

    protected QRefreshCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "qrefresh";
    }

    public static QRefreshCommand on(Repository repository) {
        return new QRefreshCommand(repository);
    }

    /**
     * Set the <tt>--edit</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand edit() {
        cmdAppend("--edit");
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--currentuser</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand currentuser() {
        cmdAppend("--currentuser");
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--user</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand user(String user) {
        cmdAppend("--user", user);
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--currentdate</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand currentdate() {
        cmdAppend("--currentdate");
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--date</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand date(String date) {
        cmdAppend("--date", date);
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--include</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand include(String... patterns) {
        cmdAppend("--include", patterns);
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--exclude</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand exclude(String... patterns) {
        cmdAppend("--exclude", patterns);
        return (QRefreshCommand) this;
    }

    /**
     * Set the <tt>--message</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qrefresh">Mercurial documentation</a>
     * @return this instance
     */
    public QRefreshCommand message(String text) {
        cmdAppend("--message", text);
        return (QRefreshCommand) this;
    }

}
