package com.aragost.javahg.internals;

import java.io.ByteArrayOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

public class PatternReplacingOutputStream extends FilterOutputStream {

    private enum State {
        /**
         * The normal state where bytes are directly written though to the underlying stream
         */
        NORMAL,
        /**
         * A '%' has just been seen, so potentially a named pattern will start
         */
        MAYBE_NAME_START,
        /**
         * Bytes written to the stream is part of a named pattern, i.o. recently '%{' was written to the stream
         */
        READING_NAME,
        /**
         * 
         */
        WRITING_REPLACEMENT;
    }

    private final ByteArrayOutputStream nameBuffer = new ByteArrayOutputStream(20);

    private final Map<String, byte[]> replacements;

    private State state = State.NORMAL;

    public PatternReplacingOutputStream(OutputStream out, Map<String, byte[]> replacements) {
        super(out);
        this.replacements = replacements;
    }

    @Override
    public synchronized void write(int b) throws IOException {
        switch (this.state) {
        case NORMAL:
            if (b == '%') {
                this.state = State.MAYBE_NAME_START;
            } else {
                super.write(b);
            }
            break;
        case MAYBE_NAME_START:
            if (b == '{') {
                this.state = State.READING_NAME;
            } else {
                super.write('%');
                if (b == '%') {
                    this.state = State.NORMAL;
                } else {
                    super.write(b);
                }
            }
            break;
        case READING_NAME:
            if (b == '}') {
                this.state = State.WRITING_REPLACEMENT;
                String name = new String(this.nameBuffer.toByteArray());
                this.nameBuffer.reset();
                byte[] replacement = this.replacements.get(name);
                if (replacement == null) {
                    replacement = ("%{" + name + "=null}").getBytes();
                }
                this.out.write(replacement);
                this.state = State.NORMAL;
            } else {
                this.nameBuffer.write(b);
            }
            break;
        case WRITING_REPLACEMENT:
        default:
            super.write(b);
            break;
        }
    }
}
