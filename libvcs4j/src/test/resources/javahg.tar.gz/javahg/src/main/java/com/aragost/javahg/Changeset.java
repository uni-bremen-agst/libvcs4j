/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.aragost.javahg.commands.LogCommand;
import com.aragost.javahg.commands.StatusCommand;
import com.aragost.javahg.commands.StatusResult;
import com.aragost.javahg.internals.GenericLogCommand;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.RuntimeIOException;
import com.aragost.javahg.internals.Utils;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Represent data for a single changeset.
 * <p>
 * A Changeset object can be created just with the node id. The actually data will be loaded on demand when it is
 * accessed
 */
public class Changeset {

    /**
     * Character sequence that indicate the begin and end of the changeset in the command output.
     * <p>
     * This pattern is written by the CHANGESET_STYLE_PATH
     */
    private static final byte[] CHANGESET_PATTERN = Utils.randomBytes();

    /**
     * Style file used among other with the log command to read changesets.
     * <p>
     * The style is parsed by the createFromInputStream() method.
     */
    public static final String CHANGESET_STYLE_PATH = Utils.resourceAsFile("/styles/changesets.style",
            ImmutableMap.of("pattern", CHANGESET_PATTERN)).getPath();

    public static final String CHANGESET_EAGER_STYLE_PATH = Utils.resourceAsFile("/styles/changesets-eager.style",
            ImmutableMap.of("pattern", CHANGESET_PATTERN)).getPath();

    /**
     * The id for the null changeset
     */
    public static final String NULL_ID = "0000000000000000000000000000000000000000";

    /**
     * Length of the changeset node number (SHA1 digest)
     */
    private static final int CHANGESET_ID_LENGTH = 40;

    private final String node;
    private final Repository repository;

    /**
     * The actual data for the Changeset
     */
    protected ChangesetData data;

    /**
     * The actual file data for the Changeset
     */
    protected ChangesetFileData fileData;

    /**
     * Mercurial's extra data. Lazy loaded.
     */
    private Extra extra;

    /**
     * Use {@link Repository#changeset(String)} to create Changesets
     * 
     * @param repository
     */
    public Changeset(Repository repository, String node) {
        this.repository = repository;
        this.node = node;
        //
        // Check that the value given for the node is potentially a valid node ID.
        if (!isChangesetId(node)) {
            throw new RuntimeException("'" + node + "' is not a node ID!!");
        }
    }

    /**
     * Tells whether the given string is a possible changeset ID as defined by Mercurial. Basically, we only test
     * whether the given string is indeed an hexadecimal number.
     * 
     * @param hexNumber
     *            a candidate string that might or might not be an hexadecimal number
     * @return <code>true</code> if the string is a 40-character hexadecimal number.
     */
    public static boolean isChangesetId(String hexNumber) {
        if (Strings.isNullOrEmpty(hexNumber) || hexNumber.length() != CHANGESET_ID_LENGTH) {
            return false;
        }
        return hexNumber.matches("[0-9a-fA-f]+"); //$NON-NLS-1$
    }

    private static Changeset createFromInputStream(Repository repository, HgInputStream in, boolean eager)
            throws IOException {
        String nodeString = ""; //$NON-NLS-1$
        String stringUpToEol = ""; //$NON-NLS-1$

        // Some extensions (like Evolution) may output unwanted text before the actual node ID. We try to skip that
        // unwanted text (see issue 531: https://bitbucket.org/mercurialeclipse/main/issues/531/).
        // Skip to where JavaHg expected output is.
        in.find(TemplateMarkers.JAVAHG_MARKER);
        do {
            stringUpToEol = stringUpToEol + in.textUpTo('\n');
            int strLength = stringUpToEol.length();

            // Anything smaller than the expected length of a changeset ID cannot be a node identifier.
            if (strLength < CHANGESET_ID_LENGTH) {
                nodeString = ""; //$NON-NLS-1$
            } else {
                nodeString = stringUpToEol.substring(strLength - CHANGESET_ID_LENGTH, strLength);
            }
        } while (!Changeset.isChangesetId(nodeString));
        int revision = in.revisionUpTo('\n');
        Changeset cset = repository.changeset(nodeString);
        String user = in.textUpTo('\n');
        DateTime timestamp = in.dateTimeUpTo('\n');
        String branch = in.textUpTo('\n');
        in.upTo(':');
        String p1 = in.nextAsText(40);
        in.upTo(':');
        String p2 = in.nextAsText(40);
        in.mustMatch(' '); // skip space part of {parents}
        Changeset parent1 = repository.changeset(p1);
        Changeset parent2 = repository.changeset(p2);

        // read files
        if (eager) {
            Builder<String> addedBuilder = ImmutableList.builder();
            Builder<String> modifiedBuilder = ImmutableList.builder();
            Builder<String> deletedBuilder = ImmutableList.builder();

            String line = in.textUpTo('\n');
            while (line.length() > 0) {
                if (line.startsWith("a ")) {
                    addedBuilder.add(line.substring(2));
                } else if (line.startsWith("m ")) {
                    modifiedBuilder.add(line.substring(2));
                } else if (line.startsWith("d ")) {
                    deletedBuilder.add(line.substring(2));
                }
                line = in.textUpTo('\n');
            }

            ChangesetFileData fileData = cset.fileData;
            if (fileData == null) {
                fileData = new ChangesetFileData(addedBuilder.build(), modifiedBuilder.build(), deletedBuilder.build());
                cset.fileData = fileData;
            }
        }
        String message = in.textUpTo('\0');

        if (cset == null) {
            // Revision -1:000000000000
            return null;
        }

        ChangesetData data = cset.data;
        if (data == null) {
            data = new ChangesetData(revision, user, timestamp, branch, parent1, parent2, message);
            cset.data = data;
        } else if (revision != data.revision) {
            // Handle revision specially because revision is not part of the node
            data.revision = revision;
        }
        return cset;
    }

    /**
     * This method is an alias for {@link #readListFromStream(Repository, HgInputStream, boolean)} with the eager
     * parameter set to false.
     * 
     * @param repository
     * @param in
     * @return
     */
    public static List<Changeset> readListFromStream(Repository repository, HgInputStream in) {
        return readListFromStream(repository, in, false);
    }

    /**
     * Read the rest of the content of the stream and return a List of the Changeset found there.
     * <p>
     * Be aware the this method will read everything from the stream, what is after the changesets will simply be
     * discarded.
     * 
     * @param repository
     * @param in
     * @param eager
     * @return
     */
    public static List<Changeset> readListFromStream(Repository repository, HgInputStream in, boolean eager) {
        List<Changeset> changesets = Lists.newArrayList();
        try {
            boolean found = in.find(CHANGESET_PATTERN);
            if (found) {
                while (!in.match(CHANGESET_PATTERN)) {
                    Changeset cset = Changeset.createFromInputStream(repository, in, eager);

                    if (cset != null) {
                        changesets.add(cset);
                    }
                }
            }
            // If the pattern is not found there is no changsets
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        } finally {
            try {
                Utils.consumeAll(in);
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            }
        }
        return changesets;
    }

    public String getNode() {
        return this.node;
    }

    public int getRevision() {
        ensureAllDataLoaded();
        return this.data.revision;
    }

    public String getUser() {
        ensureAllDataLoaded();
        return this.data.user;
    }

    public DateTime getTimestamp() {
        ensureAllDataLoaded();
        return this.data.timestamp;
    }

    public String getBranch() {
        ensureAllDataLoaded();
        return this.data.branch;
    }

    public Changeset getParent1() {
        ensureAllDataLoaded();
        return this.data.parent1;
    }

    public Changeset getParent2() {
        ensureAllDataLoaded();
        return this.data.parent2;
    }

    public String getMessage() {
        ensureAllDataLoaded();
        return this.data.message;
    }

    public List<String> getAddedFiles() {
        ensureFileDataLoaded();
        return this.fileData.addedFiles;
    }

    public List<String> getModifiedFiles() {
        ensureFileDataLoaded();
        return this.fileData.modifiedFiles;
    }

    public List<String> getDeletedFiles() {
        ensureFileDataLoaded();
        return this.fileData.deletedFiles;
    }

    private void loadFileData() {
        StatusResult result = new StatusCommand(repository).added().modified().removed().change(this.node).execute();
        if (result != null) {
            fileData = new ChangesetFileData(result.getAdded(), result.getModified(), result.getRemoved());
        } else {
            throw new IllegalStateException("could not load file data from status");
        }
    }

    private void ensureFileDataLoaded() {
        if (this.fileData != null) {
            return;
        }
        loadFileData();
        if (this.fileData == null) {
            throw new IllegalStateException("could not load file data");
        }
    }

    private void ensureAllDataLoaded() {
        if (this.data != null) {
            return;
        }
        LogCommand.on(this.repository).rev(getNode()).execute();
        if (this.data == null) {
            throw new IllegalStateException("data was not loaded");
        }
    }

    @Deprecated
    public Phase readPhase() {
        return phase();
    }

    /**
     * 
     * @return the phase for this changeset.
     */
    public Phase phase() {
        Map<Changeset, Phase> phases = getRepository().phases(getNode());
        return phases.get(this);
    }

    /**
     * Return tags that is pointing the this changeset
     */
    public List<String> tags() {
        GenericLogCommand cmd = new GenericLogCommand(getRepository()).style("tags");
        cmd.rev(getNode());
        HgInputStream stream = cmd.stream();
        List<String> result = Lists.newArrayList();
        try {
            // Skip to where JavaHg expected output is.
            if (stream.find(TemplateMarkers.JAVAHG_MARKER)) {
                while (!stream.isEof()) {
                    if (stream.find(TemplateMarkers.JAVAHG_MARKER_TAG)) {
                        String tag = stream.textUpTo(0);
                        if (!"tip".equals(tag)) {
                            result.add(tag);
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeIOException(e);
        } finally {
            try {
                stream.consumeAll();
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            }
        }
        return result;
    }

    /**
     * 
     * @return Mercurial's extra dictionary
     */
    @SuppressWarnings("synthetic-access")
    public synchronized Extra getExtra() {
        if (this.extra == null) {
            GenericLogCommand cmd = new GenericLogCommand(getRepository()).style("extras");
            cmd.rev(getNode());
            this.extra = new Extra(cmd.stream());
        }
        return this.extra;
    }

    @Override
    public boolean equals(Object that) {
        if (that instanceof Changeset) {
            return equals((Changeset) that);
        }
        return false;
    }

    public boolean equals(Changeset that) {
        if (this.repository != that.repository) {
            return false;
        }
        return this.getNode().equals(that.getNode());
    }

    @Override
    public int hashCode() {
        return getNode().hashCode();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("changeset[");
        builder.append(this.data == null ? "?" : this.data.revision).append(':').append(this.node).append(']');
        return builder.toString();
    }

    @VisibleForTesting
    ChangesetData getData() {
        return this.data;
    }

    @VisibleForTesting
    ChangesetFileData getFileData() {
        return this.fileData;
    }

    Repository getRepository() {
        return repository;
    }

    String decodeBytes(byte[] bytes) {
        return Utils.decodeBytes(bytes, getRepository().newDecoder());
    }

    /**
     * Class representing the extra dictionary Mercurial has for each changeset.
     * <p>
     * The values can be binary data, but is typically strings. For this reason there is accessor methods to access the
     * values as both byte array and String.
     */
    public class Extra {

        private final Map<String, byte[]> map;

        private Extra(HgInputStream stream) {
            try {
                this.map = Maps.newHashMap();

                // Skip to where JavaHg expected output is. See TemplateMarkers file for more info.
                if (stream.find(TemplateMarkers.JAVAHG_MARKER)) {
                    // The value is binary data, node is used as delimiter
                    byte[] node = stream.upTo(0);
                    while (!stream.isEof()) {
                        String key = stream.textUpTo(0);
                        byte[] value = stream.upTo(node);
                        this.map.put(key, value);
                    }
                }
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            } finally {
                try {
                    stream.consumeAll();
                } catch (IOException e) {
                    throw new RuntimeIOException(e);
                }
            }
        }

        /**
         * Amenel Voglozin, 2016-12-29: the bytes of "extras" appear to be returned by hg in UTF-8 irrespective of the
         * actual encoding of the repository. A simple test to prove it is to set a breakpoint in
         * ChangesetTest.testExtra at cs.getExtra() after the branch name with non-ascii characters:
         * <ol>
         * <li>get the command from debugging the code and run it (I always issue <code>chcp 1252</code> first because
         * I'm on a French Windows system), e.g. <code>log --debug --style
         * C:\Users\Amenel\.javahg\tmp\1483029023744-0\styles\extras.style --rev
         * 41d0b072e76f098ec487f32c5f57ec9aa321aad5</code>
         * <li>remove the style specification and run the command, e.g. <code>hg 
         * log --debug --rev 41d0b072e76f098ec487f32c5f57ec9aa321aad5</code>
         * </ol>
         * In the first case, the branch name is garbled. In the second case, the branch name is returned as it was
         * sent, revealing that somehow, hg converted the UTF-8 byte train to the local encoding (ISO-8859-1 on Windows)
         * 
         * @param key
         * @return The extra data for the key as a String
         */
        public String getString(String key) {
            byte[] bytes = getBytes(key);
            if (bytes == null) {
                return null;
            }
            // hg 4.0 returns a UTF-8 bytes no matter what the repo encoding is.
            return Utils.decodeBytes(bytes, Utils.getUtf8Charset().newDecoder());
        }

        /**
         * @param key
         * @return The extra data for the key as byte array
         */
        public byte[] getBytes(String key) {
            return map.get(key);
        }

        /**
         * @return a view on the extra data dictionary where values are Strings.
         */
        public Map<String, String> stringValuedMap() {
            Function<byte[], String> f = new Function<byte[], String>() {
                @Override
                public String apply(byte[] input) {
                    return decodeBytes(input);
                }
            };
            return Maps.transformValues(this.map, f);
        }

        /**
         * @return a view on the extra data dictionary where values are byte arrays.
         */
        public Map<String, byte[]> byteArrayValuedMap() {
            return this.map;
        }

    }

}

class ChangesetFileData {

    public List<String> addedFiles;
    public List<String> modifiedFiles;
    public List<String> deletedFiles;

    public ChangesetFileData(List<String> addedFiles, List<String> modifiedFiles, List<String> deletedFiles) {
        this.addedFiles = addedFiles;
        this.modifiedFiles = modifiedFiles;
        this.deletedFiles = deletedFiles;
    }

}

class ChangesetData {
    public int revision;
    public String user;
    public DateTime timestamp;
    public String branch;
    public Changeset parent1;
    public Changeset parent2;
    public String message;

    public ChangesetData(int revision, String user, DateTime timestamp, String branch, Changeset parent1,
            Changeset parent2, String message) {
        this.revision = revision;
        this.user = user;
        this.timestamp = timestamp;
        this.branch = branch;
        this.parent1 = parent1;
        this.parent2 = parent2;
        this.message = message;
    }
}
