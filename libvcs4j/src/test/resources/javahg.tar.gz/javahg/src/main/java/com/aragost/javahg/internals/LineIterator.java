package com.aragost.javahg.internals;

import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class LineIterator implements Iterator<String>, Iterable<String> {

    private boolean atEnd = false;

    private HgInputStream stream;

    public LineIterator(HgInputStream stream) {
        this.stream = stream;
    }

    @Override
    public Iterator<String> iterator() {
        return this;
    }

    @Override
    public boolean hasNext() {
        if (!this.atEnd) {
            try {
                this.atEnd = (this.stream.isEof());
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            }
        }
        return !this.atEnd;
    }

    @Override
    public String next() {
        if (hasNext()) {
            try {
                return this.stream.textUpTo('\n');
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            }
        }
        throw new NoSuchElementException();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }

}
