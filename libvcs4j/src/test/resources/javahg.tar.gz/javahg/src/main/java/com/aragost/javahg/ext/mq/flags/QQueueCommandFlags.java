/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.1.1+41-63a1bed65fa3.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.ext.mq.flags;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.QQueueCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class QQueueCommandFlags extends AbstractCommand {

    protected QQueueCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "qqueue";
    }

    public static QQueueCommand on(Repository repository) {
        return new QQueueCommand(repository);
    }

    /**
     * Set the <tt>--list</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand list() {
        cmdAppend("--list");
        return (QQueueCommand) this;
    }

    /**
     * Set the <tt>--active</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand active() {
        cmdAppend("--active");
        return (QQueueCommand) this;
    }

    /**
     * Set the <tt>--create</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand create() {
        cmdAppend("--create");
        return (QQueueCommand) this;
    }

    /**
     * Set the <tt>--rename</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand rename() {
        cmdAppend("--rename");
        return (QQueueCommand) this;
    }

    /**
     * Set the <tt>--delete</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand delete() {
        cmdAppend("--delete");
        return (QQueueCommand) this;
    }

    /**
     * Set the <tt>--purge</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#qqueue">Mercurial documentation</a>
     * @return this instance
     */
    public QQueueCommand purge() {
        cmdAppend("--purge");
        return (QQueueCommand) this;
    }

}
