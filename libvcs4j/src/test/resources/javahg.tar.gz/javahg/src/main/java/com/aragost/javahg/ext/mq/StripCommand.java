package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.StripCommandFlags;

public class StripCommand extends StripCommandFlags {

    public StripCommand(Repository repository) {
        super(repository);
        cmdAppend("-y");
    }

    public String execute() {
        return launchString();
    }
}
