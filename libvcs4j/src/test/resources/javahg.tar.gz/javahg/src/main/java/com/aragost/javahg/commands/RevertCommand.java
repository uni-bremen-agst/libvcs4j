package com.aragost.javahg.commands;

import java.io.File;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.RevertCommandFlags;
import com.aragost.javahg.internals.Utils;

public class RevertCommand extends RevertCommandFlags {

    public RevertCommand(Repository repository) {
        super(repository);
        cmdAppend("-y");
    }

    /**
     * Execute with no files. Should be used with {@link #all()}
     */
    public void execute() {
        launchString(new String[0]);
    }

    /**
     * @param files
     *            the files to revert.
     */
    public String execute(String... files) {
        return launchString(files);
    }

    /**
     * @param files
     *            the files to revert.
     */
    public String execute(File... files) {
        return execute(Utils.fileArray2StringArray(files));
    }
}
