package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QPopCommandFlags;

public class QPopCommand extends QPopCommandFlags {

    public QPopCommand(Repository repository) {
        super(repository);
    }

    /**
     * Invoke qpop
     */
    public void execute() {
        launchString();
    }

    /**
     * Invoke qpop
     * 
     * @param patchName
     *            The patch name to pop
     */
    public void execute(String patchName) {
        launchString(patchName);
    }
}
