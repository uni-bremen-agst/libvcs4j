package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QPushCommandFlags;

public class QPushCommand extends QPushCommandFlags {

    public QPushCommand(Repository repository) {
        super(repository);
    }

    /**
     * Invoke qpush
     */
    public void execute() {
        launchString();
    }

    /**
     * Invoke qpush
     * 
     * @param patchName
     *            The patch name to push
     */
    public void execute(String patchName) {
        launchString(patchName);
    }
}
