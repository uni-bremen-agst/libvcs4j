/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.util.Map;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.CopyCommandFlags;
import com.aragost.javahg.internals.CopyRenameHelper;
import com.aragost.javahg.internals.Utils;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Maps;

/**
 * Command class for executing <tt>hg copy</tt>. Set flags from {@link CopyCommandFlags} and call the {@link #execute}
 * method.
 */
public class CopyCommand extends CopyCommandFlags {

    @VisibleForTesting
    static final String PREFIX = "copying ";

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public CopyCommand(Repository repository) {
        super(repository);
        withDebugFlag();
    }

    /**
     * @param files
     *            the files to copy. The last file in this list is the destination. If two files are given, the target
     *            must be a directory or a non-existing file. If more files are given, the destination must be an
     *            directory.
     * @return mapping from new names to old names.
     */
    // TODO: this would be clearer if we overloaded execute to take
    // either (String src, String dst) or (String[] srcs, String dst).
    public Map<String, String> execute(String... files) {
        Map<File, File> map = execute(Utils.stringArray2FileArray(getRepository().getDirectory(), files));
        Map<String, String> result = Maps.newHashMap();
        for (Map.Entry<File, File> entry : map.entrySet()) {
            result.put(entry.getKey().getPath(), entry.getValue().getPath());
        }
        return result;
    }

    public Map<File, File> execute(File... files) {
        if (files.length < 2) {
            throw new IllegalArgumentException("must provide at least two files");
        }

        return CopyRenameHelper.parse(getRepository(), files, launchIterator(Utils.fileArray2StringArray(files)),
                PREFIX);
    }
}
