/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.IOException;
import java.io.InputStream;

import com.aragost.javahg.Changeset;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.UpdateCommandFlags;
import com.aragost.javahg.internals.UpdateMergeHelper;

/**
 * Command class for executing <tt>hg update</tt>. Set flags from {@link UpdateCommandFlags} and call the
 * {@link #execute} method.
 */
public class UpdateCommand extends UpdateCommandFlags {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public UpdateCommand(Repository repository) {
        super(repository);
    }

    /**
     * Run <tt>hg update</tt> on a clean working copy. This runs with no merge oracle and so the caller must ensure that
     * there are no merge conflicts.
     * 
     * @return the update result.
     * @throws IOException
     */
    public UpdateResult execute() throws IOException {
        return executeHelper(null);
    }

    /**
     * Run <tt>hg update</tt> with a merge oracle.
     * 
     * @param oracle
     *            the merge oracle to use in case of merge conflicts.
     * 
     * @return the update result.
     * @throws IOException
     */
    public UpdateResult execute(ManifestMergeOracle oracle) throws IOException {
        if (oracle == null) {
            throw new IllegalArgumentException("oracle == null");
        }
        return executeHelper(oracle);
    }

    private UpdateResult executeHelper(ManifestMergeOracle oracle) throws IOException {
        InputStream stdout = launchStream();
        UpdateMergeHelper helper = new UpdateMergeHelper(stdout, oracle, this);
        return helper.update();
    }

    @Override
    public boolean isSuccessful() {
        return super.isSuccessful() || getReturnCode() == 1;
    }

    /**
     * @return True if the command was not successful because it would have crossed branches. Applicable to updates
     *         where revision is not specified.
     */
    public boolean crossedBranch() {
        String errorString = getErrorString();

        return errorString.indexOf("abort: crosses branches") >= 0
                || errorString.indexOf("abort: not a linear update") >= 0;
    }

    /**
     * Set the <tt>--rev</tt> flag.
     * 
     * @param cset
     *            the changeset to update to
     * @return this command.
     */
    public UpdateCommand rev(Changeset cset) {
        super.rev(cset.getNode());
        return this;
    }
}
