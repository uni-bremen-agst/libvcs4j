package com.aragost.javahg.merge;

import com.aragost.javahg.commands.ResolveCommand;

public class MergeConflict extends MergeFile {

    private boolean resolved = false;

    public MergeConflict(ConflictResolvingContext mergeState, String file) {
        super(mergeState, file);
    }

    public boolean isResolved() {
        return resolved;
    }

    /**
     * Attempt to resolve conflict with Mercurial's internal merge tool
     * 
     * @return true if the conflict was resolved, false otherwise
     */
    public boolean resolveWithInternalMerge() {
        return resolveWith("internal:merge");
    }

    /**
     * Attempt to resolve conflict with the specified tool.
     * 
     * @return true if the conflict was resolved, false otherwise
     */
    public boolean resolveWith(String tool) {
        ResolveCommand cmd = ResolveCommand.on(getRepository()).tool(tool);
        cmd.execute(getFilename());
        this.resolved = cmd.getReturnCode() == 0;
        return this.resolved;
    }

    /**
     * Mark this merge conflict as resolved
     */
    public void markResolved() {
        ResolveCommand.on(getRepository()).mark(getFilename());
    }

}
