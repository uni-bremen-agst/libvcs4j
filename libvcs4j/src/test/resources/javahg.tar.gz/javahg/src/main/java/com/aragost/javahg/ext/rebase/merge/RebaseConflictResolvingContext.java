package com.aragost.javahg.ext.rebase.merge;

import java.io.File;
import java.io.IOException;

import com.aragost.javahg.Bundle;
import com.aragost.javahg.Changeset;
import com.aragost.javahg.ext.rebase.RebaseCommand;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.UnexpectedCommandOutputException;
import com.aragost.javahg.internals.Utils;
import com.aragost.javahg.merge.ConflictResolvingContext;

public class RebaseConflictResolvingContext extends ConflictResolvingContext {

    private static final byte[] SAVED_BACKUP_BUNDLE_TO = "saved backup bundle to ".getBytes();
    private File backupBundleFile;

    public RebaseConflictResolvingContext(RebaseCommand command) {
        super(command);
    }

    public void processStream(HgInputStream in) throws IOException {
        super.processStream(in, true);

        while (!in.isEof()) {
            if (in.find(SAVED_BACKUP_BUNDLE_TO)) {
                assert this.backupBundleFile == null;
                this.backupBundleFile = new File(in.textUpTo('\n'));
            } else {
                throw new UnexpectedCommandOutputException(Utils.readStream(in, getRepository().newDecoder()));
            }
        }
    }

    /**
     * @see com.aragost.javahg.merge.ConflictResolvingContext#getRemote()
     */
    @Override
    public Changeset getRemote() {
        // Future: should find the tip of the changesets contained in the bundle
        // and use that and have getRepository() return the overlay repository.
        return super.getRemote();
    }

    public Bundle getBackupBundle() {
        if (backupBundleFile != null) {
            return new Bundle(getRepository().getBaseRepository(), backupBundleFile, false);
        }

        return null;
    }

    public File getBackupBundleFile() {
        return backupBundleFile;
    }
}
