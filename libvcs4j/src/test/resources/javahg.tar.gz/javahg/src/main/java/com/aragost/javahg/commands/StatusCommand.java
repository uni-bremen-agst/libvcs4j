/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.StatusCommandFlags;
import com.aragost.javahg.internals.HgInputStream;
import com.aragost.javahg.internals.RuntimeIOException;
import com.aragost.javahg.internals.Utils;
import com.google.common.collect.Lists;

/**
 * Command class for executing <tt>hg status</tt>. Set flags from {@link StatusCommandFlags} and call the
 * {@link #execute} method.
 */
public class StatusCommand extends StatusCommandFlags implements Iterable<StatusLine> {

    /**
     * @param repository
     *            the repository associated with this command.
     */
    public StatusCommand(Repository repository) {
        super(repository);
    }

    /**
     * @return a status result.
     */
    public StatusResult execute() {
        return execute(new String[0]);
    }

    /**
     * @param files
     *            the files to query.
     * @return a status result.
     */
    public StatusResult execute(String... files) {
        StatusResult result = new StatusResult();
        for (Iterator<StatusLine> i = iterator(files); i.hasNext();) {
            StatusLine line = i.next();
            result.addLine(line);
        }
        return result;
    }

    /**
     * @param files
     *            the files to query.
     * @return a status result.
     */
    public StatusResult execute(File... files) {
        return execute(Utils.fileArray2StringArray(files));
    }

    /**
     * 
     * @return a list of status lines.
     */
    public List<StatusLine> lines() {
        return lines(new String[0]);
    }

    /**
     * @param files
     *            the files to query.
     * @return a list of status lines.
     */
    public List<StatusLine> lines(String... files) {
        List<StatusLine> lines = Lists.newArrayList();
        for (Iterator<StatusLine> i = iterator(files); i.hasNext();) {
            lines.add(i.next());
        }
        return lines;
    }

    /**
     * @param files
     *            the files to query.
     * @return a list of status lines.
     */
    public List<StatusLine> lines(File... files) {
        return lines(Utils.fileArray2StringArray(files));
    }

    @Override
    public Iterator<StatusLine> iterator() {
        return iterator(new String[0]);
    }

    /**
     * @param files
     *            the files to query
     * @return an iterator over status lines. The iterator must be exhausted before another command is sent to the
     *         server.
     */
    public Iterator<StatusLine> iterator(String... files) {
        return new StatusLineIterator(launchStream(files));
    }

    private static class StatusLineIterator implements Iterator<StatusLine> {

        private boolean nextLineCurrent = false;
        private StatusLine nextLine = null;
        private HgInputStream in;

        public StatusLineIterator(HgInputStream in) {
            super();
            this.in = in;
        }

        @Override
        public boolean hasNext() {
            if (!this.nextLineCurrent) {
                this.nextLine = readLine();
                this.nextLineCurrent = true;
            }
            return this.nextLine != null;
        }

        @Override
        public StatusLine next() {
            if (this.nextLineCurrent) {
                this.nextLineCurrent = false;
                return this.nextLine;
            }
            StatusLine line = readLine();
            if (line == null) {
                throw new NoSuchElementException();
            }
            return line;

        }

        private StatusLine readLine() {
            try {
                if (this.in.isEof()) {
                    return null;
                }
                return StatusLine.fromStream(this.in);
            } catch (IOException e) {
                throw new RuntimeIOException(e);
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
