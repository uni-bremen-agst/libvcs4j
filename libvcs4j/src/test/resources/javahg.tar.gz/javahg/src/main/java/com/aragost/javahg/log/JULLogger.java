package com.aragost.javahg.log;

import java.util.logging.Level;

import com.google.common.annotations.VisibleForTesting;

/**
 * This simulates the Logger class from slf4j.
 * <p>
 * Only the methods that is actually used by JavaHg is implemented, but others will be added as needed.
 * <p>
 * Implementation note: In general for log level abc there is an <code>void abc(String msg)</code> and
 * <code>void abc(String msg, Object[] args)</code>. The first simply writes the message to the backend with no
 * formatting, the second will do a formatting similar to slf4j. The first is strictly not needed, but the consequence
 * would be that for even simple log messages a temp array would be created for the varargs.
 * 
 */
public class JULLogger implements Logger {

    private final java.util.logging.Logger julLogger;

    public JULLogger(String name) {
        this.julLogger = java.util.logging.Logger.getLogger(name);
    }

    @Override
    public void debug(String msg) {
        this.julLogger.fine(msg);
    }

    @Override
    public void debug(String msg, Object... args) {
        if (isDebugEnabled()) {
            this.julLogger.fine(format(msg, args));
        }
    }

    @Override
    public void debug(String msg, Throwable thrown) {
        logException(Level.FINE, msg, thrown);
    }

    @Override
    public void info(String msg) {
        this.julLogger.info(msg);
    }

    @Override
    public void info(String msg, Object... args) {
        if (isInfoEnabled()) {
            this.julLogger.info(format(msg, args));
        }
    }

    @Override
    public void info(String msg, Throwable thrown) {
        logException(Level.INFO, msg, thrown);
    }

    @Override
    public void warn(String msg) {
        this.julLogger.warning(msg);
    }

    @Override
    public void warn(String msg, Object... args) {
        this.julLogger.warning(format(msg, args));
    }

    @Override
    public void warn(String msg, Throwable thrown) {
        logException(Level.WARNING, msg, thrown);
    }

    @Override
    public void error(String msg) {
        this.julLogger.severe(msg);
    }

    @Override
    public void error(String msg, Object... args) {
        this.julLogger.severe(format(msg, args));
    }

    @Override
    public void error(String msg, Throwable thrown) {
        logException(Level.SEVERE, msg, thrown);
    }

    @Override
    public boolean isDebugEnabled() {
        return this.julLogger.isLoggable(Level.FINE);
    }

    @Override
    public boolean isInfoEnabled() {
        return this.julLogger.isLoggable(Level.INFO);
    }

    @Override
    public boolean isWarnEnabled() {
        return this.julLogger.isLoggable(Level.WARNING);
    }

    @Override
    public boolean isErrorEnabled() {
        return this.julLogger.isLoggable(Level.SEVERE);
    }

    /**
     * Simulate the slf4j formatting of messages. This does not have all the features of slf4j, it is not possible to
     * escape {} in the message. It will always be interpreted as an anchore.
     * <p>
     * If there is too few args compared to anchors in the format then the method fails with IndexOutOfBoundException
     * 
     * @param format
     * @param args
     * @return
     */
    @VisibleForTesting
    static String format(String format, Object[] args) {
        int length = format.length();
        StringBuilder tgt = new StringBuilder(length);
        int prevPos = 0;
        int argIndex = 0;
        while (prevPos < length) {
            int pos = format.indexOf("{}", prevPos);
            if (pos >= 0) {
                Object arg = args[argIndex++];
                tgt.append(format.substring(prevPos, pos));
                tgt.append(arg == null ? "" : arg.toString());
                prevPos = pos + 2;
            } else {
                tgt.append(format.substring(prevPos));
                prevPos = length;
            }
        }
        return tgt.toString();
    }

    private void logException(Level level, String msg, Throwable thrown) {
        this.julLogger.log(level, msg, thrown);
    }
}
