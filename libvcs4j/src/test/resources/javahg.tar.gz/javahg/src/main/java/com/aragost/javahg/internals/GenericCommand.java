package com.aragost.javahg.internals;

import com.aragost.javahg.Repository;

public class GenericCommand extends AbstractCommand {

    private String commandName;

    public GenericCommand(Repository repository, String commandName) {
        super(repository, commandName);
        this.commandName = commandName;
    }

    @Override
    public String getCommandName() {
        return this.commandName;
    }

    public String execute(String... args) {
        return launchString(args);
    }
}
