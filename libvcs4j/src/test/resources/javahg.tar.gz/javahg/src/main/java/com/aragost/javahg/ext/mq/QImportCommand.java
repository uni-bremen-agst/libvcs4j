package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QImportCommandFlags;

public class QImportCommand extends QImportCommandFlags {

    public QImportCommand(Repository repository) {
        super(repository);
        cmdAppend("--git");
    }

    /**
     * Invoke qimport
     */
    public void execute() {
        launchString();
    }

    /**
     * Invoke qimport
     * 
     * @param file
     *            The patch file to import
     */
    public void execute(String file) {
        launchString(file);
    }
}
