package com.aragost.javahg.ext.mq;

import com.aragost.javahg.Repository;
import com.aragost.javahg.ext.mq.flags.QRenameCommandFlags;

public class QRenameCommand extends QRenameCommandFlags {

    public QRenameCommand(Repository repository) {
        super(repository);
    }

}
