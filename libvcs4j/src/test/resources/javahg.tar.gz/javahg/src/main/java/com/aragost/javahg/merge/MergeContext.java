package com.aragost.javahg.merge;

import com.aragost.javahg.internals.AbstractCommand;

public class MergeContext extends ConflictResolvingContext {

    public MergeContext(AbstractCommand command) {
        super(command);
    }

}
