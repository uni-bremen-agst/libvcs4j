/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */
package com.aragost.javahg.commands;

import java.util.List;

import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.flags.BranchesCommandFlags;
import com.aragost.javahg.log.Logger;
import com.aragost.javahg.log.LoggerFactory;
import com.google.common.collect.Lists;

/**
 * Command class for executing <tt>hg branches</tt>. Set flags from {@link BranchesCommandFlags} and see the
 * {@link #execute()} method for how to run the command.
 * <p>
 * This class wont be able to parse the branch names correctly if they contain newline characters (Mercurial will
 * unfortunately let you create such branch names).
 */
public class BranchesCommand extends BranchesCommandFlags {

    private static final Logger LOG = LoggerFactory.getLogger(BranchesCommand.class);

    public BranchesCommand(Repository repository) {
        super(repository);
        withDebugFlag();
    }

    /**
     * @return list of branches for the repository
     */
    public List<Branch> execute() {
        List<Branch> branches = Lists.newArrayList();
        for (String line : launchIterator()) {
            try {
                Branch branch = Branch.fromLine(getRepository(), line);
                branches.add(branch);
            } catch (Exception e) {
                //
                // Take into account the possibility that a line does not actually describe a branch. This may happen
                // when an extension outputs text before the text that we're interested in or when hg encounters an
                // error but still provides the branch names (the case that prompted this change is an error that read
                // «invalid branchheads cache (visible): tip differs"»).
                LOG.error("Error getting branch name (line read: '" + line + "')", e);
            }
        }
        return branches;
    }

}
