/*
 * #%L
 * JavaHg
 * %%
 * Copyright (C) 2011 aragost Trifork ag
 * %%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #L%
 */

/*
 * Automatically generated based on Mercurial 2.3+10-9d9d15928521.
 *
 * Don't edit this file! Edit scripts/generate-flag-classes.py instead.
 */
package com.aragost.javahg.commands.flags;

import com.aragost.javahg.Args;
import com.aragost.javahg.Repository;
import com.aragost.javahg.commands.BackoutCommand;
import com.aragost.javahg.internals.AbstractCommand;

public abstract class BackoutCommandFlags extends AbstractCommand {

    protected BackoutCommandFlags(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "backout";
    }

    public static BackoutCommand on(Repository repository) {
        return new BackoutCommand(repository);
    }

    /**
     * Set the <tt>--merge</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand merge() {
        cmdAppend(Args.MERGE);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--parent</tt> command line flag.
     * 
     * @deprecated Using this flag has been deprecated in Mercurial. The flag wont go away, but there will typically be
     *             a better way to express the same thing.
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    @Deprecated
    public BackoutCommand parent(String rev) {
        cmdAppend(Args.PARENT, rev);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--rev</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand rev(String rev) {
        cmdAppend(Args.REVISION, rev);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--tool</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand tool(String value) {
        cmdAppend(Args.TOOL, value);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--include</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand include(String... patterns) {
        cmdAppend(Args.INCLUDE, patterns);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--exclude</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand exclude(String... patterns) {
        cmdAppend(Args.EXCLUDE, patterns);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--message</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand message(String text) {
        cmdAppend(Args.MESSAGE, text);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--date</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand date(String date) {
        cmdAppend(Args.DATE, date);
        return (BackoutCommand) this;
    }

    /**
     * Set the <tt>--user</tt> command line flag.
     * 
     * @see <a href="http://www.selenic.com/mercurial/hg.1.html#backout">Mercurial documentation</a>
     * @return this instance
     */
    public BackoutCommand user(String user) {
        cmdAppend(Args.USER, user);
        return (BackoutCommand) this;
    }

}
