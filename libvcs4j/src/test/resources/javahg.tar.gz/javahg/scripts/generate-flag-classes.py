#!/usr/bin/python
###
# #%L
# JavaHg
# %%
# Copyright (C) 2011 aragost Trifork ag
# %%
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# #L%
###

# Generate interfaces and abstract command for javahg
#
# Copyright 2011 aragost Trifork

import os, re, sys, optparse, fnmatch, subprocess

optblacklist = [
    'annotate.user',
    'annotate.file',
    'annotate.date',
    'annotate.number',
    'annotate.changeset',
    'annotate.line-number',
    'annotate.follow',
    'bookmarks.delete',
    'bookmarks.rename',
    'branch.clean',
    'cat.output',
    'commit.addremove',
    'export.output',
    'graft.edit',
    'graft.rev',
    'heads.active',
    'locate.fullpath',
    'log.patch',
    'log.stat',
    'log.style',
    'import.strip',
    'import.edit',
    'incoming.patch',
    'incoming.stat',
    'merge.preview',
    'outgoing.patch',
    'outgoing.stat',
    'pull.update',
    'resolve.list',
    'resolve.no-status',
    'resolve.mark',
    'resolve.unmark',
    'status.no-status',
    'tag.edit',
    '*.dry-run',
    '*.git',
    '*.text',
    '*.print0',
    '*.subrepos',
    '*.template',
    '*.style',
    '*.logfile',
    '*.graph',
    # Blacklist Java keywords, need special handling
    '*.continue', 
    '*.public',
    '*.short',
    '*.long',
    ]

cmdwhitelist = [
    'add',
    # 'addremove', # Disabled due to case problem
    'annotate',
    'backout',
    'bisect',
    'bookmarks',
    'branch',
    'branches',
    'cat',
    'clone',
    'commit',
    'copy',
    'diff',
    'export',
    'graft',
    'heads',
    'identify',
    'import',
    'incoming',
    'locate',
    'log',
    'manifest',
    'merge',
    'outgoing',
    'parents',
    'phase',
    'pull',
    'push',
    'remove',
    'rename',
    'resolve',
    'revert',
    'rollback',
    'root',
    'status',
    'tag',
    'tags',
    'update',
    'version',
    ]

opttypes = {
    'annotate.date': 'boolean',
    'commit.date': 'DateTime',
    'diff.unified': 'int',
    'log.limit': 'int',
    'tag.date': 'DateTime',
    }

def camelcase(s, first=False):
    parts = s.split("-")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def plural(s):
    if s == "branch":
        return s + "es"
    else:
        return s + "s"


def splitopt(cmdname, option):
    longopt, metavar, repeat = option[:3]

    qualified = cmdname + "." + longopt

    opttype = "String"
    for glob in opttypes:
        if fnmatch.fnmatch(qualified, glob):
            opttype = opttypes[glob]
            break

    if repeat:
        opttype = opttype + "..."
        metavar = plural(metavar)

    if not metavar:
        opttype = "boolean"
        arg = ""
    else:
        arg = "%s %s" % (opttype, metavar)
    return longopt, arg, opttype, metavar


def implementation(javadir, name, options, version, unlink=False):
    clsname = "%sCommandFlags" % (name[0].upper() + name[1:]) 
    cmdclsname = "%sCommand" % (name[0].upper() + name[1:])
    name = name.lower()

    path = os.path.join(javadir, 'flags', clsname + ".java")
    if unlink:
        if os.path.exists(path):
            os.unlink(path)
        return

    fp = open(path, "w")

    fp.write("""\
/*
 * #%s
 * JavaHg
 * %%%%
 * Copyright (C) 2011 aragost Trifork ag
 * %%%%
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * #%s
 */
""" % ("%L", "L%")) # interpolation to avoid two %L-L% pairs in this script
    fp.write("\n")
    fp.write("/*\n")
    fp.write(" * Automatically generated based on Mercurial %s.\n" % version)
    fp.write(" *\n")
    fp.write(" * Don't edit this file! Edit scripts/generate-flag-classes.py "
             "instead.\n")
    fp.write(" */\n")

    # Future: Support configurable package
    packageIdx = javadir.find("com/aragost")
    package = "com.aragost.javahg.commands" if packageIdx < 0 else javadir[packageIdx:].replace("/", ".")

    fp.write("package %s.flags;\n" % package)
    fp.write("\n")

    if [o for o in options if splitopt(name, o)[2].startswith("Date")]:
        fp.write("import com.aragost.javahg.DateTime;\n")
        fp.write("\n")

    fp.write("import com.aragost.javahg.Repository;\n")
    fp.write("import %s.%s;\n" % (package, cmdclsname))
    fp.write("import com.aragost.javahg.internals.AbstractCommand;\n")
    fp.write("\n")
    fp.write("public abstract class %s extends AbstractCommand {\n"
             % (clsname))

    fp.write("""
    protected %s(Repository repository) {
        super(repository);
    }

    @Override
    public final String getCommandName() {
        return "%s";
    }

    public static %s on(Repository repository) {
        return new %s(repository);
    }

""" % (clsname, name, cmdclsname, cmdclsname))

    for option in options:
        longopt, arg, opttype, metavar = splitopt(name, option)
        fp.write("    /**\n")
        fp.write("     * Set the <tt>--%s</tt> command line flag.\n" % longopt)
        fp.write("     * \n")
        if option[3]:
            fp.write("""\
     * @deprecated Using this flag has been deprecated in Mercurial.
     *             The flag wont go away, but there will typically be
     *             a better way to express the same thing.
""")

        fp.write('     * @see <a\n')
        fp.write('     *      href="http://www.selenic.com/mercurial/'
                 'hg.1.html#%s">Mercurial\n' % name)
        fp.write("     *      documentation</a>\n")
        fp.write("     * @return this instance\n")
        fp.write("     */\n")

        if option[3]:
            fp.write("    @Deprecated\n")
        fp.write("    public %s %s(%s) {\n"
                 % (cmdclsname, camelcase(longopt), arg))
        if arg:
            fp.write('        cmdAppend("--%s", %s);\n' % (longopt, metavar))
        else:
            fp.write('        cmdAppend("--%s");\n' % longopt)
        fp.write("        return (%s) this;\n" % cmdclsname)
        fp.write("    }\n\n")

    fp.write("}\n")
    fp.close()


def runhg(hg, *args):
    cmdline = [hg] + list(args)
    p = subprocess.Popen(cmdline, env=dict(HGRCPATH="", HGPLAIN="",
                                           PATH=os.environ["PATH"]),
                         stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    assert not stderr, "%s -> %s" % (" ".join(cmdline), stdout)
    return stdout

def hgversion(hg):
    line = runhg(hg, "version", "-q")
    m = re.match(r"Mercurial Distributed SCM \(version (.+)\)", line)
    assert m, "no version in %r" % line
    return m.group(1)

def findcommands(hg):
    lines = runhg(hg, "help").splitlines()
    commands = []
    for line in lines[4:]:
        if not line.strip():
            break
        commands.append(line[1:line.index(" ", 1)])
    return commands

def findoptions(hg, cmd, extension=None):
    args = ["help", "-v", cmd]
    if extension is not None:
        args.extend(["--config", "extensions.%s=" % extension])
    lines = runhg(hg, *args).splitlines()
    if not "options:" in lines:
        return []
    start = lines.index("options:") + 2
    stop = lines.index("global options:", start) - 1

    try:
        stop = lines.index("[+] marked option can be specified multiple times",
                           start, stop) - 1
    except ValueError:
        pass # no repeated options before global options

    options = []
    for line in lines[start:stop]:
        deprecated = 'DEPRECATED' in line
        if line[4:6] == "  ":
            # continuation line caused by long help text
            if deprecated:
                # mark flag as deprecated
                options[-1] = options[-1][:-1] + (True,)
            continue

        a = 6
        b = line.find(" ", a)
        c = line.find(" ", b + 1)

        longopt = line[a:b]
        metavar = line[b + 1:c]
        if metavar.isupper():
            metavar = metavar.lower()
        else:
            metavar = "" # first word of option help text
        repeat = line[c+1:c+4] == "[+]"
        options.append((longopt, metavar, repeat, deprecated))
    return options

def process(hg, javadir, extension, commands):
    version = hgversion(hg)
    optskip = re.compile("|".join("(?:%s)" % fnmatch.translate(glob)
                                  for glob in optblacklist))
    
    if extension is not None:
        commands = commands or [extension]

    def filteredoptions(cmd):
        return [o for o in findoptions(hg, cmd, extension)
                   if not optskip.match(cmd + "." + o[0])]  

    if not commands:
        for cmd in findcommands(hg):
            unlink = cmd not in cmdwhitelist
            if not unlink:
                print 'processing', cmd
            implementation(javadir, cmd, filteredoptions(cmd), version, unlink)
    else:
        for cmd in commands:
            print 'processing', cmd
            implementation(javadir, cmd, filteredoptions(cmd.lower()), version, False)

def usage():
    print "%s [--hg HGDIR] [--java JAVADIR]\n" % sys.argv[0]
    sys.exit(0)


if __name__ == "__main__":
    hg = "hg"
    javadir = "src/main/java/com/aragost/javahg/commands"

    parser = optparse.OptionParser()
    parser.add_option("--hg", help="path to Mercurial", default=hg)
    parser.add_option("--java",
                      help="directory to write Java files in",
                      metavar="JAVADIR", default=javadir)
    parser.add_option("--extension", 
                      help="an extension to enable", 
                      metavar="EXT", default=None)
    parser.add_option("--command", 
                      help="the commands to generate output for. Default is all unless EXT is provided in which case the default is the extension name", 
                      action="append", default=None)

    (options, args) = parser.parse_args()

    sys.exit(process(options.hg, options.java, options.extension, options.command))
