package com.blade.types;

import com.blade.ioc.annotation.Bean;

/**
 * @author biezhi
 * @date 2017/9/19
 */
@Bean
public class BladeClassDefineType {
    private int    age;
    private String name;
}
