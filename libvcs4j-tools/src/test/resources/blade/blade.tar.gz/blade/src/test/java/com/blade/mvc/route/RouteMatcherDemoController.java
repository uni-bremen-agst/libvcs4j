package com.blade.mvc.route;

public class RouteMatcherDemoController {
    public void index() {
    }

    public void remove() {
    }
}