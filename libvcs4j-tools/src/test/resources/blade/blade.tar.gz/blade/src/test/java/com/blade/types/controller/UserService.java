package com.blade.types.controller;

/**
 * @author biezhi
 * @date 2017/9/19
 */
public class UserService implements Runnable {
    @Override
    public void run() {

    }
}
