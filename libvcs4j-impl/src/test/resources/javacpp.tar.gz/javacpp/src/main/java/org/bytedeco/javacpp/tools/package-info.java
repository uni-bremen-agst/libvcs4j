/**
 * Contains classes used at build time by JavaCPP.
 */
package org.bytedeco.javacpp.tools;
